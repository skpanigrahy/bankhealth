# integration-service
Shared adapter layer: OAuth2 token acquisition, retry/circuit-breaker policy, and the scheduler that
refreshes `widget_cache` per `../../database/schema/schema.sql: configuration` cadence values. Every
capability service calls upstream systems through this module rather than integrating directly — see
`../../docs/04_Engineering` (Document 406 – Scheduler & Refresh Engine).
