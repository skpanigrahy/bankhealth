# tech-readiness-service
Owns Tech Readiness (`/dashboard/tech-readiness`): Teller Express, Connection, ATM, Tablets.
Sources: `../../integrations/splunk`, `../../integrations/cortex`, `../../integrations/atm`.
