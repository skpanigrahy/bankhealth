# dashboard-service

Owns `GET /api/v1/dashboard` and `POST /api/v1/dashboard/refresh` (see `../../api/openapi.yaml`).
Composes `actions-service`, `meetings-service`, `tech-readiness-service`, `performance-service`, and
`nearby-service` behind that single contract (ADR-005) — the frontend only ever calls this service.

Reads exclusively from `dashboard_cache` / `widget_cache` (ADR-002); never fans out to upstream systems
synchronously on a request thread.
