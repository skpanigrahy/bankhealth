# actions-service
Owns Required Actions (`/dashboard/actions`): Control Exceptions, Cash Management, Branch Dashboard,
ICSC, Banker Notifications. Sources: `../../integrations/branch-dashboard`, `../../integrations/cash-manager`,
`../../integrations/banker-homepage`.
