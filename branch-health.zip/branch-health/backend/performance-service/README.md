# performance-service
Owns Performance at a Glance (`/dashboard/performance`): OSAT, Convenience, One Chase Sales, Banker
Availability. Sources: `../../integrations/performance`, `../../integrations/client-central`.
