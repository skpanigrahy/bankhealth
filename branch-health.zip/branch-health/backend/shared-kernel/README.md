# shared-kernel
Domain types shared across services (Branch, Money/percent value objects, Problem Details error model,
audit logging helpers) so `../../api/openapi.yaml` schemas map to one Java representation, not one per
service.
