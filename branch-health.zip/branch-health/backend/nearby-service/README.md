# nearby-service
Owns Nearby Branches (`/dashboard/nearby-branches`). Source: `../../integrations/branch-locator`.
