# meetings-service
Owns Today's Meetings (`/dashboard/meetings`). Source: `../../integrations/client-central`.
