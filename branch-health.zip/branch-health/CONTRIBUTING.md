# Contributing

1. Read `docs/00_INDEX.md` first — it tells you which document is authoritative for what you're touching.
2. Follow the engineering lifecycle for any new feature (see `README.md`): Business Requirement → UX →
   Widget Spec → API Contract → Database → Integration → Backend → Frontend → Tests → Review → Deploy.
   Don't skip steps.
3. If you change `api/openapi.yaml` or `database/schema/schema.sql`, update the matching docs in
   `docs/05_API` / `docs/06_Database` and add a Flyway migration under `database/migrations/`.
4. Any decision that changes an existing ADR's conclusion gets a new ADR in `docs/12_ADR`, not a silent
   code change (see `docs/12_ADR/ADR-*` for the format: Context, Decision, Alternatives, Consequences,
   Review date).
5. Branch naming: `bh/<ticket-id>-short-description`. PRs require CODEOWNERS approval for any path they
   touch.
