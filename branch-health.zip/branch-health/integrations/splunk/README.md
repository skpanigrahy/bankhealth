# Integration: Splunk (Teller Express + Tablets)

| | |
| --- | --- |
| **Source application** | Splunk |
| **Data owner** | Hila Morgan / Mike Allen (Teller Express); Joe Raquepaw (Tablets) |
| **Refresh cadence** | 15 minutes |
| **Purpose** | Teller Express overall status; tablet online/offline counts |

## Authentication
Enterprise OAuth2 (client credentials), scoped read-only. Token acquisition via the shared KYB
integration-service (`backend/integration-service`) — individual widget services never hold
credentials directly.

## Retry policy
1. Initial request
2. Retry after 2s
3. Retry after 5s
4. Circuit breaker opens after repeated failures → `integration_status.circuit_state = OPEN`

## Fallback
Serve the last `widget_cache` row for the affected widget(s) and mark `is_stale = true`. The
frontend renders the widget's "offline cache" state (see `docs/04_Engineering`, Document 403) rather
than an error.

## Data mapping
See `docs/04_Engineering` (Document 401 – data dictionary) for the full source-field → domain-field
mapping. Domain shape for this integration's data is defined in `api/openapi.yaml`.

## Health check
Polled by `backend/integration-service`; surfaced in `integration_status` (see
`database/schema/schema.sql`) and on the platform ops dashboard (Document 409 – telemetry).
