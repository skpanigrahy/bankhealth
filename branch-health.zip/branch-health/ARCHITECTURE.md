# Architecture Overview

## Shape of the system

```
                         ┌───────────────────────────┐
                         │   Branch Manager (React)   │
                         └─────────────┬─────────────┘
                                       │ HTTPS / OAuth2 Bearer
                                       ▼
                         ┌───────────────────────────┐
                         │  Dashboard Aggregation API │   api/openapi.yaml (GET /api/v1/dashboard)
                         └─────────────┬─────────────┘
                                       │
              ┌────────────┬───────────┼───────────┬────────────┬─────────────┐
              ▼            ▼           ▼           ▼            ▼             ▼
        actions-svc   meetings-svc  tech-readi-  performance- nearby-svc  integration-svc
                                     ness-svc      svc
              │            │           │           │            │             │
              └────────────┴───────────┴───────────┴────────────┴─────────────┘
                                       │
                                       ▼
                         ┌───────────────────────────┐
                         │   Local Cache (Postgres)   │   database/schema/schema.sql
                         │  dashboard_cache/widget_*  │
                         └─────────────┬─────────────┘
                                       │ scheduled pulls (15 min / daily / weekly / monthly)
                                       ▼
     ┌────────────┬─────────────┬───────────┬────────────┬────────────┬────────────┬────────────┐
     ▼            ▼             ▼           ▼            ▼            ▼            ▼            ▼
Branch      Client Central  My Cash    Splunk       Cortex       ATM Reporting  Branch      Performance
Dashboard   (meetings)      Manager   (Teller/       (network)   & Monitoring   Locator     Homepage
(84329)                     (89850)   tablets)                   (110976)       Data Store  (OSAT etc.)
```

## Core decisions (see `docs/12_ADR` for full context/trade-offs)

1. **Read-only, launch-out design.** Branch Health never performs the resolving action. Every card/widget
   ends in "go to the system of record." This came directly from banker feedback: "we don't want to work
   here."
2. **Cached aggregation over live fan-out.** A dashboard load never blocks on N upstream calls. Each
   upstream system is pulled on its own cadence into a local cache; the API reads the cache. Only truly
   exceptional cases (none identified for MVP1) would justify a synchronous live call.
3. **Branch Manager only, single-branch by default.** ~340 branch managers cover 2+ locations (one covers
   3); everyone else is single-branch. Multi-branch users get a dropdown that defaults to their current
   location. No cross-branch visibility beyond that — bankers explicitly said they don't want to see
   other branches' data. Market Director / Regional Director rollups are a distinct, later persona.
4. **Deployed as a KYB module, not a standalone platform**, for MVP1 — avoids duplicating CI/CD and batch
   review overhead before the target state is validated with a pilot group.
5. **Service-per-capability backend**, not a single monolith service, so each widget's data path
   (actions, meetings, tech readiness, performance, nearby) can evolve, scale, and fail independently
   while still living under one deployable module.
6. **Contract-first API** (`api/openapi.yaml`) — backend implements it, frontend consumes it. This is the
   single source of truth when documentation and code disagree.

## Widget → data source map

| Widget | Primary source app | Data owner (from discovery) | Cadence |
| --- | --- | --- | --- |
| Control Exceptions | Branch Dashboard (Business Metric Dashboard – 84329) | Kola Oladejo | Real-time (15 min refresh) |
| Cash Management | My Cash Manager (Enterprise Cash Mgmt System UI – 89850) | Ravi Patel | Daily |
| Branch Dashboard (3 data points) | Branch Dashboard (84329) | Kola Oladejo | Real-time (15 min refresh) |
| ICSC | Branch Dashboard (84329) | Kola Oladejo | Monthly |
| Banker Notifications | Banker Homepage (104294) | Kola Oladejo | Real-time (15 min refresh) |
| Today's Meetings / Calendar | Client Central (102242) | Sandy Clarke | Real-time (15 min refresh) |
| Teller Express status | Splunk | Hila Morgan / Mike Allen | Real-time (15 min refresh) |
| Connection status | Cortex | Srinivas Kati / Hila Morgan | Real-time (15 min refresh) |
| ATM status | ATM Reporting and Monitoring (110976) | Nihari Paladugu | Real-time (15 min refresh) |
| Tablets | Splunk | Joe Raquepaw | Real-time (15 min refresh) |
| OSAT / Convenience / One Chase Sales | Performance Homepage | — | Weekly / Monthly per metric |
| Banker Availability | Client Central (102242) | Sandy Clarke | Real-time (15 min refresh) |
| Nearby branches, financial centers, ATMs | Branch Location Data Store (109913) | Kola Oladejo | Real-time (15 min refresh) |

This mapping is normative for `integrations/*` and `database/schema/schema.sql`; if a document elsewhere
disagrees, this table and `api/openapi.yaml` win (see `docs/00_INDEX.md`).
