# Changelog

## Unreleased — MVP1
- Repository scaffold created (docs, api, database, backend skeleton, frontend prototype, integrations,
  infrastructure, testing, ai).
- `api/openapi.yaml` — contract for GET /dashboard and per-widget endpoints.
- `database/schema/schema.sql` — cache/config/audit schema.
- `frontend/` — working React prototype of the Branch Manager dashboard against mock data.
- ADR-001 through ADR-006 recorded.
