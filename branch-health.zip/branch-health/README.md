# Branch Health

**Status:** MVP1 — in build
**Owner:** Jay (Product) · Branch Health Engineering
**Primary persona:** Branch Manager

## What this is

Branch Health is the **single operational landing page** for a Branch Manager. It is not a replacement
for any existing system — it is a consolidated, at-a-glance view that answers:

> "Is my branch operating well today, and is there anything I need to go handle?"

The product philosophy, validated across ~40 banker interviews (garage branches, 1:1 interviews, and a
multi-market/multi-region collective session) facilitated by the UX team:

```
Branch Health  →  Visibility  →  Awareness  →  Decision  →  Launch source application  →  Act there
```

Branch Health never lets you take action inside it. It shows you what needs attention and sends you to
the system of record (Branch Dashboard, My Cash Manager, Client Central, iTech Check, etc.) to resolve it.

## Scope for MVP1

MVP1 targets **Branch Managers only** (Market Director / Regional Director / Operations personas are
explicitly out of scope and will roll up differently in a later phase). See
[`docs/01_Product`](docs/01_Product) for the full Charter, PRD, and BRS, and
[`docs/12_ADR`](docs/12_ADR) for why these boundaries were chosen.

Sections shipping in MVP1:

| Section | Purpose |
| --- | --- |
| Header | Branch identity, operational status (derived from Tech Readiness), last refresh |
| Required Actions | Control Exceptions, Cash Management, Branch Dashboard, ICSC, Banker Notifications |
| Today's Meetings | Read-only view of the day's schedule from Client Central |
| Tech Readiness | Teller Express, connection status, ATM status, tablet status |
| Performance at a Glance | OSAT, Convenience, One Chase Sales, Banker Availability |
| Nearby Branches | Radius map of nearby branches/ATMs with operational relevance (open/closed, ATM/teller availability) |

Explicitly **not** in MVP1 (see `docs/12_ADR` and `docs/14_Backlog`): telephony status, multi-branch
market/regional rollups, notary/drive-up availability, in-app ticket resolution, live/on-demand API calls
in place of the cached refresh model.

## Repository layout

```
branch-health/
├── docs/            Authoritative knowledge base (product, UX, architecture, ADRs, backlog)
├── api/             Contract-first API definitions (OpenAPI 3.1 + JSON Schema) — source of truth
├── database/        Schema, migrations, seed data for the cache/config/audit store
├── backend/         Service-per-capability backend skeleton (Spring Boot, Java 21)
├── frontend/         React 19 + TypeScript Branch Manager dashboard
├── integrations/     One contract per upstream enterprise system
├── infrastructure/  Docker/Kubernetes/Helm/Terraform/monitoring
├── testing/         Unit/integration/contract/perf/security/a11y/e2e
├── ai/              Context, prompts, and validators for AI-assisted implementation
├── scripts/         Developer productivity scripts
└── examples/        Reference implementations to copy patterns from
```

Start with [`docs/00_INDEX.md`](docs/00_INDEX.md) — the master architecture index — before reading or
writing anything else in this repository.

## Engineering standards (fixed for MVP1)

**Backend:** Java 21, Spring Boot 3.x, Hexagonal Architecture, DDD, constructor injection, MapStruct,
Flyway, Micrometer, OpenTelemetry.

**Frontend:** React 19, TypeScript, MUI, React Router, Storybook, Vitest, Playwright.

**API:** REST, OpenAPI 3.1, JSON Schema, RFC 9457 Problem Details for errors, versioned endpoints.

**Security:** OAuth2/OIDC, RBAC, branch-level authorization, secrets via environment/configuration only.

**Deployment note:** for MVP1, Branch Health runs as a **module under KYB** rather than a standalone
product/database, to avoid the CI/CD and administrative overhead of a brand-new platform before the
target state is validated with a pilot group. See `docs/12_ADR`.

## Refresh model

Branch Health does not call upstream systems live on every page view. It reads from a local cache that is
refreshed on a per-source cadence (15 minutes / daily / weekly / monthly) — see
[`docs/04_Engineering`](docs/04_Engineering) and [`database/schema`](database/schema). Live calls are
reserved for the rare case where cached data would be actively misleading.

## Getting started

- Frontend prototype: see [`frontend/README.md`](frontend/README.md)
- API contract: see [`api/openapi.yaml`](api/openapi.yaml)
- Database schema: see [`database/schema/schema.sql`](database/schema/schema.sql)
