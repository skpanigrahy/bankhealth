# Branch Health — Frontend (MVP1)

React 19 + TypeScript + MUI implementation of the Branch Manager dashboard, replicating the UX-approved
design in `../docs/02_UX` (see the project's approved screenshots).

## Run locally

```bash
npm install
npm run dev
```

Opens at http://localhost:5173. Runs entirely against mock data (`src/services/mockData.ts`) that
mirrors `../api/examples/dashboard-response.json`, so there's nothing else to stand up to see the UI.

## Switching to the real API

In `src/services/api.ts`, flip `USE_MOCK = false` and set `VITE_API_BASE_URL` (defaults to `/api/v1`) once
`backend/dashboard-service` implements `GET /api/v1/dashboard` per `../api/openapi.yaml`. No component
changes are needed — every widget only depends on the types in `src/types/dashboard.ts`, which mirror the
contract.

## Structure

```
src/
├── layouts/DashboardLayout.tsx     Top nav bar (hamburger, branch name, Profile, Sign out)
├── pages/BranchManagerDashboard.tsx  Composes widgets; owns loading/error/refresh state
├── widgets/
│   ├── Header/Greeting.tsx          "Good afternoon, {name}" + operational status line
│   ├── RequiredActions/             5 launch-out cards (ADR-001: no in-app resolution)
│   ├── TodaysMeetings/              Banker schedule visualization
│   ├── TechReadiness/               Teller Express / Connection / ATM / Tablet alerts
│   ├── PerformanceAtGlance/         OSAT / Convenience / One Chase Sales / Banker Availability
│   └── NearbyBranches/              Placeholder map + location list (real map = backlog)
├── services/api.ts                 Fetch layer; unwraps the {data, metadata} envelope (ADR-006)
├── services/mockData.ts            Mock payload matching api/openapi.yaml
├── types/dashboard.ts              TypeScript types mirroring api/openapi.yaml
└── theme/theme.ts                  MUI theme sampled from the approved screenshots
```

## Known simplifications in this MVP1 pass (see inline comments)

- `TodaysMeetings` renders illustrative load-per-banker blocks, not real appointment start/end times —
  `Appointment.startTime/endTime` exist in the type but Client Central isn't wired yet.
- `NearbyBranches` renders a static placeholder map with deterministic pin positions, not a real map
  provider (Google Maps/Mapbox) — tracked in `../docs/14_Backlog`.
- `Customize` on Required Actions is present but disabled, matching the approved screenshot and
  `feature_toggle.customize-required-actions = false`.

## Testing (to be filled in — see `../testing/`)

Storybook stories per widget go in `src/stories/`. Vitest unit tests colocate with components. Playwright
e2e specs live in `../testing/e2e/`.
