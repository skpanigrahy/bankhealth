// Mirrors ../../../api/openapi.yaml — keep in sync by hand for MVP1; codegen candidate post-MVP1.

export type OperationalStatus = "GREEN" | "AMBER" | "RED";

export interface Branch {
  branchId: string;
  branchCode: string;
  branchName: string;
  market?: string;
  region?: string;
  timezone?: string;
}

export interface DashboardHeader {
  branch: Branch;
  greetingName: string;
  operationalStatus: OperationalStatus;
  operationalStatusLabel: string;
  lastRefresh: string;
  refreshInProgress: boolean;
  availableBranches: Branch[];
}

export type ActionType =
  | "CONTROL_EXCEPTION"
  | "CASH_MANAGEMENT"
  | "BRANCH_DASHBOARD"
  | "ICSC"
  | "BANKER_NOTIFICATIONS";

export type DueDescriptor =
  | "DUE_TODAY"
  | "DUE_TOMORROW"
  | "DUE_IN_N_DAYS"
  | "NONE_DUE"
  | "TO_REVIEW";

export interface RequiredAction {
  actionId: string;
  actionType: ActionType;
  title: string;
  subtitle?: string;
  pendingCount: number;
  dueDescriptor: DueDescriptor;
  destinationUrl: string;
  priority: "HIGH" | "MEDIUM" | "LOW";
}

export interface RequiredActionsResponse {
  totalDueToday: number;
  actions: RequiredAction[];
}

export interface Appointment {
  appointmentId: string;
  type: "SCHEDULED" | "PROSPECT";
  customerLabel?: string;
  startTime: string;
  endTime: string;
}

export interface BankerSchedule {
  bankerId: string;
  bankerName: string;
  appointments: Appointment[];
}

export interface MeetingsResponse {
  date: string;
  scheduledCount: number;
  prospectCount: number;
  bankers: BankerSchedule[];
}

export type TechReadinessSeverity = "OK" | "WARNING" | "CRITICAL";

export interface TechReadinessAlert {
  component: "TELLER_EXPRESS" | "CONNECTION" | "ATM" | "TABLETS";
  severity: TechReadinessSeverity;
  title: string;
  description: string;
}

export interface TechReadinessResponse {
  overallStatus: OperationalStatus;
  tellerExpress: { status: "ONLINE" | "STORE_MODE" | "OFFLINE" };
  connection: { mode: "PRIMARY" | "CELL_BACKUP" | "OFFLINE" };
  atm: { operational: number; total: number };
  tablets: { online: number; total: number };
  alerts: TechReadinessAlert[];
}

export interface MetricWithTrend {
  label: string;
  value: string;
  trendPercent?: number;
}

export interface PerformanceResponse {
  osat: { metrics: MetricWithTrend[] };
  convenience: { metrics: MetricWithTrend[] };
  oneChaseSales: { metrics: MetricWithTrend[] };
  bankerAvailability: { metrics: MetricWithTrend[] };
}

export type LocationType = "BRANCH_WITH_ATM" | "ATM_DRIVE_UP" | "FINANCIAL_CENTER";

export interface NearbyLocation {
  locationId: string;
  name: string;
  locationType: LocationType;
  distanceMiles: number;
  latitude: number;
  longitude: number;
  isOpen: boolean;
  hoursLabel?: string;
  atmSummary?: string | null;
  meetWithUsUrl?: string | null;
}

export interface NearbyBranchesResponse {
  centerBranchId: string;
  radiusMiles: number;
  locations: NearbyLocation[];
}

export interface Dashboard {
  header: DashboardHeader;
  requiredActions: RequiredActionsResponse;
  meetings: MeetingsResponse;
  techReadiness: TechReadinessResponse;
  performance: PerformanceResponse;
  nearbyBranches: NearbyBranchesResponse;
}

export interface Metadata {
  requestId: string;
  generatedAt: string;
  cacheAge?: string;
}

export interface Envelope<T> {
  data: T;
  metadata: Metadata;
}
