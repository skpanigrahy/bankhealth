import type { Dashboard, Envelope } from "../types/dashboard";
import { mockDashboard } from "./mockData";

// Toggle this once backend/dashboard-service is deployed. Keeping the mock behind the same
// function signature means widgets never know which mode they're in.
const USE_MOCK = true;
const BASE_URL = import.meta.env.VITE_API_BASE_URL ?? "/api/v1";

function withCacheAge(dashboard: Dashboard): Envelope<Dashboard> {
  return {
    data: dashboard,
    metadata: {
      requestId: crypto.randomUUID(),
      generatedAt: new Date().toISOString(),
      cacheAge: "PT3M",
    },
  };
}

export async function fetchDashboard(branchId?: string): Promise<Envelope<Dashboard>> {
  if (USE_MOCK) {
    await new Promise((r) => setTimeout(r, 250)); // simulate network latency for loading states
    return withCacheAge(mockDashboard);
  }

  const url = new URL(`${BASE_URL}/dashboard`, window.location.origin);
  if (branchId) url.searchParams.set("branchId", branchId);

  const res = await fetch(url.toString(), {
    headers: { Accept: "application/json" },
  });

  if (!res.ok) {
    const problem = await res.json().catch(() => null);
    throw new Error(problem?.detail ?? `Dashboard request failed (${res.status})`);
  }

  return (await res.json()) as Envelope<Dashboard>;
}

export async function refreshDashboard(branchId?: string): Promise<void> {
  if (USE_MOCK) {
    await new Promise((r) => setTimeout(r, 400));
    return;
  }
  const url = new URL(`${BASE_URL}/dashboard/refresh`, window.location.origin);
  if (branchId) url.searchParams.set("branchId", branchId);
  await fetch(url.toString(), { method: "POST" });
}
