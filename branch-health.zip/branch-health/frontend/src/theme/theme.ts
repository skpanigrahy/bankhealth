import { createTheme } from "@mui/material/styles";

// Colors sampled directly (pixel-picked) from the UX-approved Branch Health Dashboard
// screenshots (docs/02_UX) — see docs/02_UX/README.md.
export const brand = {
  headerBlue: "#0B4C8C",
  headerBlueDark: "#073A6E",
  iconAccent: "#0B6CB4", // small badge on the Required Actions icons
  accentBrown: "#8A5A2B", // top accent bar seen on the "Reference Guide" title slides
  pageBg: "#F4F5F7",
  cardBg: "#FFFFFF",
  textPrimary: "#1A1F27",
  textSecondary: "#5B6472",
  success: "#1E8E4E",
  warning: "#B7791F",
  critical: "#C22E2E",
  scheduledBlue: "#2F6FE0",
  prospectGreen: "#3EA36B",
};

export const theme = createTheme({
  palette: {
    primary: { main: brand.headerBlue, dark: brand.headerBlueDark },
    success: { main: brand.success },
    warning: { main: brand.warning },
    error: { main: brand.critical },
    background: { default: brand.pageBg, paper: brand.cardBg },
    text: { primary: brand.textPrimary, secondary: brand.textSecondary },
  },
  shape: { borderRadius: 10 },
  typography: {
    fontFamily: '"Segoe UI", Roboto, Helvetica, Arial, sans-serif',
    h1: { fontSize: "1.75rem", fontWeight: 600 },
    h2: { fontSize: "1.25rem", fontWeight: 600 },
    body2: { fontSize: "0.875rem" },
  },
  components: {
    MuiCard: {
      styleOverrides: {
        root: {
          boxShadow: "0 1px 2px rgba(16,24,40,0.06)",
          border: "1px solid #E4E7EC",
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        root: { textTransform: "none", fontWeight: 600 },
      },
    },
  },
});
