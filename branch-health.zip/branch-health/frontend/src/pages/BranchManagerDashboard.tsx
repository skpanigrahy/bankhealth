import { useCallback, useEffect, useState } from "react";
import { Alert, Box, CircularProgress, Grid, Stack, Typography } from "@mui/material";
import { DashboardLayout } from "../layouts/DashboardLayout";
import { Greeting } from "../widgets/Header/Greeting";
import { RequiredActions } from "../widgets/RequiredActions/RequiredActions";
import { TodaysMeetings } from "../widgets/TodaysMeetings/TodaysMeetings";
import { TechReadiness } from "../widgets/TechReadiness/TechReadiness";
import { PerformanceAtGlance } from "../widgets/PerformanceAtGlance/PerformanceAtGlance";
import { NearbyBranches } from "../widgets/NearbyBranches/NearbyBranches";
import { fetchDashboard, refreshDashboard } from "../services/api";
import type { Dashboard } from "../types/dashboard";

type LoadState =
  | { status: "loading" }
  | { status: "error"; message: string }
  | { status: "ready"; dashboard: Dashboard };

export function BranchManagerDashboard() {
  const [state, setState] = useState<LoadState>({ status: "loading" });
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    try {
      const envelope = await fetchDashboard();
      setState({ status: "ready", dashboard: envelope.data });
    } catch (err) {
      setState({
        status: "error",
        message: err instanceof Error ? err.message : "Unable to load dashboard. Please try again.",
      });
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const handleRefresh = useCallback(async () => {
    setRefreshing(true);
    try {
      await refreshDashboard();
      await load();
    } finally {
      setRefreshing(false);
    }
  }, [load]);

  if (state.status === "loading") {
    return (
      <Stack alignItems="center" justifyContent="center" sx={{ minHeight: "100vh" }}>
        <CircularProgress />
      </Stack>
    );
  }

  if (state.status === "error") {
    return (
      <Stack alignItems="center" justifyContent="center" sx={{ minHeight: "100vh", p: 4 }}>
        <Alert severity="error" sx={{ maxWidth: 480 }}>
          {state.message}
        </Alert>
      </Stack>
    );
  }

  const { dashboard } = state;

  return (
    <DashboardLayout branch={dashboard.header.branch}>
      <Greeting header={dashboard.header} onRefresh={handleRefresh} refreshing={refreshing} />

      <RequiredActions data={dashboard.requiredActions} />

      <Box sx={{ mb: 5 }}>
        <Grid container spacing={4}>
          <Grid item xs={12} md={7}>
            <TodaysMeetings data={dashboard.meetings} />
          </Grid>
          <Grid item xs={12} md={5}>
            <TechReadiness data={dashboard.techReadiness} />
          </Grid>
        </Grid>
      </Box>

      <PerformanceAtGlance data={dashboard.performance} />

      <NearbyBranches data={dashboard.nearbyBranches} />

      <Typography variant="caption" color="text.secondary" sx={{ display: "block", mt: 4 }}>
        Data refreshes automatically every 15 minutes. See docs/12_ADR/ADR-002 for the refresh model.
      </Typography>
    </DashboardLayout>
  );
}
