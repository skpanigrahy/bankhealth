import { ReactNode } from "react";
import { AppBar, Toolbar, Box, Typography, IconButton, Button, Stack } from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import PersonOutlineIcon from "@mui/icons-material/PersonOutline";
import LogoutIcon from "@mui/icons-material/Logout";
import { brand } from "../theme/theme";
import type { Branch } from "../types/dashboard";

interface Props {
  branch: Branch;
  children: ReactNode;
}

export function DashboardLayout({ branch, children }: Props) {
  return (
    <Box sx={{ minHeight: "100vh", bgcolor: brand.pageBg }}>
      <AppBar
        position="sticky"
        elevation={0}
        sx={{ bgcolor: brand.headerBlue, color: "#fff" }}
      >
        <Toolbar sx={{ gap: 2 }}>
          <IconButton edge="start" color="inherit" aria-label="menu">
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" sx={{ fontWeight: 600, fontSize: "1.05rem" }}>
            Branch Health Dashboard
          </Typography>
          <Typography sx={{ opacity: 0.6 }}>|</Typography>
          <Typography sx={{ fontWeight: 600 }}>{branch.branchName}</Typography>
          <Box sx={{ flexGrow: 1 }} />
          <Stack direction="row" spacing={2} alignItems="center">
            <Button
              color="inherit"
              startIcon={<PersonOutlineIcon />}
              sx={{ opacity: 0.95 }}
            >
              Profile
            </Button>
            <Button color="inherit" endIcon={<LogoutIcon />} sx={{ opacity: 0.95 }}>
              Sign out
            </Button>
          </Stack>
        </Toolbar>
      </AppBar>
      <Box component="main" sx={{ maxWidth: 1280, mx: "auto", px: { xs: 2, md: 4 }, py: 4 }}>
        {children}
      </Box>
    </Box>
  );
}
