import { Box, Typography, Stack, Link } from "@mui/material";
import type { MeetingsResponse } from "../../types/dashboard";
import { brand } from "../../theme/theme";

interface Props {
  data: MeetingsResponse;
}

const HOURS = ["8AM", "10AM", "12PM", "2PM", "4PM", "6PM"];

/**
 * Appointment start/end times aren't populated by the Client Central integration until MVP2
 * (see docs/04_Engineering); for MVP1 the timeline renders two illustrative block clusters per
 * banker (AM / PM, matching the approved design's morning-block / afternoon-block-with-a-
 * midday-gap layout), derived deterministically from the banker id — not real clock positions.
 * Swap for real Appointment[] positioning once available.
 */
function cluster(seed: string, offset: number, min: number, max: number) {
  let hash = 0;
  for (const ch of seed) hash = (hash * 31 + ch.charCodeAt(0) + offset) % 97;
  const blocks = min + (hash % (max - min + 1));
  return Array.from({ length: blocks }, (_, i) => ((hash + i) % 3 === 0 ? "prospect" : "scheduled"));
}

function segmentClusters(seed: string) {
  return [cluster(seed, 1, 3, 4), cluster(seed, 2, 4, 6)];
}

export function TodaysMeetings({ data }: Props) {
  return (
    <Box component="section" aria-labelledby="meetings-heading">
      <Stack direction="row" justifyContent="space-between" alignItems="baseline">
        <Typography id="meetings-heading" variant="h2">
          Today's meetings
        </Typography>
        <Link href="#" underline="hover" variant="body2">
          See details
        </Link>
      </Stack>
      <Typography color="text.secondary" variant="body2" sx={{ mb: 2 }}>
        Prepare for customer appointments.
      </Typography>

      <Stack direction="row" spacing={3} sx={{ mb: 1.5 }}>
        <LegendDot color={brand.scheduledBlue} label={`Scheduled (${data.scheduledCount})`} />
        <LegendDot color={brand.prospectGreen} label={`Prospects (${data.prospectCount})`} />
      </Stack>

      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: `140px repeat(${HOURS.length}, 1fr)`,
          columnGap: 1,
          fontSize: "0.75rem",
          color: "text.secondary",
          mb: 1,
        }}
      >
        <span />
        {HOURS.map((h) => (
          <span key={h}>{h}</span>
        ))}
      </Box>

      <Stack spacing={1.25}>
        {data.bankers.map((banker) => (
          <Box
            key={banker.bankerId}
            sx={{ display: "grid", gridTemplateColumns: "140px 1fr", alignItems: "center", gap: 1 }}
          >
            <Typography variant="body2" noWrap>
              {banker.bankerName}
            </Typography>
            <Stack direction="row" spacing={2}>
              {segmentClusters(banker.bankerId).map((blocks, ci) => (
                <Stack key={ci} direction="row" spacing={0.5}>
                  {blocks.map((kind, i) => (
                    <Box
                      key={i}
                      sx={{
                        height: 20,
                        width: 26,
                        borderRadius: 0.5,
                        bgcolor: kind === "prospect" ? brand.prospectGreen : brand.scheduledBlue,
                      }}
                    />
                  ))}
                </Stack>
              ))}
            </Stack>
          </Box>
        ))}
      </Stack>
    </Box>
  );
}

function LegendDot({ color, label }: { color: string; label: string }) {
  return (
    <Stack direction="row" spacing={0.75} alignItems="center">
      <Box sx={{ width: 10, height: 10, bgcolor: color, borderRadius: 0.5 }} />
      <Typography variant="body2" color="text.secondary">
        {label}
      </Typography>
    </Stack>
  );
}
