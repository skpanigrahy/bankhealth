import { Box, Typography, Stack, Card, Button, Divider } from "@mui/material";
import PlaceIcon from "@mui/icons-material/Place";
import AccountBalanceOutlinedIcon from "@mui/icons-material/AccountBalanceOutlined";
import LocalAtmOutlinedIcon from "@mui/icons-material/LocalAtmOutlined";
import type { LocationType, NearbyBranchesResponse } from "../../types/dashboard";
import { brand } from "../../theme/theme";

const LOCATION_ICON: Record<LocationType, React.ElementType> = {
  BRANCH_WITH_ATM: AccountBalanceOutlinedIcon,
  ATM_DRIVE_UP: LocalAtmOutlinedIcon,
  FINANCIAL_CENTER: AccountBalanceOutlinedIcon,
};

interface Props {
  data: NearbyBranchesResponse;
}

// Deterministic placeholder positions for MVP1 — replace with a real map provider
// (see docs/14_Backlog and integrations/branch-locator) wired to lat/long.
const PIN_POSITIONS = [
  { top: "60%", left: "22%" },
  { top: "35%", left: "55%" },
  { top: "20%", left: "20%" },
  { top: "75%", left: "48%" },
  { top: "50%", left: "72%" },
];

export function NearbyBranches({ data }: Props) {
  return (
    <Box component="section" aria-labelledby="nearby-heading">
      <Typography id="nearby-heading" variant="h2">
        Nearby branches, financial centers and ATMs
      </Typography>
      <Typography color="text.secondary" variant="body2" sx={{ mb: 2 }}>
        See which locations are open or closed.
      </Typography>

      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: { xs: "1fr", md: "1fr 380px" },
          gap: 0,
          border: "1px solid #E4E7EC",
          borderRadius: 2,
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            position: "relative",
            minHeight: 320,
            bgcolor: "#E9EEF3",
            backgroundImage:
              "linear-gradient(#DCE4EC 1px, transparent 1px), linear-gradient(90deg, #DCE4EC 1px, transparent 1px)",
            backgroundSize: "32px 32px",
          }}
        >
          {data.locations.map((loc, i) => {
            const pos = PIN_POSITIONS[i % PIN_POSITIONS.length];
            return (
              <Box
                key={loc.locationId}
                sx={{
                  position: "absolute",
                  top: pos.top,
                  left: pos.left,
                  transform: "translate(-50%, -100%)",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                }}
                title={loc.name}
              >
                <PlaceIcon
                  sx={{
                    fontSize: 34,
                    color: loc.isOpen ? brand.headerBlue : brand.critical,
                    filter: "drop-shadow(0 1px 2px rgba(0,0,0,0.25))",
                  }}
                />
                <Typography
                  variant="caption"
                  sx={{ mt: -0.5, color: "#fff", fontWeight: 700, position: "relative", top: -22 }}
                >
                  {i + 1}
                </Typography>
              </Box>
            );
          })}
        </Box>

        <Stack divider={<Divider />} sx={{ bgcolor: "background.paper" }}>
          {data.locations.map((loc, i) => (
            <Box key={loc.locationId} sx={{ p: 2 }}>
              <Stack direction="row" justifyContent="space-between">
                <Typography variant="caption" color="text.secondary">
                  {loc.locationType === "BRANCH_WITH_ATM"
                    ? "Chase branch with ATM"
                    : loc.locationType === "ATM_DRIVE_UP"
                      ? "Chase ATM | Drive-up"
                      : "Financial center"}
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  {loc.distanceMiles.toFixed(2)} mi.
                </Typography>
              </Stack>
              <Stack direction="row" spacing={1} alignItems="center" sx={{ mt: 0.5 }}>
                <Card
                  sx={{
                    width: 20,
                    height: 20,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    bgcolor: "primary.main",
                    color: "#fff",
                    fontSize: "0.7rem",
                    fontWeight: 700,
                    flexShrink: 0,
                  }}
                >
                  {i + 1}
                </Card>
                {(() => {
                  const LocIcon = LOCATION_ICON[loc.locationType];
                  return <LocIcon sx={{ fontSize: 20, color: "text.secondary" }} />;
                })()}
                <Typography sx={{ fontWeight: 600 }}>{loc.name}</Typography>
              </Stack>
              {loc.hoursLabel && (
                <Typography variant="body2" color={loc.isOpen ? "text.secondary" : "error.main"} sx={{ mt: 0.5 }}>
                  {loc.isOpen ? loc.hoursLabel : "Temporarily closed"}
                </Typography>
              )}
              {loc.atmSummary && loc.isOpen && (
                <Typography variant="body2" color="text.secondary">
                  {loc.atmSummary}
                </Typography>
              )}
              {loc.meetWithUsUrl && (
                <Button
                  size="small"
                  variant="outlined"
                  href={loc.meetWithUsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  sx={{ mt: 1 }}
                >
                  Meet with us
                </Button>
              )}
            </Box>
          ))}
        </Stack>
      </Box>
    </Box>
  );
}
