import { Box, Typography, Stack, Link, CircularProgress } from "@mui/material";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import RefreshIcon from "@mui/icons-material/Refresh";
import type { DashboardHeader } from "../../types/dashboard";
import { brand } from "../../theme/theme";

interface Props {
  header: DashboardHeader;
  onRefresh: () => void;
  refreshing: boolean;
}

const statusColor: Record<DashboardHeader["operationalStatus"], string> = {
  GREEN: brand.success,
  AMBER: brand.warning,
  RED: brand.critical,
};

function formatTime(iso: string) {
  return new Date(iso).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    timeZoneName: "short",
  });
}

export function Greeting({ header, onRefresh, refreshing }: Props) {
  return (
    <Box sx={{ mb: 4 }}>
      <Typography variant="h1" sx={{ mb: 1 }}>
        Good afternoon, {header.greetingName}
      </Typography>
      <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap">
        <CheckCircleIcon sx={{ color: statusColor[header.operationalStatus], fontSize: 20 }} />
        <Typography color="text.secondary">{header.operationalStatusLabel}</Typography>
        <Typography color="text.secondary">|</Typography>
        <Typography color="text.secondary">
          Last updated {formatTime(header.lastRefresh)}
        </Typography>
        <Typography color="text.secondary">|</Typography>
        <Link
          component="button"
          onClick={onRefresh}
          underline="hover"
          sx={{ display: "inline-flex", alignItems: "center", gap: 0.5 }}
        >
          Refresh
          {refreshing ? (
            <CircularProgress size={12} thickness={6} />
          ) : (
            <RefreshIcon sx={{ fontSize: 16 }} />
          )}
        </Link>
      </Stack>
    </Box>
  );
}
