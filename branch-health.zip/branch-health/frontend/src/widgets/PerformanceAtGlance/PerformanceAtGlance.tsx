import { Box, Typography, Stack, Link, Card } from "@mui/material";
import type { MetricWithTrend, PerformanceResponse } from "../../types/dashboard";
import { brand } from "../../theme/theme";

interface Props {
  data: PerformanceResponse;
}

function Metric({ metric }: { metric: MetricWithTrend }) {
  const trend = metric.trendPercent ?? 0;
  const trendColor = trend > 0 ? brand.success : trend < 0 ? brand.critical : "text.secondary";
  const trendLabel = trend === 0 ? "0%" : `${trend > 0 ? "+" : ""}${trend}%`;

  return (
    <Box>
      <Typography variant="body2" color="text.secondary">
        {metric.label}
      </Typography>
      <Typography sx={{ fontSize: "1.5rem", fontWeight: 600, lineHeight: 1.3 }}>{metric.value}</Typography>
      <Typography variant="caption" sx={{ color: trendColor, fontWeight: 600 }}>
        {trendLabel}
      </Typography>
    </Box>
  );
}

function MetricCard({
  title,
  metrics,
  monthlyCounts,
}: {
  title: string;
  metrics: MetricWithTrend[];
  monthlyCounts?: boolean;
}) {
  return (
    <Card sx={{ p: 2.5 }}>
      <Typography sx={{ fontWeight: 600, color: "primary.main", mb: monthlyCounts ? 0 : 1.5 }}>
        {title}
      </Typography>
      {monthlyCounts && (
        <Typography variant="caption" color="text.secondary" sx={{ display: "block", mb: 1.5 }}>
          Monthly counts
        </Typography>
      )}
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          rowGap: 2,
          columnGap: 2,
        }}
      >
        {metrics.map((m) => (
          <Metric key={m.label} metric={m} />
        ))}
      </Box>
    </Card>
  );
}

export function PerformanceAtGlance({ data }: Props) {
  return (
    <Box component="section" sx={{ mb: 5 }} aria-labelledby="performance-heading">
      <Stack direction="row" justifyContent="space-between" alignItems="baseline">
        <Typography id="performance-heading" variant="h2">
          Performance at a glance
        </Typography>
        <Link href="#" underline="hover" variant="body2">
          Top daily trends reports
        </Link>
      </Stack>
      <Stack direction="row" spacing={2} alignItems="baseline" sx={{ mb: 2 }}>
        <Typography color="text.secondary" variant="body2">
          Track your branch's progress.
        </Typography>
        <Box sx={{ flexGrow: 1 }} />
        <Link href="#" underline="hover" variant="body2">
          Discover needs
        </Link>
        <Typography color="text.secondary">|</Typography>
        <Link href="#" underline="hover" variant="body2">
          Branch offers
        </Link>
      </Stack>

      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr", md: "repeat(4, 1fr)" },
          gap: 2,
        }}
      >
        <MetricCard title="OSAT" metrics={data.osat.metrics} />
        <MetricCard title="Convenience" metrics={data.convenience.metrics} monthlyCounts />
        <MetricCard title="One Chase sales" metrics={data.oneChaseSales.metrics} monthlyCounts />
        <MetricCard title="Banker Availability" metrics={data.bankerAvailability.metrics} />
      </Box>
    </Box>
  );
}
