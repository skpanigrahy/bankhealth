import { Box, Typography, Stack, Link, Divider } from "@mui/material";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import WarningAmberIcon from "@mui/icons-material/WarningAmber";
import ErrorOutlineIcon from "@mui/icons-material/ErrorOutline";
import type { TechReadinessResponse, TechReadinessSeverity } from "../../types/dashboard";
import { brand } from "../../theme/theme";

interface Props {
  data: TechReadinessResponse;
}

// Pixel-matched from the approved screenshots: Teller Express uses a red/critical triangle
// warning; Connection and ATM use an amber diamond "i" info icon; Tablets uses a green check.
const SEVERITY_ICON: Record<TechReadinessSeverity, React.ElementType> = {
  OK: CheckCircleIcon,
  WARNING: ErrorOutlineIcon,
  CRITICAL: WarningAmberIcon,
};

const SEVERITY_COLOR: Record<TechReadinessSeverity, string> = {
  OK: brand.success,
  WARNING: brand.warning,
  CRITICAL: brand.critical,
};

export function TechReadiness({ data }: Props) {
  const okSummaries: { title: string }[] = [];
  if (data.tablets.online === data.tablets.total) {
    okSummaries.push({ title: `${data.tablets.online} out of ${data.tablets.total} tablets are online` });
  }

  return (
    <Box component="section" aria-labelledby="tech-readiness-heading">
      <Stack direction="row" justifyContent="space-between" alignItems="baseline">
        <Typography id="tech-readiness-heading" variant="h2">
          Tech readiness
        </Typography>
        <Link href="#" underline="hover" variant="body2">
          See tickets
        </Link>
      </Stack>
      <Typography color="text.secondary" variant="body2" sx={{ mb: 2 }}>
        Manage your ability to serve customers.
      </Typography>

      <Stack divider={<Divider />} spacing={1.5}>
        {data.alerts.map((alert, i) => {
          const Icon = SEVERITY_ICON[alert.severity];
          return (
            <Stack key={i} direction="row" spacing={1.5} sx={{ py: 0.5 }}>
              <Icon sx={{ color: SEVERITY_COLOR[alert.severity], fontSize: 22, mt: 0.25 }} />
              <Box>
                <Typography sx={{ fontWeight: 600, color: SEVERITY_COLOR[alert.severity] }}>
                  {alert.title}
                </Typography>
                <Typography color="text.secondary" variant="body2">
                  {alert.description}
                </Typography>
              </Box>
            </Stack>
          );
        })}

        {data.tablets.online === data.tablets.total && (
          <Stack direction="row" spacing={1.5} sx={{ py: 0.5 }}>
            <CheckCircleIcon sx={{ color: brand.success, fontSize: 22, mt: 0.25 }} />
            <Typography sx={{ fontWeight: 500 }}>
              {data.tablets.online} out of {data.tablets.total} tablets are online
            </Typography>
          </Stack>
        )}
      </Stack>
    </Box>
  );
}
