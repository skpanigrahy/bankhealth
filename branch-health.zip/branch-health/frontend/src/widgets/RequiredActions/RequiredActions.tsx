import { Box, Typography, Stack, Card, CardActionArea, Button } from "@mui/material";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import AccountBalanceWalletOutlinedIcon from "@mui/icons-material/AccountBalanceWalletOutlined";
import SpaceDashboardOutlinedIcon from "@mui/icons-material/SpaceDashboardOutlined";
import ArticleOutlinedIcon from "@mui/icons-material/ArticleOutlined";
import PersonAddAltOutlinedIcon from "@mui/icons-material/PersonAddAltOutlined";
import TouchAppOutlinedIcon from "@mui/icons-material/TouchAppOutlined";
import type { ActionType, RequiredActionsResponse } from "../../types/dashboard";
import { brand } from "../../theme/theme";

const ICONS: Record<ActionType, React.ElementType> = {
  CONTROL_EXCEPTION: LockOutlinedIcon,
  CASH_MANAGEMENT: AccountBalanceWalletOutlinedIcon,
  BRANCH_DASHBOARD: SpaceDashboardOutlinedIcon,
  ICSC: ArticleOutlinedIcon,
  BANKER_NOTIFICATIONS: PersonAddAltOutlinedIcon,
};

// Every card icon in the approved design carries a small blue accent badge bottom-left,
// except Banker Notifications, whose icon already contains a "+" (person-add). ICSC's badge
// is a hand-cursor (touch) instead of a plain square — pixel-matched from the screenshots.
const BADGED: Partial<Record<ActionType, "dot" | "touch">> = {
  CONTROL_EXCEPTION: "dot",
  CASH_MANAGEMENT: "dot",
  BRANCH_DASHBOARD: "dot",
  ICSC: "touch",
};

function ActionIcon({ actionType }: { actionType: ActionType }) {
  const Icon = ICONS[actionType];
  const badge = BADGED[actionType];
  return (
    <Box sx={{ position: "relative", width: 34, height: 34, mb: 1.5 }}>
      <Icon sx={{ fontSize: 32, color: "text.primary" }} />
      {badge && (
        <Box
          sx={{
            position: "absolute",
            bottom: -2,
            left: -2,
            width: 14,
            height: 14,
            borderRadius: "4px",
            bgcolor: brand.iconAccent,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          {badge === "touch" && <TouchAppOutlinedIcon sx={{ fontSize: 10, color: "#fff" }} />}
        </Box>
      )}
    </Box>
  );
}

interface Props {
  data: RequiredActionsResponse;
}

export function RequiredActions({ data }: Props) {
  return (
    <Box component="section" sx={{ mb: 5 }} aria-labelledby="required-actions-heading">
      <Stack direction="row" justifyContent="space-between" alignItems="flex-start" sx={{ mb: 0.5 }}>
        <Box>
          <Typography id="required-actions-heading" variant="h2">
            Required actions
          </Typography>
          <Typography color="text.secondary" variant="body2">
            {data.totalDueToday} action items are due today.
          </Typography>
        </Box>
        {/* Disabled in MVP1 — see feature_toggle 'customize-required-actions' */}
        <Button variant="outlined" size="small" disabled>
          Customize
        </Button>
      </Stack>

      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr", md: "repeat(5, 1fr)" },
          gap: 2,
          mt: 2,
        }}
      >
        {data.actions.map((action) => (
          <Card key={action.actionId} sx={{ height: "100%" }}>
            <CardActionArea
              component="a"
              href={action.destinationUrl}
              target="_blank"
              rel="noopener noreferrer"
              sx={{ p: 2.5, height: "100%", display: "flex", flexDirection: "column", alignItems: "flex-start" }}
            >
              <ActionIcon actionType={action.actionType} />
              <Typography sx={{ fontWeight: 600 }}>{action.title}</Typography>
              <Typography color="text.secondary" variant="body2">
                {action.subtitle}
              </Typography>
            </CardActionArea>
          </Card>
        ))}
      </Box>
    </Box>
  );
}
