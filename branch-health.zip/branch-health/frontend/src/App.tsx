import { BranchManagerDashboard } from "./pages/BranchManagerDashboard";

export default function App() {
  return <BranchManagerDashboard />;
}
