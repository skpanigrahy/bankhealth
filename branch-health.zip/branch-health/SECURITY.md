# Security

Branch Health is read-only toward its own users (ADR-001) and authenticates via enterprise OAuth2/OIDC.
Authorization is branch-level: a manager may only view branches they're assigned in
`branch_manager_assignment` (see `database/schema/schema.sql`). Full model: `docs/10_Security`.

Report suspected vulnerabilities through the standard internal security channel — do not open a public
issue.
