# Data dictionary & retention

Full field-by-field dictionary (ENT-* IDs, source, refresh cadence) lives in
`../../docs/04_Engineering` (Document 401). This file only covers what isn't obvious from
`../schema/schema.sql` column comments.

| Table | Retention | Notes |
| --- | --- | --- |
| `dashboard_cache`, `widget_cache` | Rolling — overwritten on each refresh | Not history; `refresh_history` is the audit trail of refreshes |
| `refresh_history` | 90 days | Used for scheduler health dashboards (Document 409 telemetry) |
| `audit_log` | Per platform data-retention policy | See `../../docs/10_Security` |
| `branch`, `branch_manager_assignment` | Indefinite, soft-delete via `status` | Synced daily from Branch Directory |
