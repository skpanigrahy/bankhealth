-- Flyway migration V1 — initial schema. Mirrors database/schema/schema.sql (target-state doc).

-- Branch Health — cache / configuration / audit schema
-- Postgres / Aurora. Branch Health is read-only toward users (ADR-001) but still owns this
-- persistence for cached aggregation (ADR-002), user preference, feature toggles, and audit.
--
-- Conventions (from platform constitution.md, applied here):
--   * UUID primary keys
--   * mandatory audit columns: created_at, created_by, updated_at, updated_by
--   * optimistic locking via `version`
--   * soft delete via `status`, never a hard DELETE on business tables
--   * migrations are managed by Flyway; this file is the human-readable target state,
--     not itself a migration — see database/migrations/V1__init.sql

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================================
-- branch — ENT-BR-* from the data dictionary (Document 401)
-- ============================================================================
CREATE TABLE branch (
    branch_id     UUID PRIMARY KEY DEFAULT uuid_generate_v4(),   -- ENT-BR-001
    branch_code   VARCHAR(10) NOT NULL UNIQUE,                   -- ENT-BR-002
    branch_name   VARCHAR(100) NOT NULL,                         -- ENT-BR-003
    market        VARCHAR(100),                                  -- ENT-BR-004
    region        VARCHAR(100),                                  -- ENT-BR-005
    timezone      VARCHAR(64) NOT NULL DEFAULT 'America/New_York', -- ENT-BR-006
    latitude      DOUBLE PRECISION,
    longitude     DOUBLE PRECISION,
    status        VARCHAR(16) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','INACTIVE')),
    version       INTEGER NOT NULL DEFAULT 0,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_by    VARCHAR(64) NOT NULL DEFAULT 'system',
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by    VARCHAR(64) NOT NULL DEFAULT 'system'
);

-- Which branches a given SID (banker) may view — enforces branch-level authorization (ADR/07_Security)
CREATE TABLE branch_manager_assignment (
    assignment_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sid           VARCHAR(32) NOT NULL,
    branch_id     UUID NOT NULL REFERENCES branch(branch_id),
    is_primary    BOOLEAN NOT NULL DEFAULT true,
    status        VARCHAR(16) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','INACTIVE')),
    version       INTEGER NOT NULL DEFAULT 0,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_by    VARCHAR(64) NOT NULL DEFAULT 'system',
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by    VARCHAR(64) NOT NULL DEFAULT 'system',
    UNIQUE (sid, branch_id)
);
CREATE INDEX idx_bma_sid ON branch_manager_assignment(sid) WHERE status = 'ACTIVE';

-- ============================================================================
-- dashboard_cache — one row per branch, the assembled payload behind GET /dashboard
-- widget_cache    — one row per (branch, widget) so a single upstream failure only
--                    affects its own widget's freshness (ADR-005)
-- ============================================================================
CREATE TABLE dashboard_cache (
    dashboard_cache_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    branch_id           UUID NOT NULL UNIQUE REFERENCES branch(branch_id),
    operational_status  VARCHAR(8) NOT NULL CHECK (operational_status IN ('GREEN','AMBER','RED')),
    payload             JSONB NOT NULL,          -- last known-good full Dashboard payload (api/openapi.yaml)
    generated_at        TIMESTAMPTZ NOT NULL,
    version             INTEGER NOT NULL DEFAULT 0,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_by          VARCHAR(64) NOT NULL DEFAULT 'system',
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by          VARCHAR(64) NOT NULL DEFAULT 'system'
);

CREATE TABLE widget_cache (
    widget_cache_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    branch_id       UUID NOT NULL REFERENCES branch(branch_id),
    widget_key      VARCHAR(32) NOT NULL CHECK (widget_key IN
                      ('REQUIRED_ACTIONS','MEETINGS','TECH_READINESS','PERFORMANCE','NEARBY_BRANCHES')),
    payload         JSONB NOT NULL,
    source_system   VARCHAR(64) NOT NULL,        -- e.g. 'Branch Dashboard (84329)', 'Client Central (102242)'
    is_stale        BOOLEAN NOT NULL DEFAULT false, -- true when last refresh attempt failed (partial data / offline cache state)
    generated_at    TIMESTAMPTZ NOT NULL,
    version         INTEGER NOT NULL DEFAULT 0,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_by      VARCHAR(64) NOT NULL DEFAULT 'system',
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by      VARCHAR(64) NOT NULL DEFAULT 'system',
    UNIQUE (branch_id, widget_key)
);
CREATE INDEX idx_widget_cache_branch ON widget_cache(branch_id);

-- ============================================================================
-- refresh_history — scheduler run log (Document 406), one row per job execution
-- integration_status — current health of each upstream integration (drives BH-1003 errors)
-- ============================================================================
CREATE TABLE refresh_history (
    refresh_id     UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    branch_id      UUID REFERENCES branch(branch_id),  -- NULL for global/daily directory jobs
    widget_key     VARCHAR(32) NOT NULL,
    cadence        VARCHAR(16) NOT NULL CHECK (cadence IN ('REALTIME','DAILY','WEEKLY','MONTHLY')),
    triggered_by   VARCHAR(16) NOT NULL DEFAULT 'SCHEDULER' CHECK (triggered_by IN ('SCHEDULER','MANUAL')),
    started_at     TIMESTAMPTZ NOT NULL,
    completed_at   TIMESTAMPTZ,
    outcome        VARCHAR(16) CHECK (outcome IN ('SUCCESS','PARTIAL','FAILED')),
    error_code     VARCHAR(16),                          -- e.g. 'BH-1003'
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_by     VARCHAR(64) NOT NULL DEFAULT 'system'
);
CREATE INDEX idx_refresh_history_branch_widget ON refresh_history(branch_id, widget_key, started_at DESC);

CREATE TABLE integration_status (
    integration_status_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    integration_key  VARCHAR(64) NOT NULL UNIQUE,  -- e.g. 'client-central', 'splunk', 'atm'
    display_name     VARCHAR(128) NOT NULL,
    owner            VARCHAR(128),                 -- e.g. 'Kola Oladejo'
    circuit_state     VARCHAR(16) NOT NULL DEFAULT 'CLOSED' CHECK (circuit_state IN ('CLOSED','OPEN','HALF_OPEN')),
    last_success_at   TIMESTAMPTZ,
    last_failure_at   TIMESTAMPTZ,
    consecutive_failures INTEGER NOT NULL DEFAULT 0,
    version           INTEGER NOT NULL DEFAULT 0,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_by        VARCHAR(64) NOT NULL DEFAULT 'system',
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by        VARCHAR(64) NOT NULL DEFAULT 'system'
);

-- ============================================================================
-- user_preference — per-SID UI preferences (e.g. "Customize" required-actions ordering; not in MVP1 UI
--                    per screenshot's disabled Customize button, but the row shape is ready)
-- feature_toggle   — externalized config (Document 410); no hardcoded values
-- configuration    — generic key/value platform config (refresh intervals, timeouts, URLs)
-- ============================================================================
CREATE TABLE user_preference (
    user_preference_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sid            VARCHAR(32) NOT NULL,
    preference_key VARCHAR(64) NOT NULL,
    preference_value JSONB NOT NULL,
    version        INTEGER NOT NULL DEFAULT 0,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_by     VARCHAR(64) NOT NULL DEFAULT 'system',
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by     VARCHAR(64) NOT NULL DEFAULT 'system',
    UNIQUE (sid, preference_key)
);

CREATE TABLE feature_toggle (
    feature_toggle_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    toggle_key     VARCHAR(64) NOT NULL UNIQUE,   -- e.g. 'customize-required-actions', 'nearby-branches-map'
    enabled        BOOLEAN NOT NULL DEFAULT false,
    description    TEXT,
    version        INTEGER NOT NULL DEFAULT 0,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_by     VARCHAR(64) NOT NULL DEFAULT 'system',
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by     VARCHAR(64) NOT NULL DEFAULT 'system'
);

CREATE TABLE configuration (
    configuration_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    config_key     VARCHAR(128) NOT NULL UNIQUE,  -- e.g. 'refresh.interval.realtime.minutes' = '15'
    config_value   TEXT NOT NULL,
    description    TEXT,
    version        INTEGER NOT NULL DEFAULT 0,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_by     VARCHAR(64) NOT NULL DEFAULT 'system',
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by     VARCHAR(64) NOT NULL DEFAULT 'system'
);

-- ============================================================================
-- audit_log — every read of another branch's data, every manual refresh, every config change
-- ============================================================================
CREATE TABLE audit_log (
    audit_log_id   UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sid            VARCHAR(32) NOT NULL,
    branch_id      UUID REFERENCES branch(branch_id),
    action         VARCHAR(64) NOT NULL,          -- e.g. 'DASHBOARD_VIEW', 'MANUAL_REFRESH', 'CONFIG_CHANGE'
    detail         JSONB,
    occurred_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_by     VARCHAR(64) NOT NULL DEFAULT 'system'
);
CREATE INDEX idx_audit_log_sid_time ON audit_log(sid, occurred_at DESC);

-- Retention: audit_log retained per platform data-retention policy (see docs/10_Security);
-- refresh_history retained 90 days by default (see database/dictionary/README.md).
