-- Dev/staging seed data only — never run against production.

INSERT INTO branch (branch_code, branch_name, market, region, timezone, latitude, longitude) VALUES
  ('0421', 'Main Street',   'Mid-Atlantic', 'Northeast', 'America/New_York', 39.9900, -75.2000),
  ('0533', 'Riverdate North','Mid-Atlantic', 'Northeast', 'America/New_York', 40.0100, -75.1900);

INSERT INTO feature_toggle (toggle_key, enabled, description) VALUES
  ('customize-required-actions', false, 'Reordering Required Actions cards — deferred past MVP1 (see screenshot: Customize button disabled)'),
  ('nearby-branches-map',        true,  'Nearby Branches map widget'),
  ('manual-refresh',             true,  'Manual refresh action on the dashboard header');

INSERT INTO configuration (config_key, config_value, description) VALUES
  ('refresh.interval.realtime.minutes', '15', 'Cadence for Control Exceptions, Branch Dashboard, ICSC*, Banker Notifications, Meetings, Tech Readiness, Nearby Branches'),
  ('refresh.interval.daily.hour',       '2',  'Hour (branch-local) the daily Cash Management + Branch Directory jobs run'),
  ('refresh.interval.weekly.day',       'MON','Day the weekly Performance KPI job runs'),
  ('refresh.interval.monthly.day',      '1',  'Day of month the ICSC monthly job runs'),
  ('nearby.default.radiusMiles',        '5',  'Default radius for Nearby Branches widget');
