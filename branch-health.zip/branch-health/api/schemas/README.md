These are extracted directly from `../openapi.yaml` for standalone JSON Schema validation / codegen use.
`../openapi.yaml` remains the source of truth (docs/00_INDEX.md) — regenerate this folder from it rather
than editing these files by hand. Internal `$ref`s use `#/components/schemas/...` and resolve against
`openapi.yaml`, not standalone.
