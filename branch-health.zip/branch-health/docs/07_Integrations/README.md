# Integrations

Narrative notes per upstream system. Machine-readable contracts live in ../../integrations/*.
