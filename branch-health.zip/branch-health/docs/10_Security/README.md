# Security

Authentication flow, RBAC, branch-level authorization, session management, secrets handling, audit logging.
