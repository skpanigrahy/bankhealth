# Product

Charter, PRD, and BRS. Ported from Phase1-Document 001/002/003. Defines business requirements and success criteria.
