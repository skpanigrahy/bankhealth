# DevOps

CI/CD pipeline spec, environments, deployment process. See ../../.github/workflows and ../../infrastructure/.
