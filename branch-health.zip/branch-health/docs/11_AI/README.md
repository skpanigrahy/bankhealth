# AI

Links to ../../ai/ — context, prompts, and validators used when an AI coding agent implements a feature in this repo.
