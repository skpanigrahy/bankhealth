# ADR-004: Branch Health deploys as a module under KYB, not a standalone platform, for MVP1

**Status:** Accepted
**Date:** 2026-04-23

## Context

Know Your Branch (KYB) is being built as one shared platform ("One SEAL") across nine modules, in a
monorepo, so that a new module doesn't have to stand up its own CI/CD pipeline, environments, auth
integration, and administrative review process from zero. Branch Health is the first module being built.

## Decision

For MVP1, Branch Health is delivered as a module inside the KYB monorepo/platform (shared Terraform,
shared GitHub Actions, shared base Kubernetes namespace conventions), not as an independently
provisioned product with its own platform team overhead.

## Alternatives considered

- **Standalone Branch Health platform**, provisioned independently. Rejected for MVP1 — duplicates
  environment/CI/CD/security-review setup before the underlying product is validated with a pilot group,
  and works against the explicit "One SEAL" decision for KYB.

## Consequences

- `infrastructure/` in this repository describes Branch Health's module-level Terraform/Helm, which
  composes into the shared KYB platform rather than provisioning a new one.
- Branch Health's `constitution.md`-equivalent standards must stay consistent with the platform-wide KYB
  constitution so other modules (Branch Virtual Tour next, then the remaining seven) can be built the same
  way.

## Review date

Revisit if Branch Health's traffic/scaling profile diverges enough from the rest of KYB to justify
independent infrastructure — not expected before pilot.
