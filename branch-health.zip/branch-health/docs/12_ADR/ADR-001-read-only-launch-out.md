# ADR-001: Branch Health is read-only; every widget launches out to the system of record

**Status:** Accepted
**Date:** 2026-04-23

## Context

Across ~40 banker interviews (garage branches, personal interviews, and a multi-market/multi-region
group session), the single strongest and most consistent piece of feedback was that branch managers do
not want to resolve anything inside Branch Health. When asked directly about control exceptions, they
said they want to *see* that there are 2 due today, then click through to Branch Dashboard to actually
resolve them. Tickets in ICSC are the sharpest example: bankers explicitly said "don't list tickets here,
give us a place to go see them."

## Decision

Branch Health is a visibility layer only. No widget contains a form, an approval action, or any mutation.
Every card's only interaction is: show a count/status → click → deep-link to the owning application.

## Alternatives considered

- **Embed resolution flows** (e.g., resolve a control exception inline). Rejected — directly contradicts
  user research, and would require Branch Health to duplicate business logic and authorization already
  owned by Branch Dashboard, My Cash Manager, etc.
- **Partial actions** (e.g., snooze/acknowledge only). Rejected for MVP1 — adds state Branch Health would
  own without a clear upstream owner; revisit post-pilot if bankers ask for it.

## Consequences

- Every widget spec in `api/openapi.yaml` includes a `destinationUrl` and no widget exposes a write
  endpoint.
- Simplifies MVP1 security model — Branch Health only needs read scopes against upstream systems.
- If bankers request lightweight actions after the pilot, that is a new ADR, not a reinterpretation of
  this one.

## Review date

Revisit after MVP1 pilot feedback (Milestone 9).
