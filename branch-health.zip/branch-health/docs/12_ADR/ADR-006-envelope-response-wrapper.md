# ADR-006: API responses use a `{data, metadata}` envelope with structured errors (RFC 9457)

**Status:** Accepted
**Date:** 2026-04-23

## Context

Two conventions existed in earlier drafts: a flat JSON response body, and an enveloped
`{data, metadata}` wrapper with a structured error model. The KYB platform-wide `constitution.md`
(binding across all nine KYB modules) standardizes on the envelope wrapper.

## Decision

Every `api/openapi.yaml` response uses:

```json
{
  "data": { "...": "the actual payload" },
  "metadata": { "requestId": "...", "generatedAt": "...", "cacheAge": "..." }
}
```

Errors use RFC 9457 Problem Details (`type`, `title`, `status`, `detail`, `instance`), catalogued in
`docs/04_Engineering` (Document 408 – Error Catalog) with Branch-Health-specific codes prefixed `BH-`.

## Alternatives considered

- **Flat JSON response** (data fields at the top level, no wrapper). Rejected — inconsistent with the
  platform-wide `constitution.md` used by every other KYB module, which would fragment client codegen and
  error handling across the platform.

## Consequences

- This is a platform-wide standard, not a Branch-Health-only choice — it must not be re-litigated per
  module.
- Frontend `services/api.ts` unwraps `.data` once, centrally, so widget components never deal with the
  envelope directly.

## Review date

N/A — platform-wide standard; changes go through the KYB `constitution.md`, not a Branch Health ADR.
