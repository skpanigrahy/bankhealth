# ADR-005: Backend is organized service-per-capability, not one monolith service

**Status:** Accepted
**Date:** 2026-04-23

## Context

Branch Health has six independent data domains (Required Actions, Meetings, Tech Readiness, Performance,
Nearby Branches) each backed by different upstream systems with different owners, cadences, and failure
modes (see `ARCHITECTURE.md` widget → source map). A single monolith service would couple their release
cycles and make a slow/unreliable upstream (e.g., ATM Reporting) able to degrade unrelated widgets
(e.g., Performance).

## Decision

`backend/` contains one Spring Boot module per capability (`dashboard-service`, `actions-service`,
`meetings-service`, `tech-readiness-service`, `performance-service`, `nearby-service`,
`integration-service`, plus `shared-kernel` for common domain types). `dashboard-service` composes the
others behind the single `GET /api/v1/dashboard` contract so the frontend still makes one call.

## Alternatives considered

- **Single monolith service.** Rejected — couples unrelated widgets' failure/release cycles.
- **Fully independent microservices called directly by the frontend (no aggregation).** Rejected for
  MVP1 — would mean 6+ round trips from the browser and 6+ places to handle partial failure in the UI;
  the aggregation service absorbs that complexity once, server-side.

## Consequences

- `dashboard-service` is the only service the frontend talks to directly.
- Each capability service owns its own cache tables/rows and refresh job; a failure in one produces a
  "partial data" state for its widget only, not a failed dashboard load.

## Review date

Revisit if operational data shows the aggregation hop itself becomes the bottleneck.
