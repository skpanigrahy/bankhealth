# ADR-003: MVP1 is scoped to the Branch Manager persona only

**Status:** Accepted
**Date:** 2026-04-23

## Context

Discovery covered Branch Managers, Market Directors, and Regional Directors. Roughly 340 branch managers
oversee more than one branch (one oversees three); everyone else manages a single branch. Market
Directors and Regional Directors need a *rolled-up* view across many branches, not a single-branch
dashboard with a location switcher — that's a materially different information architecture (aggregation,
comparison, drill-down), not a reskin of this screen.

## Decision

MVP1 ships the single-branch (or "my few branches, pick one") experience for Branch Managers only. The
header includes a location switcher only for the small number of managers with more than one branch,
defaulting to their primary/current branch. Market Director and Regional Director rollup views are a
separate, later persona and are **not** a phase of this same screen.

## Alternatives considered

- **One dashboard, role-aware widgets.** Rejected — the Market/Regional Director need (compare N
  branches) is structurally different from the Branch Manager need (manage 1 branch today), and
  conflating them would compromise the Branch Manager experience research validated.

## Consequences

- No cross-branch visibility in MVP1, even for managers who cover more than one branch, beyond switching
  which single branch they're looking at. Bankers were explicit they don't want to see other branches'
  data by default.
- `GET /api/v1/dashboard?branchId=` always returns exactly one branch's data.
- Market/Regional Director rollup is tracked in `docs/14_Backlog`, not `docs/13_ProjectManagement`
  milestones for MVP1.

## Review date

Revisit once Market/Regional Director discovery is scoped as its own initiative.
