# ADR-002: Cached aggregation on a per-source cadence, not live calls per page view

**Status:** Accepted
**Date:** 2026-04-23

## Context

The dashboard aggregates data from ~9 upstream systems (Branch Dashboard, My Cash Manager, Client
Central, Splunk, Cortex, ATM Reporting, Branch Location Data Store, Banker Homepage, Performance
Homepage). Calling all of them synchronously on every page load would be slow, fragile, and expensive to
operate. Engineering discussion (see meeting transcript, engineering segment) explicitly weighed "call
APIs live on click" vs. "periodic pull at a real-time-feeling interval, cached, and served from cache
during navigation" and preferred the latter, leveraging the same approach already used on the Splunk side.

## Decision

Each upstream source is pulled on its own cadence (15 minutes / daily / weekly / monthly, see
`docs/04_Engineering` and `database/schema/schema.sql: refresh_history`) into a local cache. The
Dashboard Aggregation API (`GET /api/v1/dashboard`) always reads from cache; it does not fan out to
upstream systems synchronously. A manual "Refresh" action re-triggers the relevant scheduled job rather
than bypassing the cache.

Cadence is driven by how often *new* items actually arrive from each source, not by how "real-time" the
UI needs to feel:

| Source | New items arrive | Therefore cadence |
| --- | --- | --- |
| Branch Dashboard, Client Central, Splunk, Cortex, ATM Reporting, Banker Homepage, Branch Location Data Store | Continuously through the day | 15 minutes |
| Cash Management | Overnight batch | Daily (only need to check for completions during the day) |
| ICSC | Once per month, due by the 25th | Monthly |
| Performance Homepage (OSAT, Convenience, One Chase Sales) | Weekly/monthly reporting cycle | Weekly |

## Alternatives considered

- **Live call per page view.** Rejected — 9-system fan-out on every load is slow and turns a partial
  upstream outage into a broken dashboard.
- **Real-time streaming/webhooks from every upstream system.** Rejected for MVP1 — most sources don't
  support it, and it isn't needed given the cadences above; revisit only if a specific widget genuinely
  needs sub-minute freshness.

## Consequences

- `dashboard_cache` / `widget_cache` tables are required even though Branch Health has no other
  persistence needs (see `database/schema/schema.sql`).
- A scheduler/refresh engine (`docs/04_Engineering`) is a first-class MVP1 component, not an
  optimization added later.
- Widgets must define an explicit "offline cache" / "partial data" UI state, since the UI can legitimately
  show data that is up to 15 minutes (or a day, week, month) old.

## Review date

Revisit once Tim/Kevin's network-quality (packet loss, NPL) work lands and could justify a different
cadence for Tech Readiness specifically.
