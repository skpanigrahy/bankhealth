# API

Human-readable companion to ../../api/openapi.yaml. If this text and the YAML ever disagree, the YAML wins (see ../00_INDEX.md).
