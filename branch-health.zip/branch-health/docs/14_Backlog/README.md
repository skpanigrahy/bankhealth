# Backlog — explicitly out of MVP1

Captured so nobody re-derives these debates mid-sprint. Pull into a milestone only via a new/updated ADR.

- Telephony/queue status widget (raised in UX research, no committed data source)
- Market Director / Regional Director rollup views (see ADR-003)
- Notary and drive-up-specific availability indicators
- In-app resolution of Control Exceptions / ICSC tickets / Cash Management items (see ADR-001)
- Manual per-widget "Discover Needs" recommendation engine — only the launch link ships in MVP1
- Live/on-demand upstream calls in place of the cached refresh model (see ADR-002)
- Push notifications / proactive alerts (dashboard is pull/visit-based in MVP1)
- Agentic AI / RAG assistant surfaced inside Branch Health (platform-level, later phase — see
  `../../../` KYB memory: "Agentic AI/RAG planned for a later phase")
