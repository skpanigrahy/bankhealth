# Master Architecture Index

Read in this order. This index is the tie-breaker when two documents disagree.

| # | Document | Answers | Source of truth for |
| --- | --- | --- | --- |
| 1 | `../README.md` | What are we building and why | Product boundaries |
| 2 | `../ARCHITECTURE.md` | How is the system shaped | System topology, widget → source map |
| 3 | `01_Product/` | Charter, PRD, BRS | Business requirements |
| 4 | `02_UX/` | Approved Figma / screenshots, UX research findings | Visual design, interaction rules |
| 5 | `03_Architecture/` | Detailed technical design | Non-functional requirements |
| 6 | `12_ADR/` | Why decisions were made this way | Rationale — **wins over any prose that contradicts a decision here** |
| 7 | `../api/openapi.yaml` | Exact request/response contracts | **API behavior — wins over any prose description of an endpoint** |
| 8 | `../database/schema/schema.sql` | Exact persistence model | **Schema — wins over any prose description of a table** |
| 9 | `07_Integrations/` (and `../integrations/*`) | How each upstream system is called | Integration contracts |
| 10 | `04_Engineering/` | Refresh/scheduler behavior, error handling | Operational behavior |
| 11 | `14_Backlog/` | What's explicitly deferred past MVP1 | Scope exclusions |

## Precedence rule

If a narrative document (Charter, PRD, this index's own prose, a meeting summary) conflicts with
`api/openapi.yaml` or `database/schema/schema.sql`, **the contract/schema wins**. Narrative documents
describe intent; contracts describe the executable truth. Update the narrative doc to match the contract,
not the other way around.

## Folder contents

- `01_Product` — Project Charter, PRD, BRS (ported from `Phase1-Document_001/002/003`)
- `02_UX` — AI-First Functional & UX Specification, approved screenshots, UX research findings (ported from `Phase_2`)
- `03_Architecture` — high-level architecture notes
- `04_Engineering` — Engineering Specification, scheduler/refresh design (ported from `Phase3`)
- `05_API` — human-readable companion to `api/openapi.yaml` (never the source of truth)
- `06_Database` — human-readable companion to `database/schema/schema.sql`
- `07_Integrations` — narrative integration notes; contracts live in `../integrations/*`
- `08_DevOps` — CI/CD, environments
- `09_Testing` — test strategy
- `10_Security` — security model (auth, RBAC, branch-level authorization)
- `11_AI` — links to `../ai/` context and prompts
- `12_ADR` — Architecture Decision Records (ported from `Phase_5`)
- `13_ProjectManagement` — roadmap, milestones
- `14_Backlog` — everything explicitly out of MVP1
- `15_Reference` — glossary, source-system directory
