# Engineering

Engineering Specification (Phase 3) plus Documents 401-411 (data dictionary, widget specs, integration specs, DB design, scheduler, security, error catalog, telemetry, config, sequence diagrams) from Phase 4 - Detailed Technical Design.
