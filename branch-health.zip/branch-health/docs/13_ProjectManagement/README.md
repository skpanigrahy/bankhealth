# Roadmap & milestones

See `../../Branch_Health_MVP1_Enterprise_Repository (Version 1.0)` source material for full milestone
detail. Summary:

1. Platform Foundation — repo, backend skeleton, frontend skeleton, CI/CD, auth, design system
2. Dashboard Framework — layout, navigation, routing, header
3. Required Actions — first complete vertical slice
4. Today's Meetings
5. Tech Readiness
6. Performance
7. Nearby Branches
8. Integration Hardening
9. Pilot Release
10. Production Release

Branch Health ships first; Branch Virtual Tour is next (same team); remaining seven KYB modules may start
in parallel with separate teams after that.
