# Database

Human-readable companion to ../../database/schema/schema.sql. If this text and the SQL ever disagree, the SQL wins.
