# UX

Approved UX design (see project screenshots) and the AI-First Functional & UX Specification (Phase 2). Source of truth for visual/interaction design — frontend/ implements this.
