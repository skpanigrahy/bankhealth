# Architecture

High-level architecture notes. See ../../ARCHITECTURE.md for the current diagram; this folder holds supporting detail as it's written.
