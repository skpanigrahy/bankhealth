# Know Your Branch (KYB)

One SEAL enterprise platform. Read `constitution.md` before touching anything else — it is binding for every module and every AI coding agent (Copilot, Claude Code) working in this repo.

## Where things stand

| Module | Status | Owner |
|---|---|---|
| Branch Health | **Active — Sprint 0 in progress** | starting team |
| Branch Virtual Tour | Planned, next | same team, after Branch Health |
| Branch Analytics, Branch Inventory, Branch Events, Branch Personas, Submit Branch Feedback, Search Branches, Data Workspace | Stub only | TBD — may start in parallel |

## Start here

- **Engineers/AI agents working on Branch Health:** `modules/branch-health/specify.md` → `plan.md` → `tasks.md`, in that order. Work through `tasks.md` one item at a time.
- **Local dev environment:** `docker-compose -f infra/docker-compose.yml up`
- **Shared contracts every module must honor:** `platform/shared-domain/`, `platform/event-schema-registry/`
- **Starting a new module:** copy the three-file pattern (`specify.md`/`plan.md`/`tasks.md`) from `modules/branch-health/`, and read `constitution.md` §3 and §7 first.

## Methodology

Spec-Driven Development (SDD) inside a standard Agile/sprint cadence. See `constitution.md` §6 for the loop. Specs are the source of truth; code is generated and verified against them, not the other way around.
