# Module: Branch Health — plan.md

**Depends on:** `specify.md` (this module), `constitution.md`, `platform/shared-domain/branch.schema.json`, `platform/event-schema-registry/`

## 1. Service

`kyb-branch-health-service` — Spring Boot 3 / Java 21, package root `com.kyb.branchhealth`, following the layered structure mandated in `constitution.md` §5:

```
com.kyb.branchhealth
├── api            (BranchHealthController, request/response DTOs)
├── application    (BranchHealthScoreService, mappers, validators)
├── domain         (HealthScore, ScoreCalculator, domain events)
├── infrastructure (JPA repositories, Kafka producers, mock-telemetry seed loader)
├── security       (RBAC filters — branch/region scoping)
└── config
```

## 2. Data Model (module-owned, in `branch_health` Postgres schema)

```sql
CREATE SCHEMA IF NOT EXISTS branch_health;

CREATE TABLE branch_health.health_score (
    branch_id        UUID PRIMARY KEY,          -- FK reference to kyb_shared.branch, not a local copy
    current_score     NUMERIC(5,2) NOT NULL,
    network_score      NUMERIC(5,2) NOT NULL,
    device_score       NUMERIC(5,2) NOT NULL,
    application_score  NUMERIC(5,2) NOT NULL,
    incident_score      NUMERIC(5,2) NOT NULL,
    status            VARCHAR(16) NOT NULL,      -- HEALTHY | DEGRADED | CRITICAL
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE branch_health.health_score_history (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    branch_id     UUID NOT NULL,
    score        NUMERIC(5,2) NOT NULL,
    recorded_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_health_history_branch_time ON branch_health.health_score_history (branch_id, recorded_at DESC);
```

`branch_id` is never duplicated with Branch's own fields (name, address, etc.) — those are fetched from the shared Branch read API, per constitution §7 ("no module writes directly to another module's schema" — this cuts both ways: Branch Health doesn't duplicate Branch's data either).

## 3. API (OpenAPI 3.1, contract-first — write the spec before the controller)

Base path per constitution §4: `/api/v1/branch-health`

```
GET  /api/v1/branch-health/summary
     → executive rollup: total branches, avg score, degraded count

GET  /api/v1/branch-health/branches
     → list view, scoped by caller's role (all / region / own branch)
     query params: region, status, page, size

GET  /api/v1/branch-health/branches/{branchId}
     → detail: current score, breakdown, 7-day trend, active incidents
     403 if caller not authorized for this branch (AC-4)

POST /api/v1/branch-health/branches/{branchId}/recalculate
     → dev/ops-only, forces recalculation (for testing; not in production UI)
```

Full OpenAPI YAML to be generated in `modules/branch-health/backend/api/openapi.yaml` as the first implementation task.

## 4. Score Calculation

`ScoreCalculator` (domain layer, pure function, no I/O — easiest thing to unit test per AC-1):

```
score = (network * 0.25) + (device * 0.25) + (application * 0.25) + (incidentPenalty * 0.25)
status = score >= 85 ? HEALTHY : score >= 70 ? DEGRADED : CRITICAL
```
Weights read from config (`application.yml`), not hardcoded, so they can be tuned without redeploying logic.

## 5. Events

On every recalculation: publish `kyb.branch-health.score.updated.v1` always; publish `branch.degraded.v1` / `branch.recovered.v1` only on a status transition (not every tick) — implemented via a state-diff check against the previous stored value.

## 6. Sprint 0 Telemetry Source

Real integrations (Splunk, Dynatrace, ServiceNow, device/network feeds) are out of scope per `specify.md`. Sprint 0 uses a seed loader (`infrastructure/seed/MockTelemetrySeeder`) that inserts realistic random-walk telemetry for N seeded branches on startup — shaped identically to what the real integration will eventually send, so swapping the source later doesn't change the domain layer.

## 7. Frontend

`modules/branch-health/frontend/` — React + TS + Vite, consuming `platform/design-system` for cards/charts/tables. Two routes for Sprint 0: `/branch-health` (executive/list view) and `/branch-health/:branchId` (detail view). Role-based rendering reads the authenticated user's scope from `platform/auth`.

## 8. Local Dev

`infra/docker-compose.yml` (created alongside this plan) brings up Postgres, Kafka, Redis, and the service — see that file for the one-command local environment.
