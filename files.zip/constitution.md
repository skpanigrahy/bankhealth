# Know Your Branch (KYB) — Platform Constitution

**Status:** v1.0 — Ratified for Branch Health module kickoff
**Owner:** Platform Architecture (currently: Branch Health team, until a dedicated platform team is staffed)
**Applies to:** every module under KYB, every engineer, every AI coding agent (Copilot, Claude Code) working in this repo

> This file is the single source of truth for platform-wide rules. Module-level `specify.md` / `plan.md` / `tasks.md` files MUST NOT contradict this document. If a module needs an exception, it is raised as an ADR (see §8), not silently worked around.

---

## 1. Architecture Model: One SEAL

KYB is **one platform**, not nine independent products that happen to share a name. Concretely, this means:

- There is exactly **one** identity/auth system, **one** API gateway, **one** design system, **one** event bus, **one** deployment pipeline family, and **one** canonical copy of every shared entity (Branch, Employee, Device, Incident).
- No module may stand up its own auth, its own component library, its own "Branch" table, or its own event bus. If a module believes it needs to, that is an ADR, not a local decision.
- Modules are **bounded contexts** (Domain-Driven Design) — they own their own business logic and their own module-specific data, but they consume shared entities and shared infrastructure through contracts defined in `/platform`, never by copying or re-deriving them.

## 2. Repository Topology

Monorepo. One repo, module-isolated folders, shared CI/CD.

```
knowyourbranch/
├── constitution.md              # this file
├── platform/                    # shared kernel — contracts + minimal shared implementation
│   ├── shared-domain/           # canonical entities: Branch, Employee, Device, Incident
│   ├── event-schema-registry/   # Kafka topic + event schema contracts
│   ├── design-system/           # shared tokens + components
│   ├── auth/                    # identity, session, RBAC
│   └── api-gateway/             # routing, versioning, rate limiting config
├── modules/
│   ├── branch-health/           # ACTIVE — first module, also bootstraps /platform
│   ├── branch-virtual-tour/     # PLANNED — same team, next
│   ├── branch-analytics/        # STUB — future team
│   ├── branch-inventory/        # STUB — future team
│   ├── branch-events/           # STUB — future team
│   ├── branch-personas/         # STUB — future team
│   ├── submit-branch-feedback/  # STUB — future team
│   ├── search-branches/         # STUB — future team
│   └── data-workspace/          # STUB — future team
├── docs/                        # cross-module architecture docs, ADRs
└── infra/                       # Terraform, k8s manifests, docker-compose
```

Each module under `modules/` is self-contained (`backend/`, `frontend/`, `docs/`, `specify.md`, `plan.md`, `tasks.md`) and may only import from `platform/`, never from another module directly. Cross-module needs go through published APIs or events — never direct DB or code access.

## 3. Shared Kernel Policy: Formal Contract, Minimal Implementation

For every piece of `/platform`, the **contract** (schema, interface, naming convention) must be complete enough that a module starting a year from now doesn't need to renegotiate it. The **implementation** should only cover what the current module(s) actually need. Exception: **auth is implemented for real from day one** — it is the one piece of the platform that is genuinely expensive to retrofit later.

| Shared kernel piece | Contract now | Implementation now |
|---|---|---|
| Shared entities | Full schema, superset of known future needs | Fields the active module populates |
| Event registry | Naming + versioning convention, schema format | Only events the active module publishes |
| Auth | — | Real OAuth2/OIDC, built now |
| Design system | Token contract (spacing, color, type) | Only components the active module needs |
| API gateway | Routing + versioning convention | Routes for the active module only |

## 4. Naming Conventions

- **Services:** `kyb-{module}-service` (e.g. `kyb-branch-health-service`)
- **API base path:** `/api/v1/{module}/...` (e.g. `/api/v1/branch-health/dashboard`)
- **Kafka topics:** `kyb.{module}.{entity}.{action}.v{n}` (e.g. `kyb.branch-health.score.updated.v1`)
- **Database schemas:** one Postgres schema per module (`branch_health`, `branch_inventory`, ...); shared entities live in a `kyb_shared` schema owned by the platform, not by any module
- **React module folders:** `modules/{module}/frontend/src/` mirrors the module name exactly — no abbreviations

## 5. Technology Stack (locked — do not deviate without an ADR)

| Layer | Technology |
|---|---|
| Frontend | React + TypeScript + Vite |
| UI | Tailwind CSS + shared design system in `platform/design-system` |
| Backend | Java 21 + Spring Boot |
| API style | REST, OpenAPI 3.1 contract-first |
| Messaging | Kafka |
| Cache | Redis |
| Database | PostgreSQL (Aurora in AWS) |
| Search | OpenSearch |
| AI/Agentic | RAG over curated read models; multi-agent orchestration per domain (see `docs/ai-architecture.md`) |
| Observability | OpenTelemetry + Prometheus + Grafana; logs to Splunk |
| Containers/Orchestration | Docker + Kubernetes |
| IaC | Terraform |
| CI/CD | GitHub Actions |

## 6. Development Methodology: Spec-Driven, inside standard Agile cadence

Every module follows this loop, sized to sprints, not the whole module at once:

```
specify.md  → what & why, acceptance criteria, no tech talk
plan.md     → technical approach: schema, APIs, services touched
tasks.md    → atomic, independently verifiable implementation steps
implement   → AI agent (Copilot/Claude) + engineer generate code against tasks.md
verify      → every task checked against its acceptance criteria before merge
```

AI coding agents (Copilot, Claude Code) MUST read this constitution and the relevant module's `specify.md`/`plan.md`/`tasks.md` before generating code. Do not accept agent-generated code that contradicts this file.

## 7. Non-Negotiables (forbidden patterns)

- No module writes directly to another module's database schema.
- No module bypasses the API gateway to call another module's service directly.
- No secrets or credentials in prompts, code comments, or committed config — use the secrets manager.
- No new UI component library introduced outside `platform/design-system` without an ADR.
- No AI agent given unrestricted production data access — AI reads through curated, access-controlled read models only (RAG pattern, see `docs/ai-architecture.md`).
- No breaking change to a shared entity schema or event contract without a version bump and a deprecation window.

## 8. Architecture Decision Records (ADRs)

Any deviation from this constitution, or any significant new platform-wide decision, is recorded in `docs/adr/ADR-NNN-title.md` and referenced here once accepted. Initial ADRs:

- **ADR-001** — One SEAL architecture adopted over Two SEAL.
- **ADR-002** — Monorepo topology for KYB.
- **ADR-003** — Domain-Driven Design for module/service decomposition.
- **ADR-004** — Event-driven integration via Kafka as the default cross-module communication pattern.
- **ADR-005** — Spec-Driven Development as the AI-assisted build methodology.

## 9. Amendment Process

This document changes only through an accepted ADR reviewed by whoever holds the Architecture Review Board role at the time (see Volume 1 §26.15 of the original enterprise blueprint). Module teams may propose amendments; they may not unilaterally act against this file.
