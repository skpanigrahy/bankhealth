# Module: Branch Health — specify.md

**Status:** Draft — Sprint 0 scope
**Depends on:** `constitution.md`, `platform/shared-domain/branch.schema.json`

## 1. Purpose

Give every branch stakeholder — executive, regional manager, branch manager, ops/support engineer — a single real-time view of a branch's operational health, replacing the current state of switching between Splunk, Dynatrace, ServiceNow, and telephony tools.

## 2. Users & Their Jobs-to-be-Done

| Persona | Job to be done |
|---|---|
| Executive | See health across the whole network at a glance; know which regions/branches need attention |
| Regional Manager | Compare branches under their region; spot outliers |
| Branch Manager | See their branch's current health, active incidents, and what's degrading it |
| Ops/Support Engineer | Drill from a health signal down to the root telemetry (network, device, app) fast enough to act |

## 3. Scope — Sprint 0 (this walking skeleton)

In scope:
- A single **Branch Health Score** (0–100) computed from network, device, application, and incident signals for one branch.
- **Executive summary view**: total branches, average health score, count of degraded branches.
- **Branch detail view**: current score, trend (7-day), contributing factors, active incidents.
- Health score recalculation triggered on incoming telemetry (mocked/seeded for Sprint 0, not live integrations yet).
- Publish `kyb.branch-health.score.updated.v1` and `kyb.branch-health.branch.degraded.v1` / `...recovered.v1` events.

Explicitly out of scope for Sprint 0 (later sprints):
- Live integration with Splunk/Dynatrace/ServiceNow (Sprint 0 uses seeded mock telemetry matching real shapes)
- IVR Analytics sub-dashboard (separate specify.md once Branch Health core is proven)
- AI Assistant / RAG explanations ("why is this branch unhealthy")
- Branch Virtual Tour integration

## 4. Functional Requirements

1. System computes a Branch Health Score per branch from weighted signals: Network (25%), Device (25%), Application (25%), Open Incidents (25%) — weights configurable, not hardcoded.
2. Score updates trigger a domain event; a score crossing below 70 triggers `branch.degraded`, crossing back above 70 triggers `branch.recovered`.
3. Executive view lists all branches with score, trend arrow, and status badge (Healthy / Degraded / Critical).
4. Branch detail view shows: current score, 7-day trend chart, breakdown by contributing domain, list of active incidents linked to this branch.
5. All views respect role-based access — a Branch Manager sees only their assigned branch(es); Regional Manager sees their region; Executive sees all.

## 5. Acceptance Criteria (per requirement, testable)

- **AC-1:** Given seeded telemetry for a branch with network=90, device=80, app=95, incidents=60, the computed score equals the weighted average (within rounding), and this is covered by a unit test.
- **AC-2:** Given a score drop from 75 to 65, a `kyb.branch-health.branch.degraded.v1` event is published exactly once, matching the registered schema.
- **AC-3:** Executive view loads and renders all seeded branches within 2s for a dataset of 500 branches (perf budget, not final NFR).
- **AC-4:** A Branch Manager user querying another branch's detail view receives 403, verified by an integration test.
- **AC-5:** Health score and event payloads validate against `platform/event-schema-registry/branch-health.score.updated.v1.json` — a schema validation test is part of CI, not manual review.

## 6. Explicitly Not Deciding Here

Technical approach (schema, service boundaries, API shapes) is deferred to `plan.md` — this file stays implementation-agnostic per SDD convention.
