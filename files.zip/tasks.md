# Module: Branch Health — tasks.md

Atomic tasks for Sprint 0. Each task references its acceptance criteria from `specify.md`. This is the file to hand to Copilot/Claude Code one task at a time — do not ask an agent to implement the whole module from `plan.md` directly; step through this list.

## Platform bootstrap (blocks everything else)

- [ ] **T0.1** — Create `kyb_shared` Postgres schema + `branch` table from `platform/shared-domain/branch.schema.json`. Seed 500 mock branches.
- [ ] **T0.2** — Stand up `infra/docker-compose.yml`: Postgres, Kafka (+ Zookeeper or KRaft), Redis, adminer/kafka-ui for local inspection.
- [ ] **T0.3** — Minimal `platform/auth`: JWT-based auth stub with 3 seeded roles (EXECUTIVE, REGIONAL_MANAGER, BRANCH_MANAGER) and branch/region scoping claims.
- [ ] **T0.4** — Minimal `platform/design-system`: design tokens (spacing, color, type) + Card, Table, Badge, TrendChart components.

## Backend — kyb-branch-health-service

- [ ] **T1.1** — Scaffold Spring Boot service per package structure in `plan.md` §1.
- [ ] **T1.2** — Write `openapi.yaml` for all 4 endpoints in `plan.md` §3 before writing controllers.
- [ ] **T1.3** — Implement `branch_health` schema migration (Flyway) from `plan.md` §2.
- [ ] **T1.4** — Implement `ScoreCalculator` (pure domain function) + unit test → satisfies **AC-1**.
- [ ] **T1.5** — Implement `MockTelemetrySeeder` generating realistic random-walk signals for seeded branches.
- [ ] **T1.6** — Implement recalculation flow: compute score → persist → diff against previous status → conditionally publish `branch.degraded`/`branch.recovered` → always publish `score.updated`. Integration test → satisfies **AC-2**.
- [ ] **T1.7** — Implement `GET /summary` and `GET /branches` with RBAC scoping. Integration test for cross-branch 403 → satisfies **AC-4**.
- [ ] **T1.8** — Implement `GET /branches/{branchId}` detail endpoint including 7-day trend from `health_score_history`.
- [ ] **T1.9** — CI step: validate every published event payload against its registered JSON schema → satisfies **AC-5**.
- [ ] **T1.10** — Load test `GET /branches` at 500 seeded branches, assert <2s → satisfies **AC-3**.

## Frontend — branch-health

- [ ] **T2.1** — Scaffold Vite + React + TS app under `modules/branch-health/frontend/`, wired to `platform/design-system`.
- [ ] **T2.2** — Executive/list view: branch table with score, trend arrow, status badge; consumes `GET /summary` + `GET /branches`.
- [ ] **T2.3** — Branch detail view: score breakdown, 7-day trend chart, active incidents list; consumes `GET /branches/{branchId}`.
- [ ] **T2.4** — Role-based view rendering wired to `platform/auth` session claims.
- [ ] **T2.5** — Loading, empty, and error states for both views (constitution §5 UX standard — do not skip).

## Verification (before this sprint is called done)

- [ ] **T3.1** — All AC-1 through AC-5 have a passing automated test, not manual verification.
- [ ] **T3.2** — `constitution.md` §7 non-negotiables checked: no direct cross-schema writes, no bypassed gateway, no hardcoded secrets.
- [ ] **T3.3** — `platform/event-schema-registry/README.md` updated if any new event was introduced beyond the two already registered.
