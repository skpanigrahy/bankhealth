import { Card, KPI, ProgressBar } from '../components/ui'
import { branches } from '../data/mockData'
import { PhoneCall, TrendingUp, Percent, Clock } from 'lucide-react'

export default function IVRAnalytics() {
  const avgC = Math.round(branches.reduce((s, b) => s + b.ivrContainment, 0) / branches.length)
  const totalCalls = branches.reduce((s, b) => s + b.calls, 0)
  const totalT = branches.reduce((s, b) => s + b.ivrTransfers, 0)
  const avgW = (branches.reduce((s, b) => s + b.waitTime, 0) / branches.length).toFixed(1)
  return (
    <div style={{ padding: 24 }}>
      <div className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4" style={{ gap: 12 }}>
          <KPI icon={<Percent style={{ width: 18, height: 18 }} />} label="Avg Containment" value={`${avgC}%`} />
          <KPI icon={<PhoneCall style={{ width: 18, height: 18 }} />} label="Daily Calls" value={`${(totalCalls / 1000).toFixed(1)}K`} />
          <KPI icon={<TrendingUp style={{ width: 18, height: 18 }} />} label="IVR Transfers" value={totalT.toLocaleString()} />
          <KPI icon={<Clock style={{ width: 18, height: 18 }} />} label="Avg Wait" value={`${avgW}s`} />
        </div>
        <Card title="IVR Containment by Branch" subtitle="Calls resolved by IVR without agent transfer">
          <div className="space-y-2">
            {[...branches].sort((a, b) => b.ivrContainment - a.ivrContainment).map((b) => (
              <div key={b.id} className="flex items-center gap-3">
                <span className="text-sm text-ink-700 truncate" style={{ width: 200 }}>{b.branch}</span>
                <div className="flex-1"><ProgressBar value={b.ivrContainment} /></div>
                <span className="text-sm font-semibold" style={{ width: 36, textAlign: 'right' }}>{b.ivrContainment}%</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  )
}
