import { Card, KPI, ProgressBar, HealthDot, Badge } from '../components/ui'
import { branches } from '../data/mockData'
import { Link } from 'react-router-dom'

export default function BranchHealth() {
  return (
    <div style={{ padding: 24 }}>
      <div className="space-y-6">
        <Card title="Branch Health Summary" subtitle={`${branches.length} branches across ${new Set(branches.map(b => b.country)).size} countries`}>
          <div className="space-y-3">
            {branches.map((b) => (
              <Link key={b.id} to="/branch-map" className="block">
                <div className="flex items-center gap-4 p-3 rounded-lg hover:bg-ink-50 transition-colors">
                  <HealthDot value={b.health} />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-semibold text-ink-800 truncate">{b.branch}</div>
                    <div className="text-xs text-ink-400">{b.city}, {b.country} · {b.manager}</div>
                  </div>
                  <div style={{ width: 120 }}>
                    <ProgressBar value={b.health} tone={b.health >= 90 ? 'green' : b.health >= 80 ? 'amber' : 'red'} />
                  </div>
                  <span className="text-sm font-bold" style={{ width: 36, textAlign: 'right', color: b.health >= 90 ? 'var(--emerald-600)' : b.health >= 80 ? 'var(--amber-600)' : 'var(--red-600)' }}>{b.health}</span>
                  <Badge tone={b.operatingStatus === 'Open' ? 'green' : 'red'}>{b.operatingStatus}</Badge>
                </div>
              </Link>
            ))}
          </div>
        </Card>
      </div>
    </div>
  )
}
