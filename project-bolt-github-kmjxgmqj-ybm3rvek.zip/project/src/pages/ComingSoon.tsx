import { Card } from '../components/ui'
import type { LucideIcon } from 'lucide-react'
import { Construction } from 'lucide-react'

export default function ComingSoon({ title, icon: Icon }: { title: string; icon?: LucideIcon }) {
  return (
    <div style={{ padding: 24 }}>
      <div style={{ maxWidth: 500, margin: '60px auto', textAlign: 'center' }}>
        <div className="flex items-center justify-center mb-4">
          <div className="rounded-2xl flex items-center justify-center" style={{ width: 80, height: 80, background: 'var(--brand-50)' }}>
            {Icon ? <Icon style={{ width: 36, height: 36, color: 'var(--brand-500)' }} /> : <Construction style={{ width: 36, height: 36, color: 'var(--brand-500)' }} />}
          </div>
        </div>
        <h2 className="text-lg font-bold text-ink-900 mb-2">{title}</h2>
        <p className="text-sm text-ink-400">This module is under development and will be available soon.</p>
      </div>
    </div>
  )
}
