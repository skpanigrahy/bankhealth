import { Card } from '../components/ui'
import { FileBarChart, Download, Calendar } from 'lucide-react'

export default function Reports() {
  const reports = [
    { name: 'Daily Branch Health Summary', schedule: 'Every day at 6:00 AM', lastRun: '2026-07-24 06:00', format: 'PDF' },
    { name: 'Weekly Network Performance', schedule: 'Every Monday at 8:00 AM', lastRun: '2026-07-22 08:00', format: 'Excel' },
    { name: 'Monthly SLA Compliance', schedule: '1st of every month', lastRun: '2026-07-01 09:00', format: 'PDF' },
    { name: 'Quarterly Device Inventory', schedule: 'Every quarter', lastRun: '2026-07-01 10:00', format: 'Excel' },
    { name: 'IVR Containment Weekly', schedule: 'Every Friday at 5:00 PM', lastRun: '2026-07-19 17:00', format: 'CSV' },
  ]
  return (
    <div style={{ padding: 24 }}>
      <div className="space-y-6">
        <Card title="Scheduled Reports" subtitle="Automated and on-demand reporting">
          <div className="space-y-3">
            {reports.map((r, i) => (
              <div key={i} className="flex items-center gap-4 p-3 rounded-lg hover:bg-ink-50 transition-colors">
                <FileBarChart style={{ width: 18, height: 18, color: 'var(--brand-500)' }} />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold text-ink-800">{r.name}</div>
                  <div className="text-xs text-ink-400 flex items-center gap-2"><Calendar style={{ width: 12, height: 12 }} /> {r.schedule} · Last run: {r.lastRun}</div>
                </div>
                <span className="text-xs text-ink-400" style={{ width: 50 }}>{r.format}</span>
                <button className="flex items-center gap-1 text-sm text-brand-600 hover:underline"><Download style={{ width: 14, height: 14 }} /> Download</button>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  )
}
