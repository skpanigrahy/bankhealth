import { Card, KPI, Badge } from '../components/ui'
import { branches } from '../data/mockData'
import { Ticket, CircleAlert as AlertCircle, CircleCheck as CheckCircle2, Clock } from 'lucide-react'

export default function Tickets() {
  const open = branches.reduce((s, b) => s + b.openTickets, 0)
  return (
    <div style={{ padding: 24 }}>
      <div className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4" style={{ gap: 12 }}>
          <KPI icon={<Ticket style={{ width: 18, height: 18 }} />} label="Open Tickets" value={String(open)} />
          <KPI icon={<AlertCircle style={{ width: 18, height: 18 }} />} label="Critical" value="1" />
          <KPI icon={<Clock style={{ width: 18, height: 18 }} />} label="Avg MTTR" value="2.4h" />
          <KPI icon={<CheckCircle2 style={{ width: 18, height: 18 }} />} label="Resolved Today" value="8" />
        </div>
        <Card title="Open Tickets by Branch" subtitle="Active incidents and service requests">
          <div className="space-y-2">
            {branches.filter(b => b.openTickets > 0).sort((a, b) => b.openTickets - a.openTickets).map((b) => (
              <div key={b.id} className="flex items-center gap-4 p-2 rounded-lg hover:bg-ink-50 transition-colors">
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-ink-800 truncate">{b.branch}</div>
                  <div className="text-xs text-ink-400">{b.city}, {b.country}</div>
                </div>
                <Badge tone={b.openTickets >= 10 ? 'red' : b.openTickets >= 6 ? 'amber' : 'green'}>{b.openTickets} open</Badge>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  )
}
