import { Card, KPI, Badge } from '../components/ui'
import { branches } from '../data/mockData'
import { Cpu, CircleAlert as AlertCircle, CircleCheck as CheckCircle2 } from 'lucide-react'

export default function DeviceHealth() {
  const total = branches.reduce((s, b) => s + b.devices, 0)
  const off = branches.reduce((s, b) => s + b.devicesOffline, 0)
  return (
    <div style={{ padding: 24 }}>
      <div className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4" style={{ gap: 12 }}>
          <KPI icon={<Cpu style={{ width: 18, height: 18 }} />} label="Total Devices" value={total.toLocaleString()} />
          <KPI icon={<AlertCircle style={{ width: 18, height: 18 }} />} label="Offline" value={String(off)} />
          <KPI icon={<CheckCircle2 style={{ width: 18, height: 18 }} />} label="Online Rate" value={`${Math.round((1 - off / total) * 100)}%`} />
          <KPI icon={<Cpu style={{ width: 18, height: 18 }} />} label="Avg Health" value="91%" />
        </div>
        <Card title="Device Inventory by Branch" subtitle="ATMs, servers, cameras, POS terminals">
          <div className="space-y-2">
            {branches.map((b) => (
              <div key={b.id} className="flex items-center gap-4 p-2 rounded-lg hover:bg-ink-50 transition-colors">
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-ink-800 truncate">{b.branch}</div>
                  <div className="text-xs text-ink-400">{b.devices} devices · {b.devicesOffline} offline</div>
                </div>
                <Badge tone={b.devicesOffline === 0 ? 'green' : b.devicesOffline <= 2 ? 'amber' : 'red'}>
                  {b.devicesOffline === 0 ? 'All Online' : `${b.devicesOffline} Offline`}
                </Badge>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  )
}
