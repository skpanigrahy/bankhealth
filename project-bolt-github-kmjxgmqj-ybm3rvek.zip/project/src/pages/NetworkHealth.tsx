import { Card, KPI, Badge } from '../components/ui'
import { branches } from '../data/mockData'
import { Network, Wifi, TriangleAlert as AlertTriangle } from 'lucide-react'

export default function NetworkHealth() {
  return (
    <div style={{ padding: 24 }}>
      <div className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4" style={{ gap: 12 }}>
          <KPI icon={<Network style={{ width: 18, height: 18 }} />} label="Network Health" value="94%" delta="1" trend="up" />
          <KPI icon={<Wifi style={{ width: 18, height: 18 }} />} label="Avg Latency" value="28ms" delta="3" trend="down" />
          <KPI icon={<AlertTriangle style={{ width: 18, height: 18 }} />} label="Degraded" value="3" />
          <KPI icon={<Network style={{ width: 18, height: 18 }} />} label="Failed" value="1" />
        </div>
        <Card title="Network Status by Branch" subtitle="Circuit health and latency">
          <div className="space-y-2">
            {branches.map((b) => (
              <div key={b.id} className="flex items-center gap-4 p-2 rounded-lg hover:bg-ink-50 transition-colors">
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-ink-800 truncate">{b.branch}</div>
                  <div className="text-xs text-ink-400">{b.city}, {b.country}</div>
                </div>
                <Badge tone={b.health >= 90 ? 'green' : b.health >= 80 ? 'amber' : 'red'}>{b.health >= 90 ? 'Healthy' : b.health >= 80 ? 'Warning' : 'Critical'}</Badge>
                <span className="text-sm text-ink-500" style={{ width: 60, textAlign: 'right' }}>{20 + (b.id.charCodeAt(3) % 30)}ms</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  )
}
