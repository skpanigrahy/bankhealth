import { Card, KPI, ProgressBar } from '../components/ui'
import { branches } from '../data/mockData'
import { Gauge, TrendingUp, Users, PhoneCall } from 'lucide-react'

export default function Performance() {
  const avgSla = Math.round(branches.reduce((s, b) => s + b.sla, 0) / branches.length)
  const totalCustomers = branches.reduce((s, b) => s + b.customers, 0)
  const totalTxns = branches.reduce((s, b) => s + b.transactions, 0)
  const totalCalls = branches.reduce((s, b) => s + b.calls, 0)
  return (
    <div style={{ padding: 24 }}>
      <div className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4" style={{ gap: 12 }}>
          <KPI icon={<Gauge style={{ width: 18, height: 18 }} />} label="Avg SLA" value={`${avgSla}%`} delta="1" trend="up" />
          <KPI icon={<Users style={{ width: 18, height: 18 }} />} label="Total Customers" value={totalCustomers.toLocaleString()} />
          <KPI icon={<TrendingUp style={{ width: 18, height: 18 }} />} label="Transactions" value={totalTxns.toLocaleString()} />
          <KPI icon={<PhoneCall style={{ width: 18, height: 18 }} />} label="Daily Calls" value={`${(totalCalls / 1000).toFixed(1)}K`} />
        </div>
        <Card title="SLA Compliance by Branch" subtitle="Service level agreement performance">
          <div className="space-y-2">
            {[...branches].sort((a, b) => b.sla - a.sla).map((b) => (
              <div key={b.id} className="flex items-center gap-3">
                <span className="text-sm text-ink-700 truncate" style={{ width: 200 }}>{b.branch}</span>
                <div className="flex-1"><ProgressBar value={b.sla} tone={b.sla >= 95 ? 'green' : 'amber'} /></div>
                <span className="text-sm font-semibold" style={{ width: 36, textAlign: 'right' }}>{b.sla}%</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  )
}
