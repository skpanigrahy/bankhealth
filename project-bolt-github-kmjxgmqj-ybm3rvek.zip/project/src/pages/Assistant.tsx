import { useState } from 'react'
import { Card, Badge } from '../components/ui'
import { Bot, Send, Sparkles } from 'lucide-react'
import { branches } from '../data/mockData'

interface Message { role: 'user' | 'assistant'; text: string }

export default function Assistant() {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', text: 'Hello! I am your Branch Operations AI Assistant. I can help you analyze branch health, investigate incidents, and provide operational insights. Try asking me about any branch or region.' },
  ])
  const [input, setInput] = useState('')

  const send = () => {
    if (!input.trim()) return
    const q = input.toLowerCase()
    let response = ''
    if (q.includes('worst') || q.includes('critical') || q.includes('unhealthy')) {
      const worst = [...branches].sort((a, b) => a.health - b.health)[0]
      response = `The branch with the lowest health score is ${worst.branch} in ${worst.city}, ${worst.country} with a score of ${worst.health}. It has ${worst.openTickets} open tickets, ${worst.devicesOffline} offline devices, and is currently ${worst.operatingStatus}.`
    } else if (q.includes('best') || q.includes('healthiest') || q.includes('top')) {
      const best = [...branches].sort((a, b) => b.health - a.health)[0]
      response = `${best.branch} in ${best.city}, ${best.country} has the highest health score of ${best.health}. All ${best.devices} devices are online, SLA compliance is at ${best.sla}%, and there are only ${best.openTickets} open tickets.`
    } else if (q.includes('country') || q.includes('countries')) {
      const byC: Record<string, number> = {}
      branches.forEach((b) => { byC[b.country] = (byC[b.country] || 0) + 1 })
      response = `We have ${branches.length} branches across ${Object.keys(byC).length} countries:\n` + Object.entries(byC).map(([c, n]) => `• ${c}: ${n} branches`).join('\n')
    } else if (q.includes('ticket') || q.includes('incident')) {
      const total = branches.reduce((s, b) => s + b.openTickets, 0)
      response = `There are ${total} open tickets across all branches. The most affected branch is Kolkata - Park Street with 12 open tickets, including a critical SIP trunk outage.`
    } else if (q.includes('device') || q.includes('offline')) {
      const off = branches.reduce((s, b) => s + b.devicesOffline, 0)
      response = `There are ${off} offline devices across all branches. The most affected branches are Kolkata (4 offline) and Miami (3 offline). Total devices monitored: ${branches.reduce((s, b) => s + b.devices, 0)}.`
    } else {
      response = `I can help you with branch health analysis, incident investigation, device status, network performance, IVR analytics, and more. Try asking about a specific branch, country, or metric.`
    }
    setMessages([...messages, { role: 'user', text: input }, { role: 'assistant', text: response }])
    setInput('')
  }

  return (
    <div style={{ padding: 24 }}>
      <div className="space-y-4" style={{ maxWidth: 800, margin: '0 auto' }}>
        <div className="flex items-center gap-2 mb-4">
          <Bot style={{ width: 20, height: 20, color: 'var(--brand-600)' }} />
          <h2 className="text-lg font-bold text-ink-900">AI Assistant</h2>
          <Badge tone="blue"><Sparkles style={{ width: 12, height: 12 }} /> Powered by Branch Intelligence</Badge>
        </div>
        <Card>
          <div className="space-y-4" style={{ minHeight: 400 }}>
            {messages.map((m, i) => (
              <div key={i} className="flex" style={{ justifyContent: m.role === 'user' ? 'flex-end' : 'flex-start' }}>
                <div className="rounded-lg p-3" style={{ maxWidth: '80%', background: m.role === 'user' ? 'var(--brand-600)' : 'var(--ink-50)', color: m.role === 'user' ? 'white' : 'var(--ink-800)', whiteSpace: 'pre-wrap' }}>{m.text}</div>
              </div>
            ))}
          </div>
          <div className="flex items-center gap-2 mt-4">
            <input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && send()} placeholder="Ask about branch health, incidents, devices…"
              className="flex-1 text-sm rounded-lg px-3 py-2" style={{ border: '1px solid var(--ink-200)', outline: 'none' }} />
            <button onClick={send} className="flex items-center gap-1 text-sm font-medium text-white rounded-lg px-4 py-2" style={{ background: 'var(--brand-600)' }}><Send style={{ width: 14, height: 14 }} /> Send</button>
          </div>
        </Card>
        <div className="flex flex-wrap gap-2">
          {['Which branch has the worst health?', 'How many countries do we operate in?', 'Show me offline devices', 'What are the open tickets?'].map((s, i) => (
            <button key={i} onClick={() => setInput(s)} className="text-xs text-brand-600 rounded-full px-3 py-1.5 hover:bg-brand-50" style={{ border: '1px solid var(--brand-200)' }}>{s}</button>
          ))}
        </div>
      </div>
    </div>
  )
}
