import { Card, Badge, KPI } from '../components/ui'
import { alerts } from '../data/mockData'
import { TriangleAlert as AlertTriangle, Bell, Clock } from 'lucide-react'

export default function Events() {
  return (
    <div style={{ padding: 24 }}>
      <div className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4" style={{ gap: 12 }}>
          <KPI icon={<Bell style={{ width: 18, height: 18 }} />} label="Total Events" value={String(alerts.length)} />
          <KPI icon={<AlertTriangle style={{ width: 18, height: 18 }} />} label="Critical" value={String(alerts.filter(a => a.severity === 'critical').length)} />
          <KPI icon={<AlertTriangle style={{ width: 18, height: 18 }} />} label="High" value={String(alerts.filter(a => a.severity === 'high').length)} />
          <KPI icon={<Clock style={{ width: 18, height: 18 }} />} label="Avg Resolution" value="2.4h" />
        </div>
        <Card title="Event Timeline" subtitle="Recent incidents and alerts">
          <div className="space-y-2">
            {alerts.map((a) => (
              <div key={a.id} className="flex items-start gap-3 p-3 rounded-lg hover:bg-ink-50 transition-colors">
                <AlertTriangle style={{ width: 16, height: 16, marginTop: 2, flexShrink: 0, color: a.severity === 'critical' ? 'var(--red-500)' : a.severity === 'high' ? 'var(--amber-500)' : 'var(--ink-400)' }} />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-ink-800">{a.title}</div>
                  <div className="text-xs text-ink-400">{a.branch} · {a.time}</div>
                </div>
                <Badge tone={a.severity === 'critical' ? 'red' : a.severity === 'high' ? 'amber' : 'neutral'}>{a.severity}</Badge>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  )
}
