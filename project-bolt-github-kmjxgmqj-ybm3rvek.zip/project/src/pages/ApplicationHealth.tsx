import { Card, KPI } from '../components/ui'
import { branches } from '../data/mockData'
import { AppWindow, CircleCheck as CheckCircle2, TriangleAlert as AlertTriangle } from 'lucide-react'

export default function ApplicationHealth() {
  return (
    <div style={{ padding: 24 }}>
      <div className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4" style={{ gap: 12 }}>
          <KPI icon={<AppWindow style={{ width: 18, height: 18 }} />} label="App Uptime" value="99.2%" delta="0.1" trend="up" />
          <KPI icon={<CheckCircle2 style={{ width: 18, height: 18 }} />} label="Healthy Apps" value="24 / 27" />
          <KPI icon={<AlertTriangle style={{ width: 18, height: 18 }} />} label="Degraded" value="3" />
          <KPI icon={<AppWindow style={{ width: 18, height: 18 }} />} label="Avg Response" value="1.8s" />
        </div>
        <Card title="Application Status by Branch" subtitle="Core banking, CRM, and branch applications">
          <div className="space-y-2">
            {branches.map((b) => (
              <div key={b.id} className="flex items-center gap-4 p-2 rounded-lg hover:bg-ink-50 transition-colors">
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-ink-800 truncate">{b.branch}</div>
                  <div className="text-xs text-ink-400">{b.city}, {b.country}</div>
                </div>
                <span className="text-sm font-semibold" style={{ color: b.health >= 90 ? 'var(--emerald-600)' : b.health >= 80 ? 'var(--amber-600)' : 'var(--red-600)' }}>
                  {b.health >= 90 ? 'Healthy' : b.health >= 80 ? 'Degraded' : 'Critical'}
                </span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  )
}
