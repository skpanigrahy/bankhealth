import { Card, KPI } from '../components/ui'
import { branches } from '../data/mockData'
import { Package, Building2 } from 'lucide-react'

export default function Inventory() {
  return (
    <div style={{ padding: 24 }}>
      <div className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4" style={{ gap: 12 }}>
          <KPI icon={<Building2 style={{ width: 18, height: 18 }} />} label="Total Branches" value={String(branches.length)} />
          <KPI icon={<Package style={{ width: 18, height: 18 }} />} label="Total Assets" value={branches.reduce((s, b) => s + b.devices, 0).toLocaleString()} />
          <KPI icon={<Package style={{ width: 18, height: 18 }} />} label="ATMs" value={String(branches.length * 5)} />
          <KPI icon={<Package style={{ width: 18, height: 18 }} />} label="POS Terminals" value={String(branches.length * 15)} />
        </div>
        <Card title="Asset Register" subtitle="Hardware inventory across all branches">
          <div className="space-y-2">
            {branches.map((b) => (
              <div key={b.id} className="flex items-center gap-4 p-2 rounded-lg hover:bg-ink-50 transition-colors">
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-ink-800 truncate">{b.branch}</div>
                  <div className="text-xs text-ink-400">{b.city}, {b.country}</div>
                </div>
                <span className="text-sm text-ink-500" style={{ width: 80, textAlign: 'right' }}>{b.devices} devices</span>
                <span className="text-sm text-ink-500" style={{ width: 80, textAlign: 'right' }}>{b.employees} staff</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  )
}
