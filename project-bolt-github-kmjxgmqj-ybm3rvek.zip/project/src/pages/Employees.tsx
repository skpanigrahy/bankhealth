import { Card, KPI, ProgressBar } from '../components/ui'
import { branches } from '../data/mockData'
import { Users, TrendingUp } from 'lucide-react'

export default function Employees() {
  const total = branches.reduce((s, b) => s + b.employees, 0)
  const avgU = Math.round(branches.reduce((s, b) => s + b.utilisation, 0) / branches.length)
  return (
    <div style={{ padding: 24 }}>
      <div className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4" style={{ gap: 12 }}>
          <KPI icon={<Users style={{ width: 18, height: 18 }} />} label="Total Headcount" value={String(total)} />
          <KPI icon={<TrendingUp style={{ width: 18, height: 18 }} />} label="Avg Utilisation" value={`${avgU}%`} />
          <KPI icon={<Users style={{ width: 18, height: 18 }} />} label="Branches" value={String(branches.length)} />
          <KPI icon={<Users style={{ width: 18, height: 18 }} />} label="Avg Team Size" value={String(Math.round(total / branches.length))} />
        </div>
        <Card title="Employee Utilisation by Branch" subtitle="Headcount and productivity metrics">
          <div className="space-y-2">
            {[...branches].sort((a, b) => b.utilisation - a.utilisation).map((b) => (
              <div key={b.id} className="flex items-center gap-3">
                <span className="text-sm text-ink-700 truncate" style={{ width: 200 }}>{b.branch}</span>
                <span className="text-xs text-ink-400" style={{ width: 50 }}>{b.employees} staff</span>
                <div className="flex-1"><ProgressBar value={b.utilisation} tone={b.utilisation >= 80 ? 'green' : 'amber'} /></div>
                <span className="text-sm font-semibold" style={{ width: 36, textAlign: 'right' }}>{b.utilisation}%</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  )
}
