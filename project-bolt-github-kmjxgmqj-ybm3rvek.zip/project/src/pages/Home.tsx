import { Link } from 'react-router-dom'
import { Chrome as HomeIcon, Search, BarChart3, HeartPulse, Package, CalendarClock, Users, Bot, MessageSquare, MapPin, ArrowRight, TriangleAlert as AlertTriangle, TrendingUp, Building2 } from 'lucide-react'
import { Card, HealthDot } from '../components/ui'
import { branches, alerts } from '../data/mockData'

const modules = [
  { to: '/', label: 'Home', icon: HomeIcon, color: '#3b82f6', bg: '#eff6ff', desc: 'Executive dashboard' },
  { to: '/branch-search', label: 'Search Branches', icon: Search, color: '#8b5cf6', bg: '#f5f3ff', desc: 'Find branches worldwide' },
  { to: '/branch-map', label: 'Geospatial Map', icon: MapPin, color: '#06b6d4', bg: '#ecfeff', desc: 'Interactive world map' },
  { to: '/performance', label: 'Branch Analytics', icon: BarChart3, color: '#10b981', bg: '#ecfdf5', desc: 'Performance & IVR' },
  { to: '/branch-health', label: 'Branch Health', icon: HeartPulse, color: '#ef4444', bg: '#fef2f2', desc: 'Composite health scores' },
  { to: '/inventory', label: 'Branch Inventory', icon: Package, color: '#f59e0b', bg: '#fffbeb', desc: 'Asset register' },
  { to: '/events', label: 'Branch Events', icon: CalendarClock, color: '#6366f1', bg: '#e0e7ff', desc: 'Alerts & incidents' },
  { to: '/employees', label: 'Branch Personas', icon: Users, color: '#ec4899', bg: '#fdf2f8', desc: 'Employees & utilisation' },
  { to: '/assistant', label: 'AI Assistant', icon: Bot, color: '#0ea5e9', bg: '#f0f9ff', desc: 'Conversational intelligence' },
  { to: '/feedback', label: 'Submit Feedback', icon: MessageSquare, color: '#64748b', bg: '#f8fafc', desc: 'Coming soon' },
]

export default function Home() {
  const totalBranches = branches.length
  const avgHealth = Math.round(branches.reduce((s, b) => s + b.health, 0) / totalBranches)
  const criticalAlerts = alerts.filter((a) => a.severity === 'critical').length
  const countries = new Set(branches.map((b) => b.country)).size

  return (
    <div style={{ padding: 24 }}>
      <div className="space-y-6">
        {/* Welcome banner */}
        <div className="card" style={{ background: 'linear-gradient(135deg, var(--brand-600), var(--brand-800))', border: 'none', color: 'white' }}>
          <div className="flex items-center justify-between flex-wrap" style={{ gap: 16 }}>
            <div>
              <h2 className="text-lg font-bold" style={{ marginBottom: 4 }}>Welcome to Know Your Branch</h2>
              <p style={{ fontSize: 13, opacity: 0.85 }}>Monitor and manage {totalBranches} branches across {countries} countries in real time.</p>
            </div>
            <div className="flex items-center" style={{ gap: 24 }}>
              <div className="text-center">
                <div className="text-2xl font-bold">{avgHealth}%</div>
                <div style={{ fontSize: 11, opacity: 0.7 }}>Avg Health</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">{criticalAlerts}</div>
                <div style={{ fontSize: 11, opacity: 0.7 }}>Critical</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">{totalBranches}</div>
                <div style={{ fontSize: 11, opacity: 0.7 }}>Branches</div>
              </div>
            </div>
          </div>
        </div>

        {/* Module launcher grid */}
        <div>
          <h3 className="text-sm font-bold text-ink-700 mb-3">Modules</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-3" style={{ gap: 16 }}>
            {modules.map((m) => (
              <Link key={m.to} to={m.to}>
                <div className="module-card bg-white">
                  <div className="module-card-icon" style={{ background: m.bg }}>
                    <m.icon style={{ width: 24, height: 24, color: m.color }} />
                  </div>
                  <div className="font-bold text-ink-900">{m.label}</div>
                  <div className="text-xs text-ink-400 mt-2">{m.desc}</div>
                  <div className="flex items-center gap-1 text-xs font-semibold mt-4" style={{ color: m.color }}>
                    Open <ArrowRight style={{ width: 12, height: 12 }} />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Quick alerts + branch summary */}
        <div className="grid grid-cols-1 lg:grid-cols-3" style={{ gap: 16 }}>
          <Card title="Active Alerts" subtitle={`${alerts.length} total · ${criticalAlerts} critical`}>
            <div className="space-y-2">
              {alerts.slice(0, 4).map((a) => (
                <div key={a.id} className="flex items-start gap-2 p-2 rounded-lg hover:bg-ink-50 transition-colors">
                  <AlertTriangle style={{
                    width: 14, height: 14, marginTop: 2, flexShrink: 0,
                    color: a.severity === 'critical' ? 'var(--red-500)' : a.severity === 'high' ? 'var(--amber-500)' : 'var(--ink-400)',
                  }} />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-ink-800 truncate">{a.title}</div>
                    <div className="text-xs text-ink-400">{a.time}</div>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card className="lg:col-span-2" title="Branch Health at a Glance" subtitle="Top and bottom performing branches">
            <div className="grid grid-cols-2" style={{ gap: 16 }}>
              <div>
                <div className="text-xs font-semibold text-emerald-600 mb-2">Top 5 Healthiest</div>
                <div className="space-y-2">
                  {[...branches].sort((a, b) => b.health - a.health).slice(0, 5).map((b) => (
                    <div key={b.id} className="flex items-center gap-2">
                      <HealthDot value={b.health} />
                      <span className="text-sm text-ink-700 truncate" style={{ flex: 1 }}>{b.branch}</span>
                      <span className="text-sm font-bold text-emerald-600">{b.health}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <div className="text-xs font-semibold text-red-600 mb-2">Needs Attention</div>
                <div className="space-y-2">
                  {[...branches].sort((a, b) => a.health - b.health).slice(0, 5).map((b) => (
                    <div key={b.id} className="flex items-center gap-2">
                      <HealthDot value={b.health} />
                      <span className="text-sm text-ink-700 truncate" style={{ flex: 1 }}>{b.branch}</span>
                      <span className="text-sm font-bold text-red-600">{b.health}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}
