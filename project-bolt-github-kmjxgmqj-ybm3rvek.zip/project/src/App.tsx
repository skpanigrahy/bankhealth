import { Routes, Route } from 'react-router-dom'
import Sidebar from './components/Sidebar'
import Topbar from './components/Topbar'
import Home from './pages/Home'
import BranchSearch from './pages/BranchSearch'
import BranchMap from './pages/BranchMap'
import Performance from './pages/Performance'
import IVRAnalytics from './pages/IVRAnalytics'
import Reports from './pages/Reports'
import BranchHealth from './pages/BranchHealth'
import NetworkHealth from './pages/NetworkHealth'
import DeviceHealth from './pages/DeviceHealth'
import ApplicationHealth from './pages/ApplicationHealth'
import Tickets from './pages/Tickets'
import Inventory from './pages/Inventory'
import Events from './pages/Events'
import Employees from './pages/Employees'
import Assistant from './pages/Assistant'
import ComingSoon from './pages/ComingSoon'

export default function App() {
  return (
    <div className="flex min-h-screen" style={{ background: 'var(--ink-50)' }}>
      <Sidebar />
      <main className="flex-1 min-w-0">
        <Routes>
          <Route path="/" element={<><Topbar title="Home" subtitle="Enterprise branch operations dashboard" /><Home /></>} />
          <Route path="/branch-search" element={<><Topbar title="Search Branches" subtitle="Find and discover branches worldwide" /><BranchSearch /></>} />
          <Route path="/branch-map" element={<><Topbar title="Geospatial Map" subtitle="Drill from world to individual branch" /><BranchMap /></>} />
          <Route path="/performance" element={<><Topbar title="Branch Performance" subtitle="SLA, CSAT & operational KPIs" /><Performance /></>} />
          <Route path="/ivr-analytics" element={<><Topbar title="IVR Analytics" subtitle="Interactive Voice Response performance" /><IVRAnalytics /></>} />
          <Route path="/reports" element={<><Topbar title="Reports" subtitle="Scheduled & on-demand reporting" /><Reports /></>} />
          <Route path="/branch-health" element={<><Topbar title="Branch Health" subtitle="Composite health across all branches" /><BranchHealth /></>} />
          <Route path="/network-health" element={<><Topbar title="Network Health" subtitle="LAN, WAN & SIP trunk monitoring" /><NetworkHealth /></>} />
          <Route path="/device-health" element={<><Topbar title="Device Health" subtitle="ATMs, cash recyclers, servers & endpoints" /><DeviceHealth /></>} />
          <Route path="/application-health" element={<><Topbar title="Application Health" subtitle="Core banking & branch apps uptime" /><ApplicationHealth /></>} />
          <Route path="/tickets" element={<><Topbar title="Tickets" subtitle="Incident & request management" /><Tickets /></>} />
          <Route path="/inventory" element={<><Topbar title="Branch Inventory" subtitle="Hardware & asset register" /><Inventory /></>} />
          <Route path="/events" element={<><Topbar title="Branch Events" subtitle="Incidents & alerts timeline" /><Events /></>} />
          <Route path="/employees" element={<><Topbar title="Branch Personas" subtitle="Headcount & utilisation" /><Employees /></>} />
          <Route path="/assistant" element={<><Topbar title="AI Assistant" subtitle="Conversational branch intelligence" /><Assistant /></>} />
          <Route path="/feedback" element={<><Topbar title="Submit Feedback" subtitle="Help us improve" /><ComingSoon title="Submit Feedback" /></>} />
          <Route path="/tour" element={<><Topbar title="Branch Virtual Tour" subtitle="Explore branches virtually" /><ComingSoon title="Branch Virtual Tour" /></>} />
        </Routes>
      </main>
    </div>
  )
}
