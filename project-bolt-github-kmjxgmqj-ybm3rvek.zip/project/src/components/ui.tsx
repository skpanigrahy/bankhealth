import type { ReactNode } from 'react'

export function Card({ children, title, subtitle, className }: { children: ReactNode; title?: string; subtitle?: string; className?: string }) {
  return (
    <div className={`card ${className || ''}`}>
      {title && (
        <div className="mb-4">
          <div className="card-title">{title}</div>
          {subtitle && <div className="card-subtitle">{subtitle}</div>}
        </div>
      )}
      {children}
    </div>
  )
}

export function Badge({ children, tone = 'neutral' }: { children: ReactNode; tone?: 'green' | 'amber' | 'red' | 'blue' | 'neutral' }) {
  return <span className={`badge badge-${tone}`}>{children}</span>
}

export function HealthDot({ value }: { value: number }) {
  const color = value >= 90 ? '#10b981' : value >= 80 ? '#f59e0b' : '#ef4444'
  return <span className="inline-flex rounded-full" style={{ width: 10, height: 10, background: color, flexShrink: 0 }} />
}

export function ProgressBar({ value, tone = 'blue' }: { value: number; tone?: 'blue' | 'green' | 'amber' | 'red' }) {
  const colors: Record<string, string> = { blue: '#3b82f6', green: '#10b981', amber: '#f59e0b', red: '#ef4444' }
  return (
    <div className="progress-bar">
      <div className="progress-bar-fill" style={{ width: `${value}%`, background: colors[tone] }} />
    </div>
  )
}

export function KPI({ icon, label, value, delta, trend, hint }: {
  icon: ReactNode; label: string; value: string; delta?: string; trend?: 'up' | 'down'; hint?: string
}) {
  return (
    <div className="card" style={{ padding: 16 }}>
      <div className="flex items-center justify-between mb-2">
        <div style={{ color: 'var(--ink-400)' }}>{icon}</div>
        {delta && (
          <span className="text-xs font-semibold" style={{ color: trend === 'up' ? 'var(--emerald-600)' : 'var(--red-600)' }}>
            {trend === 'up' ? '↑' : '↓'} {delta}
          </span>
        )}
      </div>
      <div className="text-2xl font-bold text-ink-900">{value}</div>
      <div className="text-xs text-ink-400">{label}</div>
      {hint && <div className="text-xs text-ink-400 mt-2" style={{ opacity: 0.7 }}>{hint}</div>}
    </div>
  )
}
