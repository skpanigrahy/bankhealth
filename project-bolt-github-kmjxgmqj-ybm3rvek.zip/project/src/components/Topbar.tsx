import { Bell, Search } from 'lucide-react'
import { alerts } from '../data/mockData'

export default function Topbar({ title, subtitle }: { title: string; subtitle: string }) {
  const criticalCount = alerts.filter((a) => a.severity === 'critical').length
  return (
    <header className="sticky top-0 z-10 bg-white px-6 py-4 flex items-center justify-between"
      style={{ borderBottom: '1px solid var(--ink-100)' }}>
      <div>
        <h1 className="text-lg font-bold text-ink-900">{title}</h1>
        <p className="text-xs text-ink-400">{subtitle}</p>
      </div>
      <div className="flex items-center gap-4">
        <div className="relative">
          <Search style={{ width: 16, height: 16, color: 'var(--ink-400)', position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)' }} />
          <input
            placeholder="Search…"
            className="text-sm rounded-lg"
            style={{ paddingLeft: 36, paddingRight: 12, paddingTop: 8, paddingBottom: 8, width: 200, border: '1px solid var(--ink-200)', background: 'var(--ink-50)', outline: 'none' }}
          />
        </div>
        <div className="relative">
          <Bell style={{ width: 20, height: 20, color: 'var(--ink-500)' }} />
          {criticalCount > 0 && (
            <span className="absolute rounded-full text-white text-xs font-bold flex items-center justify-center"
              style={{ width: 16, height: 16, background: 'var(--red-500)', fontSize: 9, top: -4, right: -4 }}>{criticalCount}</span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <div className="rounded-full flex items-center justify-center font-bold"
            style={{ width: 32, height: 32, fontSize: 13, background: 'var(--brand-100)', color: 'var(--brand-700)' }}>OP</div>
          <div className="text-sm">
            <div className="font-semibold text-ink-800">Ops Admin</div>
            <div className="text-xs text-ink-400">Super User</div>
          </div>
        </div>
      </div>
    </header>
  )
}
