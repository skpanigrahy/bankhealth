import { useState } from 'react'
import { NavLink, useLocation } from 'react-router-dom'
import { Chrome as Home, Search, BarChart3, HeartPulse, Package, CalendarClock, Users, Bot, MessageSquare, Map as MapIcon, ChevronRight, Gauge, PhoneCall, Network, Cpu, AppWindow, Ticket, FileBarChart } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'

interface SubItem { to: string; label: string; icon: LucideIcon }
interface NavGroup {
  label: string
  to?: string
  icon: LucideIcon
  subItems?: SubItem[]
}

const navGroups: NavGroup[] = [
  { label: 'Home', to: '/', icon: Home },
  {
    label: 'Search Branches', icon: Search,
    subItems: [
      { to: '/branch-search', label: 'Branch Search', icon: Search },
      { to: '/branch-map', label: 'Geospatial Map', icon: MapIcon },
    ],
  },
  {
    label: 'Branch Analytics', icon: BarChart3,
    subItems: [
      { to: '/performance', label: 'Performance', icon: Gauge },
      { to: '/ivr-analytics', label: 'IVR Analytics', icon: PhoneCall },
      { to: '/reports', label: 'Reports', icon: FileBarChart },
    ],
  },
  {
    label: 'Branch Health', icon: HeartPulse,
    subItems: [
      { to: '/branch-health', label: 'Health Overview', icon: HeartPulse },
      { to: '/network-health', label: 'Network', icon: Network },
      { to: '/device-health', label: 'Devices', icon: Cpu },
      { to: '/application-health', label: 'Applications', icon: AppWindow },
      { to: '/tickets', label: 'Tickets', icon: Ticket },
    ],
  },
  {
    label: 'Branch Inventory', icon: Package,
    subItems: [
      { to: '/inventory', label: 'Asset Register', icon: Package },
    ],
  },
  {
    label: 'Branch Events', icon: CalendarClock,
    subItems: [
      { to: '/events', label: 'Alerts & Timeline', icon: CalendarClock },
    ],
  },
  {
    label: 'Branch Personas', icon: Users,
    subItems: [
      { to: '/employees', label: 'Employees', icon: Users },
    ],
  },
  { label: 'AI Assistant', to: '/assistant', icon: Bot },
  { label: 'Submit Feedback', to: '/feedback', icon: MessageSquare },
  { label: 'Virtual Tour', to: '/tour', icon: MapIcon },
]

export default function Sidebar() {
  const location = useLocation()
  const initialExpanded = navGroups
    .filter((g) => g.subItems?.some((s) => location.pathname.startsWith(s.to)))
    .map((g) => g.label)
  const [expanded, setExpanded] = useState<string[]>(initialExpanded)

  const toggle = (label: string) => {
    setExpanded((prev) => prev.includes(label) ? prev.filter((l) => l !== label) : [...prev, label])
  }

  return (
    <aside className="sticky top-0 h-screen flex flex-col bg-white"
      style={{ width: 256, flexShrink: 0, borderRight: '1px solid var(--ink-100)' }}>
      {/* Logo */}
      <div className="flex items-center gap-2 px-5 py-5" style={{ borderBottom: '1px solid var(--ink-100)' }}>
        <div className="flex items-center justify-center text-white font-bold rounded-lg"
          style={{ width: 36, height: 36, background: 'var(--brand-600)', fontSize: 18 }}>K</div>
        <div>
          <div className="font-bold text-ink-900" style={{ lineHeight: 1.2 }}>Know Your Branch</div>
          <div className="text-xs text-ink-400">Enterprise Operations</div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto px-3 py-4">
        {navGroups.map((group) => {
          if (!group.subItems) {
            return (
              <div key={group.label} className="space-y-1">
                <NavLink
                  to={group.to!}
                  end={group.to === '/'}
                  className={({ isActive }) => `nav-link ${isActive ? 'nav-link-active' : ''}`}
                >
                  <group.icon style={{ width: 16, height: 16 }} />
                  <span>{group.label}</span>
                </NavLink>
              </div>
            )
          }

          const isExpanded = expanded.includes(group.label)
          const hasActiveChild = group.subItems.some((s) => location.pathname === s.to)

          return (
            <div key={group.label} className="space-y-1">
              <button
                onClick={() => toggle(group.label)}
                className={`nav-group-header ${isExpanded ? 'expanded' : ''}`}
                style={hasActiveChild ? { color: 'var(--brand-700)' } : undefined}
              >
                <group.icon style={{ width: 16, height: 16, color: hasActiveChild ? 'var(--brand-600)' : 'var(--ink-500)' }} />
                <span>{group.label}</span>
                <ChevronRight className="chevron" style={{ width: 14, height: 14, color: 'var(--ink-400)' }} />
              </button>
              {isExpanded && (
                <div className="nav-group-children space-y-1">
                  {group.subItems.map((sub) => (
                    <NavLink
                      key={sub.to}
                      to={sub.to}
                      className={({ isActive }) => `nav-sub-link ${isActive ? 'nav-sub-link-active' : ''}`}
                      style={{ position: 'relative' }}
                    >
                      <sub.icon style={{ width: 14, height: 14 }} />
                      <span>{sub.label}</span>
                    </NavLink>
                  ))}
                </div>
              )}
            </div>
          )
        })}
      </nav>

      {/* Footer */}
      <div className="px-4 py-4 text-xs text-ink-400" style={{ borderTop: '1px solid var(--ink-100)' }}>
        v0.3 · 27 branches · 9 countries
      </div>
    </aside>
  )
}
