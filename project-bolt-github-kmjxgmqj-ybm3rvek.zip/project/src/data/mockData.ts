export interface BranchRow {
  id: string
  branch: string
  country: string
  countryCode: string
  region: string
  market: string
  city: string
  state: string
  lat: number
  lng: number
  manager: string
  costCenter: string
  health: number
  ivrContainment: number
  openTickets: number
  devices: number
  devicesOffline: number
  sla: number
  employees: number
  utilisation: number
  customers: number
  transactions: number
  calls: number
  ivrTransfers: number
  waitTime: number
  buildingStatus: string
  operatingStatus: string
  branchType: string
}

export const branches: BranchRow[] = [
  // --- United States ---
  { id: 'BR-101', branch: 'New York - Midtown', country: 'United States', countryCode: 'US', region: 'Northeast', market: 'Metro', city: 'New York', state: 'New York', lat: 40.7549, lng: -73.9840, manager: 'J. Anderson', costCenter: 'CC-NYC-01', health: 94, ivrContainment: 81, openTickets: 3, devices: 156, devicesOffline: 1, sla: 99, employees: 52, utilisation: 85, customers: 1820, transactions: 5210, calls: 6210, ivrTransfers: 1180, waitTime: 2.8, buildingStatus: 'Excellent', operatingStatus: 'Open', branchType: 'Full Service' },
  { id: 'BR-102', branch: 'San Francisco - Financial District', country: 'United States', countryCode: 'US', region: 'West', market: 'Metro', city: 'San Francisco', state: 'California', lat: 37.7946, lng: -122.3999, manager: 'S. Chen', costCenter: 'CC-SF-01', health: 91, ivrContainment: 78, openTickets: 4, devices: 134, devicesOffline: 1, sla: 98, employees: 44, utilisation: 82, customers: 1410, transactions: 4120, calls: 4920, ivrTransfers: 1082, waitTime: 3.1, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Full Service' },
  { id: 'BR-103', branch: 'Chicago - Loop', country: 'United States', countryCode: 'US', region: 'Midwest', market: 'Metro', city: 'Chicago', state: 'Illinois', lat: 41.8781, lng: -87.6298, manager: 'M. Johnson', costCenter: 'CC-CHI-01', health: 89, ivrContainment: 74, openTickets: 6, devices: 112, devicesOffline: 2, sla: 96, employees: 38, utilisation: 78, customers: 1180, transactions: 3480, calls: 4180, ivrTransfers: 1087, waitTime: 3.6, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Full Service' },
  { id: 'BR-104', branch: 'Houston - Galleria', country: 'United States', countryCode: 'US', region: 'South', market: 'Metro', city: 'Houston', state: 'Texas', lat: 29.7380, lng: -95.4612, manager: 'R. Martinez', costCenter: 'CC-HOU-01', health: 85, ivrContainment: 70, openTickets: 8, devices: 98, devicesOffline: 2, sla: 94, employees: 33, utilisation: 75, customers: 920, transactions: 2740, calls: 3310, ivrTransfers: 993, waitTime: 4.2, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Standard' },
  { id: 'BR-105', branch: 'Atlanta - Buckhead', country: 'United States', countryCode: 'US', region: 'Southeast', market: 'Metro', city: 'Atlanta', state: 'Georgia', lat: 33.8467, lng: -84.3646, manager: 'D. Williams', costCenter: 'CC-ATL-01', health: 87, ivrContainment: 73, openTickets: 5, devices: 104, devicesOffline: 1, sla: 95, employees: 35, utilisation: 77, customers: 1020, transactions: 3020, calls: 3680, ivrTransfers: 994, waitTime: 3.8, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Full Service' },
  { id: 'BR-106', branch: 'Seattle - Downtown', country: 'United States', countryCode: 'US', region: 'West', market: 'Metro', city: 'Seattle', state: 'Washington', lat: 47.6062, lng: -122.3321, manager: 'L. Park', costCenter: 'CC-SEA-01', health: 93, ivrContainment: 80, openTickets: 2, devices: 128, devicesOffline: 0, sla: 99, employees: 41, utilisation: 83, customers: 1340, transactions: 3960, calls: 4720, ivrTransfers: 944, waitTime: 2.9, buildingStatus: 'Excellent', operatingStatus: 'Open', branchType: 'Full Service' },
  { id: 'BR-107', branch: 'Miami - Brickell', country: 'United States', countryCode: 'US', region: 'Southeast', market: 'Metro', city: 'Miami', state: 'Florida', lat: 25.7934, lng: -80.1902, manager: 'C. Rodriguez', costCenter: 'CC-MIA-01', health: 82, ivrContainment: 67, openTickets: 9, devices: 86, devicesOffline: 3, sla: 91, employees: 28, utilisation: 71, customers: 740, transactions: 2180, calls: 2680, ivrTransfers: 884, waitTime: 5.2, buildingStatus: 'Fair', operatingStatus: 'Open', branchType: 'Standard' },
  { id: 'BR-108', branch: 'Denver - Cherry Creek', country: 'United States', countryCode: 'US', region: 'West', market: 'Urban', city: 'Denver', state: 'Colorado', lat: 39.7174, lng: -104.9534, manager: 'B. Taylor', costCenter: 'CC-DEN-01', health: 88, ivrContainment: 75, openTickets: 4, devices: 92, devicesOffline: 1, sla: 96, employees: 30, utilisation: 76, customers: 860, transactions: 2520, calls: 3020, ivrTransfers: 755, waitTime: 3.5, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Standard' },
  { id: 'BR-109', branch: 'Boston - Back Bay', country: 'United States', countryCode: 'US', region: 'Northeast', market: 'Metro', city: 'Boston', state: 'Massachusetts', lat: 42.3505, lng: -71.0810, manager: 'E. Murphy', costCenter: 'CC-BOS-01', health: 90, ivrContainment: 77, openTickets: 3, devices: 108, devicesOffline: 0, sla: 97, employees: 36, utilisation: 80, customers: 1120, transactions: 3340, calls: 4020, ivrTransfers: 925, waitTime: 3.0, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Full Service' },
  { id: 'BR-110', branch: 'Phoenix - Scottsdale', country: 'United States', countryCode: 'US', region: 'West', market: 'Urban', city: 'Phoenix', state: 'Arizona', lat: 33.4942, lng: -111.9256, manager: 'T. Nguyen', costCenter: 'CC-PHX-01', health: 86, ivrContainment: 72, openTickets: 6, devices: 88, devicesOffline: 2, sla: 94, employees: 27, utilisation: 73, customers: 780, transactions: 2280, calls: 2780, ivrTransfers: 778, waitTime: 4.0, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Standard' },
  // --- China ---
  { id: 'BR-201', branch: 'Shanghai - Lujiazui', country: 'China', countryCode: 'CN', region: 'East', market: 'Metro', city: 'Shanghai', state: 'Shanghai', lat: 31.2397, lng: 121.4998, manager: 'W. Zhang', costCenter: 'CC-SHA-01', health: 92, ivrContainment: 79, openTickets: 4, devices: 148, devicesOffline: 1, sla: 98, employees: 46, utilisation: 83, customers: 1620, transactions: 4720, calls: 5720, ivrTransfers: 1201, waitTime: 3.0, buildingStatus: 'Excellent', operatingStatus: 'Open', branchType: 'Full Service' },
  { id: 'BR-202', branch: 'Beijing - CBD', country: 'China', countryCode: 'CN', region: 'North', market: 'Metro', city: 'Beijing', state: 'Beijing', lat: 39.9087, lng: 116.3974, manager: 'L. Wang', costCenter: 'CC-BJ-01', health: 90, ivrContainment: 76, openTickets: 5, devices: 132, devicesOffline: 2, sla: 97, employees: 42, utilisation: 81, customers: 1380, transactions: 4080, calls: 4880, ivrTransfers: 1171, waitTime: 3.4, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Full Service' },
  { id: 'BR-203', branch: 'Shenzhen - Futian', country: 'China', countryCode: 'CN', region: 'South', market: 'Metro', city: 'Shenzhen', state: 'Guangdong', lat: 22.5431, lng: 114.0579, manager: 'H. Liu', costCenter: 'CC-SZ-01', health: 88, ivrContainment: 73, openTickets: 7, devices: 118, devicesOffline: 2, sla: 95, employees: 38, utilisation: 79, customers: 1140, transactions: 3380, calls: 4080, ivrTransfers: 1102, waitTime: 3.8, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Full Service' },
  { id: 'BR-204', branch: 'Guangzhou - Tianhe', country: 'China', countryCode: 'CN', region: 'South', market: 'Metro', city: 'Guangzhou', state: 'Guangdong', lat: 23.1376, lng: 113.3246, manager: 'X. Chen', costCenter: 'CC-GZ-01', health: 84, ivrContainment: 68, openTickets: 9, devices: 96, devicesOffline: 3, sla: 92, employees: 32, utilisation: 74, customers: 880, transactions: 2620, calls: 3180, ivrTransfers: 1018, waitTime: 4.6, buildingStatus: 'Fair', operatingStatus: 'Open', branchType: 'Standard' },
  // --- India ---
  { id: 'BR-301', branch: 'Mumbai - Fort', country: 'India', countryCode: 'IN', region: 'West', market: 'Metro', city: 'Mumbai', state: 'Maharashtra', lat: 18.9289, lng: 72.8320, manager: 'A. Sharma', costCenter: 'CC-MUM-01', health: 92, ivrContainment: 78, openTickets: 4, devices: 126, devicesOffline: 1, sla: 98, employees: 42, utilisation: 81, customers: 1240, transactions: 3820, calls: 4820, ivrTransfers: 1060, waitTime: 3.2, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Full Service' },
  { id: 'BR-302', branch: 'Delhi - Connaught', country: 'India', countryCode: 'IN', region: 'North', market: 'Metro', city: 'Delhi', state: 'Delhi', lat: 28.6328, lng: 77.2197, manager: 'P. Gupta', costCenter: 'CC-DEL-01', health: 88, ivrContainment: 71, openTickets: 7, devices: 98, devicesOffline: 2, sla: 95, employees: 36, utilisation: 77, customers: 980, transactions: 2940, calls: 3940, ivrTransfers: 1142, waitTime: 4.1, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Full Service' },
  { id: 'BR-303', branch: 'Bengaluru - MG Road', country: 'India', countryCode: 'IN', region: 'South', market: 'Metro', city: 'Bengaluru', state: 'Karnataka', lat: 12.9756, lng: 77.6067, manager: 'D. Reddy', costCenter: 'CC-BLR-01', health: 95, ivrContainment: 82, openTickets: 2, devices: 142, devicesOffline: 0, sla: 99, employees: 48, utilisation: 84, customers: 1520, transactions: 4210, calls: 5210, ivrTransfers: 938, waitTime: 2.5, buildingStatus: 'Excellent', operatingStatus: 'Open', branchType: 'Full Service' },
  { id: 'BR-304', branch: 'Chennai - T. Nagar', country: 'India', countryCode: 'IN', region: 'South', market: 'Urban', city: 'Chennai', state: 'Tamil Nadu', lat: 13.0418, lng: 80.2341, manager: 'L. Krishnan', costCenter: 'CC-MAA-01', health: 84, ivrContainment: 69, openTickets: 9, devices: 87, devicesOffline: 3, sla: 92, employees: 31, utilisation: 73, customers: 760, transactions: 2180, calls: 2870, ivrTransfers: 891, waitTime: 5.4, buildingStatus: 'Fair', operatingStatus: 'Open', branchType: 'Standard' },
  { id: 'BR-305', branch: 'Kolkata - Park Street', country: 'India', countryCode: 'IN', region: 'East', market: 'Metro', city: 'Kolkata', state: 'West Bengal', lat: 22.5547, lng: 88.3510, manager: 'S. Banerjee', costCenter: 'CC-CCU-01', health: 79, ivrContainment: 64, openTickets: 12, devices: 76, devicesOffline: 4, sla: 89, employees: 28, utilisation: 69, customers: 640, transactions: 1820, calls: 2210, ivrTransfers: 796, waitTime: 6.8, buildingStatus: 'Fair', operatingStatus: 'Degraded', branchType: 'Standard' },
  // --- United Kingdom ---
  { id: 'BR-401', branch: 'London - City', country: 'United Kingdom', countryCode: 'GB', region: 'Greater London', market: 'Metro', city: 'London', state: 'England', lat: 51.5144, lng: -0.0929, manager: 'O. Bennett', costCenter: 'CC-LON-01', health: 91, ivrContainment: 77, openTickets: 4, devices: 124, devicesOffline: 1, sla: 97, employees: 40, utilisation: 80, customers: 1280, transactions: 3760, calls: 4560, ivrTransfers: 1050, waitTime: 3.1, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Full Service' },
  { id: 'BR-402', branch: 'Manchester - Spinningfields', country: 'United Kingdom', countryCode: 'GB', region: 'North West', market: 'Urban', city: 'Manchester', state: 'England', lat: 53.4794, lng: -2.2540, manager: 'G. Hughes', costCenter: 'CC-MAN-01', health: 85, ivrContainment: 71, openTickets: 7, devices: 92, devicesOffline: 2, sla: 94, employees: 30, utilisation: 75, customers: 820, transactions: 2420, calls: 2920, ivrTransfers: 847, waitTime: 4.0, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Standard' },
  // --- Singapore ---
  { id: 'BR-501', branch: 'Singapore - Raffles Place', country: 'Singapore', countryCode: 'SG', region: 'Central', market: 'Metro', city: 'Singapore', state: 'Singapore', lat: 1.2833, lng: 103.8513, manager: 'J. Tan', costCenter: 'CC-SG-01', health: 93, ivrContainment: 80, openTickets: 3, devices: 116, devicesOffline: 0, sla: 99, employees: 38, utilisation: 82, customers: 1320, transactions: 3880, calls: 4680, ivrTransfers: 936, waitTime: 2.7, buildingStatus: 'Excellent', operatingStatus: 'Open', branchType: 'Full Service' },
  // --- Germany ---
  { id: 'BR-601', branch: 'Frankfurt - Bankenviertel', country: 'Germany', countryCode: 'DE', region: 'Hesse', market: 'Metro', city: 'Frankfurt', state: 'Hesse', lat: 50.1136, lng: 8.6785, manager: 'K. Müller', costCenter: 'CC-FRA-01', health: 89, ivrContainment: 74, openTickets: 5, devices: 104, devicesOffline: 1, sla: 96, employees: 34, utilisation: 78, customers: 980, transactions: 2880, calls: 3480, ivrTransfers: 905, waitTime: 3.4, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Full Service' },
  // --- Japan ---
  { id: 'BR-701', branch: 'Tokyo - Marunouchi', country: 'Japan', countryCode: 'JP', region: 'Kanto', market: 'Metro', city: 'Tokyo', state: 'Tokyo', lat: 35.6812, lng: 139.7671, manager: 'Y. Sato', costCenter: 'CC-TYO-01', health: 90, ivrContainment: 76, openTickets: 4, devices: 130, devicesOffline: 1, sla: 97, employees: 42, utilisation: 81, customers: 1480, transactions: 4320, calls: 5180, ivrTransfers: 1243, waitTime: 3.2, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Full Service' },
  // --- UAE ---
  { id: 'BR-801', branch: 'Dubai - DIFC', country: 'United Arab Emirates', countryCode: 'AE', region: 'Dubai', market: 'Metro', city: 'Dubai', state: 'Dubai', lat: 25.2138, lng: 55.2790, manager: 'F. Al-Hashimi', costCenter: 'CC-DXB-01', health: 87, ivrContainment: 72, openTickets: 6, devices: 100, devicesOffline: 2, sla: 95, employees: 32, utilisation: 76, customers: 1060, transactions: 3120, calls: 3820, ivrTransfers: 1069, waitTime: 3.6, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Full Service' },
  // --- Australia ---
  { id: 'BR-901', branch: 'Sydney - Martin Place', country: 'Australia', countryCode: 'AU', region: 'New South Wales', market: 'Metro', city: 'Sydney', state: 'New South Wales', lat: -33.8678, lng: 151.2073, manager: 'N. Clarke', costCenter: 'CC-SYD-01', health: 88, ivrContainment: 73, openTickets: 5, devices: 108, devicesOffline: 1, sla: 96, employees: 35, utilisation: 77, customers: 1020, transactions: 3020, calls: 3680, ivrTransfers: 994, waitTime: 3.5, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Full Service' },
]

export const alerts = [
  { id: 1, severity: 'critical', title: 'Kolkata - SIP trunk down', time: '12 min ago', branch: 'Kolkata - Park Street' },
  { id: 2, severity: 'high', title: 'Miami - ATM #3 offline', time: '28 min ago', branch: 'Miami - Brickell' },
  { id: 3, severity: 'medium', title: 'Houston - WAN latency > 45ms', time: '41 min ago', branch: 'Houston - Galleria' },
  { id: 4, severity: 'low', title: 'London - certificate expiring in 7 days', time: '1 hr ago', branch: 'London - City' },
  { id: 5, severity: 'medium', title: 'Chicago - queue wait time > 5 min', time: '2 hr ago', branch: 'Chicago - Loop' },
  { id: 6, severity: 'high', title: 'Kolkata - backup circuit at 92% utilization', time: '15 min ago', branch: 'Kolkata - Park Street' },
]
