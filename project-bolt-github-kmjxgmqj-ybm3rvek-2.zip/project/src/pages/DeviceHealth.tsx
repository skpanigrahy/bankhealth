import { Card, KPI, Badge, ProgressBar } from '../components/ui'
import {
  Cpu, CircleAlert as AlertCircle, CircleCheck as CheckCircle2, Banknote,
  Monitor, Tablet, CreditCard, Printer, Camera, BatteryCharging, Server,
} from 'lucide-react'
import { branches, devices } from '../data/mockData'

const deviceTypeIcons: Record<string, any> = {
  ATM: Banknote, Teller: Monitor, Kiosk: Tablet, POS: CreditCard,
  Printer: Printer, Camera: Camera, UPS: BatteryCharging, Server: Server,
}

const deviceTypeColors: Record<string, string> = {
  ATM: '#f59e0b', Teller: '#3b82f6', Kiosk: '#8b5cf6', POS: '#10b981',
  Printer: '#64748b', Camera: '#ec4899', UPS: '#06b6d4', Server: '#6366f1',
}

export default function DeviceHealth() {
  const total = devices.length
  const off = devices.filter((d) => d.status === 'Offline').length
  const degraded = devices.filter((d) => d.status === 'Degraded').length
  const onlineRate = Math.round(((total - off) / total) * 100)
  const avgUptime = Math.round(devices.filter((d) => d.uptime > 0).reduce((s, d) => s + d.uptime, 0) / devices.filter((d) => d.uptime > 0).length * 10) / 10

  const byType = ['ATM', 'Teller', 'Kiosk', 'POS', 'Printer', 'Camera', 'UPS', 'Server'].map((type) => {
    const items = devices.filter((d) => d.type === type)
    return {
      type,
      total: items.length,
      online: items.filter((d) => d.status === 'Online').length,
      offline: items.filter((d) => d.status === 'Offline').length,
      degraded: items.filter((d) => d.status === 'Degraded').length,
    }
  })

  return (
    <div>
      <div className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4" style={{ gap: 12 }}>
          <KPI icon={<Cpu style={{ width: 18, height: 18 }} />} label="Total Devices" value={String(total)} tone="blue" />
          <KPI icon={<AlertCircle style={{ width: 18, height: 18 }} />} label="Offline" value={String(off)} tone="red" />
          <KPI icon={<CheckCircle2 style={{ width: 18, height: 18 }} />} label="Online Rate" value={`${onlineRate}%`} tone="green" />
          <KPI icon={<Cpu style={{ width: 18, height: 18 }} />} label="Avg Uptime" value={`${avgUptime}%`} tone="green" />
        </div>

        {/* Device type breakdown */}
        <div className="grid grid-cols-2 md:grid-cols-4" style={{ gap: 12 }}>
          {byType.map((t) => {
            const Icon = deviceTypeIcons[t.type]
            const color = deviceTypeColors[t.type]
            return (
              <Card key={t.type}>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div style={{ width: 30, height: 30, borderRadius: 7, background: `${color}1a`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <Icon style={{ width: 16, height: 16, color }} />
                    </div>
                    <span className="text-sm font-bold text-ink-800">{t.type}</span>
                  </div>
                </div>
                <div className="text-2xl font-bold text-ink-900">{t.total}</div>
                <div className="flex items-center gap-3 mt-2">
                  <span className="text-xs text-emerald-600 font-semibold">{t.online} online</span>
                  {t.offline > 0 && <span className="text-xs text-red-600 font-semibold">{t.offline} offline</span>}
                  {t.degraded > 0 && <span className="text-xs text-amber-600 font-semibold">{t.degraded} degraded</span>}
                </div>
              </Card>
            )
          })}
        </div>

        {/* Device inventory by branch */}
        <Card title="Device Inventory by Branch" subtitle="ATMs, teller systems, kiosks, POS, printers, cameras, UPS, servers">
          <div className="space-y-1">
            {branches.map((b) => {
              const branchDevices = devices.filter((d) => d.branchId === b.id)
              return (
                <div key={b.id} className="p-3 rounded-lg hover:bg-ink-50 transition-colors" style={{ borderBottom: '1px solid var(--ink-100)' }}>
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <div className="text-sm font-semibold text-ink-800">{b.branch}</div>
                      <div className="text-xs text-ink-400">{b.devices} devices · {b.devicesOffline} offline</div>
                    </div>
                    <Badge tone={b.devicesOffline === 0 ? 'green' : b.devicesOffline <= 2 ? 'amber' : 'red'}>
                      {b.devicesOffline === 0 ? 'All Online' : `${b.devicesOffline} Offline`}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-1 flex-wrap">
                    {branchDevices.map((d) => {
                      const Icon = deviceTypeIcons[d.type]
                      const color = d.status === 'Online' ? '#10b981' : d.status === 'Degraded' ? '#f59e0b' : '#ef4444'
                      return (
                        <div key={d.type} className="flex items-center gap-1 px-2 py-1 rounded" style={{ background: 'var(--ink-50)' }} title={`${d.type}: ${d.model} — ${d.status}`}>
                          <Icon style={{ width: 12, height: 12, color }} />
                          <span className="text-xs text-ink-600">{d.type}</span>
                          <span style={{ width: 6, height: 6, borderRadius: '50%', background: color }} />
                        </div>
                      )
                    })}
                  </div>
                </div>
              )
            })}
          </div>
        </Card>

        {/* Offline/degraded devices detail */}
        {devices.filter((d) => d.status !== 'Online').length > 0 && (
          <Card title="Devices Requiring Attention" subtitle="Offline and degraded devices across all branches">
            <div className="space-y-1">
              {devices.filter((d) => d.status !== 'Online').map((d) => (
                <div key={`${d.branchId}-${d.type}`} className="flex items-center gap-3 p-2 rounded-lg hover:bg-ink-50 transition-colors">
                  <span style={{ width: 8, height: 8, borderRadius: '50%', background: d.status === 'Offline' ? 'var(--red-500)' : 'var(--amber-500)' }} />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-ink-800">{d.branch} — {d.type}</div>
                    <div className="text-xs text-ink-400">{d.model} · Last seen: {d.lastSeen}</div>
                  </div>
                  <Badge tone={d.status === 'Offline' ? 'red' : 'amber'}>{d.status}</Badge>
                </div>
              ))}
            </div>
          </Card>
        )}
      </div>
    </div>
  )
}
