import { Link } from 'react-router-dom'
import {
  Chrome as HomeIcon, Search, BarChart3, HeartPulse, Package, CalendarClock, Users, Bot,
  MessageSquare, MapPin, ArrowRight, TriangleAlert as AlertTriangle, Building2, Activity,
  Gauge, PhoneCall, ShieldCheck, DollarSign, Sparkles, TrendingDown, TrendingUp, Network,
  Cpu, Ticket,
} from 'lucide-react'
import { Card, KPI, HealthDot, Badge, Sparkline, TrendArrow } from '../components/ui'
import {
  branches, alerts, executiveKPIs, executiveTrends, aiExecutiveSummary, regionPerformance,
} from '../data/mockData'

const modules = [
  { to: '/branch-search', label: 'Search Branches', icon: Search, color: '#8b5cf6', bg: '#f5f3ff', desc: 'Find branches worldwide' },
  { to: '/branch-map', label: 'Geospatial Map', icon: MapPin, color: '#06b6d4', bg: '#ecfeff', desc: 'Interactive world map' },
  { to: '/performance', label: 'Branch Analytics', icon: BarChart3, color: '#10b981', bg: '#ecfdf5', desc: 'Performance & IVR' },
  { to: '/branch-health', label: 'Branch Health', icon: HeartPulse, color: '#ef4444', bg: '#fef2f2', desc: 'Composite health scores' },
  { to: '/network-health', label: 'Network Health', icon: Network, color: '#3b82f6', bg: '#eff6ff', desc: 'WAN, LAN, SIP monitoring' },
  { to: '/device-health', label: 'Device Health', icon: Cpu, color: '#f59e0b', bg: '#fffbeb', desc: 'ATMs, kiosks, POS, servers' },
  { to: '/application-health', label: 'Application Health', icon: Activity, color: '#8b5cf6', bg: '#f5f3ff', desc: 'Core banking & apps' },
  { to: '/tickets', label: 'Incident Management', icon: Ticket, color: '#ef4444', bg: '#fef2f2', desc: 'Active incidents & SLA' },
  { to: '/inventory', label: 'Branch Inventory', icon: Package, color: '#f59e0b', bg: '#fffbeb', desc: 'Asset register & lifecycle' },
  { to: '/events', label: 'Branch Events', icon: CalendarClock, color: '#6366f1', bg: '#e0e7ff', desc: 'Alerts & incidents timeline' },
  { to: '/employees', label: 'Branch Personas', icon: Users, color: '#ec4899', bg: '#fdf2f8', desc: 'Employees & utilisation' },
  { to: '/ivr-analytics', label: 'IVR Analytics', icon: PhoneCall, color: '#06b6d4', bg: '#ecfeff', desc: 'Call volume & containment' },
  { to: '/assistant', label: 'AI Assistant', icon: Bot, color: '#0ea5e9', bg: '#f0f9ff', desc: 'Conversational intelligence' },
  { to: '/feedback', label: 'Submit Feedback', icon: MessageSquare, color: '#64748b', bg: '#f8fafc', desc: 'Coming soon' },
]

const summaryTypeStyles: Record<string, { color: string; bg: string; icon: any }> = {
  positive: { color: '#059669', bg: '#ecfdf5', icon: TrendingUp },
  warning: { color: '#d97706', bg: '#fffbeb', icon: AlertTriangle },
  negative: { color: '#dc2626', bg: '#fef2f2', icon: TrendingDown },
  critical: { color: '#b91c1c', bg: '#fee2e2', icon: AlertTriangle },
}

export default function Home() {
  const k = executiveKPIs
  const criticalAlerts = alerts.filter((a) => a.severity === 'critical').length

  return (
    <div>
      <div className="space-y-6">
        {/* Welcome banner */}
        <div className="card" style={{ background: 'linear-gradient(135deg, var(--brand-600), var(--brand-800))', border: 'none', color: 'white' }}>
          <div className="flex items-center justify-between flex-wrap" style={{ gap: 16 }}>
            <div>
              <h2 className="text-lg font-bold" style={{ marginBottom: 4 }}>Branch Operations Intelligence Platform</h2>
              <p style={{ fontSize: 13, opacity: 0.85 }}>Unified operational cockpit for {k.totalBranches} branches across {new Set(branches.map((b) => b.country)).size} countries</p>
            </div>
            <div className="flex items-center" style={{ gap: 24 }}>
              <div className="text-center">
                <div className="text-2xl font-bold">{k.overallHealth}%</div>
                <div style={{ fontSize: 11, opacity: 0.7 }}>Avg Health</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">{k.activeIncidents}</div>
                <div style={{ fontSize: 11, opacity: 0.7 }}>Active Incidents</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">{k.avgSla}%</div>
                <div style={{ fontSize: 11, opacity: 0.7 }}>Avg SLA</div>
              </div>
            </div>
          </div>
        </div>

        {/* Executive KPI cards */}
        <div>
          <h3 className="text-sm font-bold text-ink-700 mb-3">Executive KPIs</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6" style={{ gap: 12 }}>
            <KPI icon={<Building2 style={{ width: 18, height: 18 }} />} label="Total Branches" value={String(k.totalBranches)} tone="blue" />
            <KPI icon={<HeartPulse style={{ width: 18, height: 18 }} />} label="Healthy Branches" value={String(k.healthyBranches)} tone="green" hint={`${k.warningBranches} warning · ${k.criticalBranches} critical`} />
            <KPI icon={<AlertTriangle style={{ width: 18, height: 18 }} />} label="Active Incidents" value={String(k.activeIncidents)} tone="red" hint={`${k.majorOutages} major outage`} />
            <KPI icon={<Gauge style={{ width: 18, height: 18 }} />} label="Average SLA" value={`${k.avgSla}%`} tone="green" delta="1" trend="up" />
            <KPI icon={<PhoneCall style={{ width: 18, height: 18 }} />} label="IVR Containment" value={`${k.ivrContainment}%`} tone="blue" delta="3" trend="up" />
            <KPI icon={<Users style={{ width: 18, height: 18 }} />} label="Employee Availability" value={`${k.employeeAvailability}%`} tone="green" />
            <KPI icon={<Activity style={{ width: 18, height: 18 }} />} label="Customer Satisfaction" value={`${k.customerSatisfaction}/5`} tone="amber" delta="0.1" trend="down" />
            <KPI icon={<ShieldCheck style={{ width: 18, height: 18 }} />} label="Network Availability" value="99.1%" tone="green" />
            <KPI icon={<DollarSign style={{ width: 18, height: 18 }} />} label="Operational Cost Index" value={String(k.operationalCostIndex)} tone="amber" delta="2" trend="up" />
            <KPI icon={<Cpu style={{ width: 18, height: 18 }} />} label="Devices Online" value="98.4%" tone="green" />
            <KPI icon={<Ticket style={{ width: 18, height: 18 }} />} label="SLA Breaches" value="2" tone="red" />
            <KPI icon={<Sparkles style={{ width: 18, height: 18 }} />} label="AI Insights Today" value="14" tone="blue" />
          </div>
        </div>

        {/* AI Executive Summary */}
        <Card title="AI Executive Summary" subtitle="Auto-generated operational insights">
          <div className="space-y-2">
            {aiExecutiveSummary.map((s, i) => {
              const style = summaryTypeStyles[s.type]
              const Icon = style.icon
              return (
                <div key={i} className="flex items-start gap-3 p-3 rounded-lg" style={{ background: style.bg }}>
                  <Icon style={{ width: 16, height: 16, color: style.color, marginTop: 1, flexShrink: 0 }} />
                  <div className="text-sm" style={{ color: style.color, fontWeight: 500 }}>{s.text}</div>
                </div>
              )
            })}
          </div>
        </Card>

        {/* Executive Trends */}
        <div>
          <h3 className="text-sm font-bold text-ink-700 mb-3">30-Day Executive Trends</h3>
          <div className="grid grid-cols-2 md:grid-cols-4" style={{ gap: 12 }}>
            <Card>
              <div className="flex items-center justify-between mb-2">
                <div className="text-xs font-semibold text-ink-500">Branch Health</div>
                <Badge tone="green">+3.2%</Badge>
              </div>
              <Sparkline data={executiveTrends.branchHealth} color="#10b981" width={200} height={40} />
            </Card>
            <Card>
              <div className="flex items-center justify-between mb-2">
                <div className="text-xs font-semibold text-ink-500">Incident Volume</div>
                <Badge tone="amber">+2</Badge>
              </div>
              <Sparkline data={executiveTrends.incidentVolume} color="#f59e0b" width={200} height={40} />
            </Card>
            <Card>
              <div className="flex items-center justify-between mb-2">
                <div className="text-xs font-semibold text-ink-500">Network Availability</div>
                <Badge tone="green">99.1%</Badge>
              </div>
              <Sparkline data={executiveTrends.networkAvailability.map((v) => v * 100 - 9800)} color="#3b82f6" width={200} height={40} />
            </Card>
            <Card>
              <div className="flex items-center justify-between mb-2">
                <div className="text-xs font-semibold text-ink-500">Customer Transactions</div>
                <Badge tone="green">+5.8%</Badge>
              </div>
              <Sparkline data={executiveTrends.customerTransactions} color="#8b5cf6" width={200} height={40} />
            </Card>
            <Card>
              <div className="flex items-center justify-between mb-2">
                <div className="text-xs font-semibold text-ink-500">Voice Quality (MOS)</div>
                <Badge tone="amber">4.1</Badge>
              </div>
              <Sparkline data={executiveTrends.voiceQuality.map((v) => v * 10)} color="#06b6d4" width={200} height={40} />
            </Card>
            <Card>
              <div className="flex items-center justify-between mb-2">
                <div className="text-xs font-semibold text-ink-500">IVR Containment</div>
                <Badge tone="green">+3%</Badge>
              </div>
              <Sparkline data={executiveTrends.ivrContainment} color="#ec4899" width={200} height={40} />
            </Card>
            <Card>
              <div className="flex items-center justify-between mb-2">
                <div className="text-xs font-semibold text-ink-500">Employee Utilization</div>
                <Badge tone="green">+2%</Badge>
              </div>
              <Sparkline data={executiveTrends.employeeUtilization} color="#6366f1" width={200} height={40} />
            </Card>
          </div>
        </div>

        {/* Module launcher grid */}
        <div>
          <h3 className="text-sm font-bold text-ink-700 mb-3">Modules</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5" style={{ gap: 12 }}>
            {modules.map((m) => (
              <Link key={m.to} to={m.to}>
                <div className="module-card bg-white">
                  <div className="module-card-icon" style={{ background: m.bg }}>
                    <m.icon style={{ width: 22, height: 22, color: m.color }} />
                  </div>
                  <div className="font-bold text-ink-900" style={{ fontSize: 13 }}>{m.label}</div>
                  <div className="text-xs text-ink-400 mt-2">{m.desc}</div>
                  <div className="flex items-center gap-1 text-xs font-semibold mt-3" style={{ color: m.color }}>
                    Open <ArrowRight style={{ width: 12, height: 12 }} />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Region performance + Active alerts */}
        <div className="grid grid-cols-1 lg:grid-cols-3" style={{ gap: 16 }}>
          <Card className="lg:col-span-2" title="Regional Performance" subtitle="Health, SLA & incidents by region">
            <div className="space-y-1">
              <div className="flex items-center text-xs font-semibold text-ink-400 px-2 pb-2" style={{ borderBottom: '1px solid var(--ink-100)' }}>
                <span style={{ flex: 1 }}>Region</span>
                <span style={{ width: 60, textAlign: 'center' }}>Health</span>
                <span style={{ width: 50, textAlign: 'center' }}>SLA</span>
                <span style={{ width: 50, textAlign: 'center' }}>Incidents</span>
                <span style={{ width: 60, textAlign: 'right' }}>Utilisation</span>
              </div>
              {regionPerformance.slice(0, 10).map((r) => (
                <div key={r.region} className="flex items-center p-2 rounded-lg hover:bg-ink-50 transition-colors">
                  <span className="text-sm font-medium text-ink-800 truncate" style={{ flex: 1 }}>{r.region}</span>
                  <span style={{ width: 60, textAlign: 'center' }}>
                    <span className="text-sm font-bold" style={{ color: r.avgHealth >= 90 ? 'var(--emerald-600)' : r.avgHealth >= 80 ? 'var(--amber-600)' : 'var(--red-600)' }}>{r.avgHealth}</span>
                  </span>
                  <span className="text-sm text-ink-600" style={{ width: 50, textAlign: 'center' }}>{r.avgSla}%</span>
                  <span style={{ width: 50, textAlign: 'center' }}>
                    <Badge tone={r.incidents >= 3 ? 'red' : r.incidents >= 2 ? 'amber' : 'green'}>{r.incidents}</Badge>
                  </span>
                  <span className="text-sm text-ink-500" style={{ width: 60, textAlign: 'right' }}>{r.utilisation}%</span>
                </div>
              ))}
            </div>
          </Card>

          <Card title="Active Alerts" subtitle={`${alerts.length} total · ${criticalAlerts} critical`}>
            <div className="space-y-2">
              {alerts.map((a) => (
                <div key={a.id} className="flex items-start gap-2 p-2 rounded-lg hover:bg-ink-50 transition-colors">
                  <AlertTriangle style={{
                    width: 14, height: 14, marginTop: 2, flexShrink: 0,
                    color: a.severity === 'critical' ? 'var(--red-500)' : a.severity === 'high' ? 'var(--amber-500)' : 'var(--ink-400)',
                  }} />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-ink-800 truncate">{a.title}</div>
                    <div className="text-xs text-ink-400">{a.time}</div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Branch health at a glance */}
        <Card title="Branch Health at a Glance" subtitle="Top and bottom performing branches">
          <div className="grid grid-cols-2" style={{ gap: 16 }}>
            <div>
              <div className="text-xs font-semibold text-emerald-600 mb-2">Top 5 Healthiest</div>
              <div className="space-y-2">
                {[...branches].sort((a, b) => b.health - a.health).slice(0, 5).map((b) => (
                  <div key={b.id} className="flex items-center gap-2">
                    <HealthDot value={b.health} />
                    <span className="text-sm text-ink-700 truncate" style={{ flex: 1 }}>{b.branch}</span>
                    <span className="text-sm font-bold text-emerald-600">{b.health}</span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <div className="text-xs font-semibold text-red-600 mb-2">Needs Attention</div>
              <div className="space-y-2">
                {[...branches].sort((a, b) => a.health - b.health).slice(0, 5).map((b) => (
                  <div key={b.id} className="flex items-center gap-2">
                    <HealthDot value={b.health} />
                    <span className="text-sm text-ink-700 truncate" style={{ flex: 1 }}>{b.branch}</span>
                    <span className="text-sm font-bold text-red-600">{b.health}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}
