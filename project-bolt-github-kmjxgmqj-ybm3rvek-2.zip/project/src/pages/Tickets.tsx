import { Card, KPI, Badge } from '../components/ui'
import {
  Ticket, CircleAlert as AlertCircle, Clock, Gauge, Activity, ArrowRight,
} from 'lucide-react'
import { incidents, incidentMetrics, incidentTimeline, branches } from '../data/mockData'

const severityColors: Record<string, string> = {
  Critical: '#ef4444', High: '#f59e0b', Medium: '#3b82f6', Low: '#64748b',
}
const statusColors: Record<string, string> = {
  Open: '#3b82f6', 'In Progress': '#f59e0b', Escalated: '#ef4444', Resolved: '#10b981',
}
const timelineTypeColors: Record<string, string> = {
  alert: '#ef4444', created: '#3b82f6', escalation: '#f59e0b', assignment: '#8b5cf6', notification: '#64748b', action: '#10b981', update: '#64748b',
}

export default function Tickets() {
  return (
    <div>
      <div className="space-y-6">
        {/* Incident metrics */}
        <div className="grid grid-cols-2 md:grid-cols-6" style={{ gap: 12 }}>
          <KPI icon={<Ticket style={{ width: 18, height: 18 }} />} label="Open Incidents" value={String(incidentMetrics.openIncidents)} tone="blue" />
          <KPI icon={<AlertCircle style={{ width: 18, height: 18 }} />} label="Critical" value={String(incidentMetrics.criticalIncidents)} tone="red" />
          <KPI icon={<Clock style={{ width: 18, height: 18 }} />} label="SLA Breaches" value={String(incidentMetrics.slaBreaches)} tone="red" />
          <KPI icon={<Gauge style={{ width: 18, height: 18 }} />} label="Avg MTTD" value={`${incidentMetrics.avgMttd}m`} tone="amber" hint="Mean Time to Detect" />
          <KPI icon={<Activity style={{ width: 18, height: 18 }} />} label="Avg MTTR" value={`${incidentMetrics.avgMttr}m`} tone="green" hint="Mean Time to Resolve" />
          <KPI icon={<Clock style={{ width: 18, height: 18 }} />} label="Avg Age" value={`${incidentMetrics.avgIncidentAge}h`} tone="amber" />
        </div>

        {/* Incident list */}
        <Card title="Active Incidents" subtitle="All open and in-progress incidents across the branch network">
          <div className="space-y-1">
            <div className="flex items-center text-xs font-semibold text-ink-400 px-2 pb-2" style={{ borderBottom: '1px solid var(--ink-100)' }}>
              <span style={{ width: 90 }}>ID</span>
              <span style={{ flex: 1 }}>Title</span>
              <span style={{ width: 80 }}>Branch</span>
              <span style={{ width: 70, textAlign: 'center' }}>Severity</span>
              <span style={{ width: 80, textAlign: 'center' }}>Status</span>
              <span style={{ width: 70, textAlign: 'center' }}>MTTD</span>
              <span style={{ width: 70, textAlign: 'center' }}>SLA</span>
            </div>
            {incidents.map((inc) => (
              <div key={inc.id} className="flex items-center px-2 py-2 rounded-lg hover:bg-ink-50 transition-colors">
                <span className="text-xs font-mono text-ink-500" style={{ width: 90 }}>{inc.id}</span>
                <div className="min-w-0" style={{ flex: 1 }}>
                  <div className="text-sm font-medium text-ink-800 truncate">{inc.title}</div>
                  <div className="text-xs text-ink-400 truncate">{inc.impact}</div>
                </div>
                <span className="text-xs text-ink-600 truncate" style={{ width: 80 }}>{inc.branch.split(' - ')[0]}</span>
                <span style={{ width: 70, textAlign: 'center' }}>
                  <span className="text-xs font-bold" style={{ color: severityColors[inc.severity] }}>{inc.severity}</span>
                </span>
                <span style={{ width: 80, textAlign: 'center' }}>
                  <Badge tone={inc.status === 'Resolved' ? 'green' : inc.status === 'Escalated' ? 'red' : inc.status === 'In Progress' ? 'amber' : 'blue'}>{inc.status}</Badge>
                </span>
                <span className="text-xs text-ink-500" style={{ width: 70, textAlign: 'center' }}>{inc.mttd}m</span>
                <span style={{ width: 70, textAlign: 'center' }}>
                  {inc.slaBreached ? <Badge tone="red">Breached</Badge> : <Badge tone="green">OK</Badge>}
                </span>
              </div>
            ))}
          </div>
        </Card>

        {/* Incident timeline */}
        <Card title="Incident Timeline — INC-2026-001" subtitle="Kolkata - Park Street SIP trunk failure (Critical)">
          <div className="space-y-2">
            {incidentTimeline.map((t, i) => {
              const color = timelineTypeColors[t.type] || '#64748b'
              return (
                <div key={i} className="flex items-start gap-3">
                  <div className="flex flex-col items-center" style={{ flexShrink: 0 }}>
                    <span style={{ width: 10, height: 10, borderRadius: '50%', background: color, border: '2px solid white', boxShadow: `0 0 0 2px ${color}` }} />
                    {i < incidentTimeline.length - 1 && <span style={{ width: 2, flex: 1, background: 'var(--ink-100)', minHeight: 20 }} />}
                  </div>
                  <div className="pb-3">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono text-ink-500">{t.time}</span>
                      <span className="text-sm font-medium text-ink-800">{t.event}</span>
                    </div>
                    <div className="text-xs text-ink-400">{t.actor}</div>
                  </div>
                </div>
              )
            })}
          </div>
        </Card>

        {/* Incident correlation graph */}
        <Card title="Incident Correlation" subtitle="How incidents cascade across domains — Kolkata example">
          <div className="p-4 rounded-lg" style={{ background: 'var(--ink-50)' }}>
            <div className="flex items-center flex-wrap" style={{ gap: 8 }}>
              <div className="px-3 py-2 rounded-lg" style={{ background: '#fef2f2', border: '1px solid #fecaca' }}>
                <div className="text-xs font-bold text-red-600">Network Failure</div>
                <div className="text-xs text-ink-400">WAN circuit down</div>
              </div>
              <ArrowRight style={{ width: 16, height: 16, color: 'var(--ink-400)' }} />
              <div className="px-3 py-2 rounded-lg" style={{ background: '#fffbeb', border: '1px solid #fef3c7' }}>
                <div className="text-xs font-bold text-amber-600">Telephony</div>
                <div className="text-xs text-ink-400">SIP trunk unavailable</div>
              </div>
              <ArrowRight style={{ width: 16, height: 16, color: 'var(--ink-400)' }} />
              <div className="px-3 py-2 rounded-lg" style={{ background: '#fffbeb', border: '1px solid #fef3c7' }}>
                <div className="text-xs font-bold text-amber-600">Application</div>
                <div className="text-xs text-ink-400">IVR self-service down</div>
              </div>
              <ArrowRight style={{ width: 16, height: 16, color: 'var(--ink-400)' }} />
              <div className="px-3 py-2 rounded-lg" style={{ background: '#eff6ff', border: '1px solid #bfdbfe' }}>
                <div className="text-xs font-bold text-blue-600">Customer Impact</div>
                <div className="text-xs text-ink-400">Queue wait {'>'} 6 min</div>
              </div>
              <ArrowRight style={{ width: 16, height: 16, color: 'var(--ink-400)' }} />
              <div className="px-3 py-2 rounded-lg" style={{ background: '#fef2f2', border: '1px solid #fecaca' }}>
                <div className="text-xs font-bold text-red-600">Health Score</div>
                <div className="text-xs text-ink-400">Dropped to 79</div>
              </div>
            </div>
          </div>
        </Card>

        {/* Incidents by branch */}
        <Card title="Incidents by Branch" subtitle="Incident count and severity distribution">
          <div className="space-y-1">
            {branches.map((b) => {
              const bIncidents = incidents.filter((i) => i.branchId === b.id)
              if (bIncidents.length === 0) return null
              return (
                <div key={b.id} className="flex items-center gap-3 px-2 py-2 rounded-lg hover:bg-ink-50 transition-colors">
                  <span className="text-sm font-medium text-ink-800 truncate" style={{ flex: 1 }}>{b.branch}</span>
                  <div className="flex items-center gap-1">
                    {bIncidents.map((inc) => (
                      <span key={inc.id} style={{ width: 8, height: 8, borderRadius: 2, background: severityColors[inc.severity] }} title={`${inc.id}: ${inc.title}`} />
                    ))}
                  </div>
                  <Badge tone={bIncidents.some((i) => i.severity === 'Critical') ? 'red' : bIncidents.some((i) => i.severity === 'High') ? 'amber' : 'blue'}>
                    {bIncidents.length} incident{bIncidents.length > 1 ? 's' : ''}
                  </Badge>
                </div>
              )
            })}
          </div>
        </Card>
      </div>
    </div>
  )
}
