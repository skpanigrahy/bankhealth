import { Card, KPI, Badge } from '../components/ui'
import { CalendarClock, TriangleAlert as AlertTriangle, Bell, Wrench, Rocket, FileCheck } from 'lucide-react'
import { events, branches } from '../data/mockData'

const typeIcons: Record<string, any> = {
  Incident: AlertTriangle, Alert: Bell, Maintenance: Wrench, Deployment: Rocket, Audit: FileCheck,
}
const typeColors: Record<string, string> = {
  Incident: '#ef4444', Alert: '#f59e0b', Maintenance: '#10b981', Deployment: '#3b82f6', Audit: '#8b5cf6',
}
const severityColors: Record<string, string> = {
  Critical: '#ef4444', High: '#f59e0b', Medium: '#3b82f6', Low: '#64748b', Info: '#94a3b8',
}

export default function Events() {
  const total = events.length
  const incidents = events.filter((e) => e.type === 'Incident').length
  const alerts = events.filter((e) => e.type === 'Alert').length
  const maintenance = events.filter((e) => e.type === 'Maintenance').length

  return (
    <div>
      <div className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4" style={{ gap: 12 }}>
          <KPI icon={<CalendarClock style={{ width: 18, height: 18 }} />} label="Total Events" value={String(total)} tone="blue" />
          <KPI icon={<AlertTriangle style={{ width: 18, height: 18 }} />} label="Incidents" value={String(incidents)} tone="red" />
          <KPI icon={<Bell style={{ width: 18, height: 18 }} />} label="Alerts" value={String(alerts)} tone="amber" />
          <KPI icon={<Wrench style={{ width: 18, height: 18 }} />} label="Maintenance" value={String(maintenance)} tone="green" />
        </div>

        {/* Event timeline */}
        <Card title="Event Timeline" subtitle="Chronological view of incidents, alerts, maintenance, and deployments">
          <div className="space-y-3">
            {events.map((e, i) => {
              const Icon = typeIcons[e.type] || Bell
              const color = typeColors[e.type] || '#64748b'
              return (
                <div key={e.id} className="flex items-start gap-3">
                  <div className="flex flex-col items-center" style={{ flexShrink: 0 }}>
                    <div style={{
                      width: 32, height: 32, borderRadius: 8, background: `${color}1a`,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                    }}>
                      <Icon style={{ width: 16, height: 16, color }} />
                    </div>
                    {i < events.length - 1 && <span style={{ width: 2, flex: 1, background: 'var(--ink-100)', minHeight: 30 }} />}
                  </div>
                  <div className="flex-1 pb-3">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-semibold text-ink-800">{e.title}</span>
                      <Badge tone={e.severity === 'Critical' ? 'red' : e.severity === 'High' ? 'amber' : e.severity === 'Medium' ? 'blue' : 'neutral'}>{e.severity}</Badge>
                      <span className="text-xs text-ink-400">{e.type}</span>
                    </div>
                    <div className="text-sm text-ink-600 mt-1">{e.description}</div>
                    <div className="flex items-center gap-3 mt-1">
                      <span className="text-xs text-ink-400">{e.branch}</span>
                      <span className="text-xs text-ink-400">·</span>
                      <span className="text-xs text-ink-400">{e.timestamp}</span>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </Card>

        {/* Events by branch */}
        <Card title="Events by Branch" subtitle="Event count and severity distribution">
          <div className="space-y-1">
            {branches.map((b) => {
              const bEvents = events.filter((e) => e.branchId === b.id)
              if (bEvents.length === 0) return null
              return (
                <div key={b.id} className="flex items-center gap-3 px-2 py-2 rounded-lg hover:bg-ink-50 transition-colors">
                  <span className="text-sm font-medium text-ink-800 truncate" style={{ flex: 1 }}>{b.branch}</span>
                  <div className="flex items-center gap-1">
                    {bEvents.map((e) => (
                      <span key={e.id} style={{ width: 8, height: 8, borderRadius: 2, background: severityColors[e.severity] }} title={`${e.type}: ${e.title}`} />
                    ))}
                  </div>
                  <Badge tone={bEvents.some((e) => e.severity === 'Critical') ? 'red' : bEvents.some((e) => e.severity === 'High') ? 'amber' : 'blue'}>
                    {bEvents.length} event{bEvents.length > 1 ? 's' : ''}
                  </Badge>
                </div>
              )
            })}
          </div>
        </Card>
      </div>
    </div>
  )
}
