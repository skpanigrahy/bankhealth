import { Card, KPI, Badge, ProgressBar } from '../components/ui'
import {
  Activity, CircleAlert as AlertCircle, CircleCheck as CheckCircle2, Gauge, Layers,
} from 'lucide-react'
import { applications, branches } from '../data/mockData'

const categoryColors: Record<string, string> = {
  'Core Banking': '#3b82f6', Teller: '#10b981', CRM: '#8b5cf6',
  Authentication: '#f59e0b', 'Branch Portal': '#ec4899', Payments: '#06b6d4',
}

export default function ApplicationHealth() {
  const total = applications.length
  const healthy = applications.filter((a) => a.status === 'Healthy').length
  const warning = applications.filter((a) => a.status === 'Warning').length
  const critical = applications.filter((a) => a.status === 'Critical').length
  const avgAvail = Math.round(applications.reduce((s, a) => s + a.availability, 0) / total * 100) / 100
  const avgLatency = Math.round(applications.reduce((s, a) => s + a.latency, 0) / total)

  const byCategory = [...new Set(applications.map((a) => a.category))].map((cat) => {
    const items = applications.filter((a) => a.category === cat)
    return {
      category: cat,
      total: items.length,
      healthy: items.filter((a) => a.status === 'Healthy').length,
      avgAvail: Math.round(items.reduce((s, a) => s + a.availability, 0) / items.length * 100) / 100,
    }
  })

  return (
    <div>
      <div className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4" style={{ gap: 12 }}>
          <KPI icon={<Activity style={{ width: 18, height: 18 }} />} label="Total Apps" value={String(total)} tone="blue" />
          <KPI icon={<CheckCircle2 style={{ width: 18, height: 18 }} />} label="Avg Availability" value={`${avgAvail}%`} tone="green" />
          <KPI icon={<Gauge style={{ width: 18, height: 18 }} />} label="Avg Latency" value={`${avgLatency}ms`} tone="amber" />
          <KPI icon={<AlertCircle style={{ width: 18, height: 18 }} />} label="Critical Apps" value={String(critical)} tone="red" />
        </div>

        {/* App category summary */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6" style={{ gap: 12 }}>
          {byCategory.map((c) => {
            const color = categoryColors[c.category]
            return (
              <Card key={c.category}>
                <div className="flex items-center gap-2 mb-2">
                  <span style={{ width: 10, height: 10, borderRadius: 3, background: color }} />
                  <span className="text-xs font-bold text-ink-800">{c.category}</span>
                </div>
                <div className="text-lg font-bold text-ink-900">{c.avgAvail}%</div>
                <div className="text-xs text-ink-400">{c.healthy}/{c.total} healthy</div>
              </Card>
            )
          })}
        </div>

        {/* Application status by branch */}
        <Card title="Application Status by Branch" subtitle="Core banking, teller, CRM, auth, portal, payments">
          <div className="space-y-1">
            <div className="flex items-center text-xs font-semibold text-ink-400 px-2 pb-2" style={{ borderBottom: '1px solid var(--ink-100)' }}>
              <span style={{ flex: 1 }}>Branch</span>
              <span style={{ width: 80, textAlign: 'center' }}>Availability</span>
              <span style={{ width: 60, textAlign: 'center' }}>Latency</span>
              <span style={{ width: 60, textAlign: 'center' }}>Errors</span>
              <span style={{ width: 60, textAlign: 'center' }}>Status</span>
            </div>
            {branches.map((b) => {
              const branchApps = applications.filter((a) => a.branchId === b.id)
              const branchAvgAvail = Math.round(branchApps.reduce((s, a) => s + a.availability, 0) / branchApps.length * 100) / 100
              const branchAvgLat = Math.round(branchApps.reduce((s, a) => s + a.latency, 0) / branchApps.length)
              const branchAvgErr = Math.round(branchApps.reduce((s, a) => s + a.errorRate, 0) / branchApps.length * 100) / 100
              const worstStatus = branchApps.some((a) => a.status === 'Critical') ? 'Critical' : branchApps.some((a) => a.status === 'Warning') ? 'Warning' : 'Healthy'
              return (
                <div key={b.id} className="flex items-center px-2 py-2 rounded-lg hover:bg-ink-50 transition-colors">
                  <span className="text-sm font-medium text-ink-800 truncate" style={{ flex: 1 }}>{b.branch}</span>
                  <span className="text-sm font-semibold" style={{ width: 80, textAlign: 'center', color: branchAvgAvail >= 99 ? 'var(--emerald-600)' : branchAvgAvail >= 95 ? 'var(--amber-600)' : 'var(--red-600)' }}>{branchAvgAvail}%</span>
                  <span className="text-sm text-ink-600" style={{ width: 60, textAlign: 'center' }}>{branchAvgLat}ms</span>
                  <span className="text-sm text-ink-600" style={{ width: 60, textAlign: 'center' }}>{branchAvgErr}%</span>
                  <span style={{ width: 60, textAlign: 'center' }}>
                    <Badge tone={worstStatus === 'Healthy' ? 'green' : worstStatus === 'Warning' ? 'amber' : 'red'}>{worstStatus}</Badge>
                  </span>
                </div>
              )
            })}
          </div>
        </Card>

        {/* Critical/Warning apps detail */}
        {applications.filter((a) => a.status !== 'Healthy').length > 0 && (
          <Card title="Applications Requiring Attention" subtitle="Apps with degraded availability or elevated error rates">
            <div className="space-y-1">
              {applications.filter((a) => a.status !== 'Healthy').map((a) => (
                <div key={`${a.branchId}-${a.name}`} className="flex items-center gap-3 p-2 rounded-lg hover:bg-ink-50 transition-colors">
                  <span style={{ width: 8, height: 8, borderRadius: '50%', background: a.status === 'Critical' ? 'var(--red-500)' : 'var(--amber-500)' }} />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-ink-800">{a.branch} — {a.name}</div>
                    <div className="text-xs text-ink-400">Avail: {a.availability}% · Latency: {a.latency}ms · Errors: {a.errorRate}%</div>
                  </div>
                  <div className="flex items-center gap-1">
                    <Layers style={{ width: 12, height: 12, color: 'var(--ink-400)' }} />
                    <span className="text-xs text-ink-400">{a.dependencies.length} deps</span>
                  </div>
                  <Badge tone={a.status === 'Critical' ? 'red' : 'amber'}>{a.status}</Badge>
                </div>
              ))}
            </div>
          </Card>
        )}
      </div>
    </div>
  )
}
