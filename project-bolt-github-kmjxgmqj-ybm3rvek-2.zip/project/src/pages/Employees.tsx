import { Card, KPI, Badge, ProgressBar } from '../components/ui'
import { Users, UserCheck, UserMinus, Award, Search } from 'lucide-react'
import { useState } from 'react'
import { employees, branches } from '../data/mockData'

export default function Employees() {
  const [search, setSearch] = useState('')
  const [branchFilter, setBranchFilter] = useState('all')

  const filtered = employees.filter((e) => {
    if (branchFilter !== 'all' && e.branchId !== branchFilter) return false
    if (search && !e.name.toLowerCase().includes(search.toLowerCase()) && !e.role.toLowerCase().includes(search.toLowerCase())) return false
    return true
  })

  const total = employees.length
  const active = employees.filter((e) => e.status === 'Active').length
  const onLeave = employees.filter((e) => e.status === 'On Leave').length
  const remote = employees.filter((e) => e.status === 'Remote').length
  const certified = employees.filter((e) => e.certifications.length > 0).length
  const avgUtil = Math.round(employees.reduce((s, e) => s + e.utilization, 0) / total)

  const byRole = [...new Set(employees.map((e) => e.role))].map((role) => ({
    role,
    count: employees.filter((e) => e.role === role).length,
  })).sort((a, b) => b.count - a.count)

  return (
    <div>
      <div className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-6" style={{ gap: 12 }}>
          <KPI icon={<Users style={{ width: 18, height: 18 }} />} label="Total Employees" value={String(total)} tone="blue" />
          <KPI icon={<UserCheck style={{ width: 18, height: 18 }} />} label="Active" value={String(active)} tone="green" />
          <KPI icon={<UserMinus style={{ width: 18, height: 18 }} />} label="On Leave" value={String(onLeave)} tone="amber" />
          <KPI icon={<Users style={{ width: 18, height: 18 }} />} label="Remote" value={String(remote)} tone="blue" />
          <KPI icon={<Award style={{ width: 18, height: 18 }} />} label="Certified" value={String(certified)} tone="green" />
          <KPI icon={<Users style={{ width: 18, height: 18 }} />} label="Avg Utilization" value={`${avgUtil}%`} tone="amber" />
        </div>

        {/* Role distribution */}
        <Card title="Role Distribution" subtitle="Headcount by role across all branches">
          <div className="grid grid-cols-2 md:grid-cols-4" style={{ gap: 12 }}>
            {byRole.map((r) => (
              <div key={r.role} className="p-3 rounded-lg" style={{ background: 'var(--ink-50)' }}>
                <div className="text-xs text-ink-400">{r.role}</div>
                <div className="text-lg font-bold text-ink-900">{r.count}</div>
              </div>
            ))}
          </div>
        </Card>

        {/* Employee directory */}
        <Card title="Employee Directory" subtitle={`${filtered.length} employees`}>
          <div className="flex items-center gap-3 mb-4">
            <div className="flex items-center gap-2 px-3 py-2 rounded-lg" style={{ background: 'var(--ink-50)', border: '1px solid var(--ink-200)', flex: 1 }}>
              <Search style={{ width: 15, height: 15, color: 'var(--ink-400)' }} />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by name or role..."
                style={{ flex: 1, border: 'none', background: 'none', outline: 'none', fontSize: 13, color: 'var(--ink-800)' }}
              />
            </div>
            <select
              value={branchFilter}
              onChange={(e) => setBranchFilter(e.target.value)}
              className="px-3 py-2 rounded-lg"
              style={{ background: 'var(--ink-50)', border: '1px solid var(--ink-200)', fontSize: 13, color: 'var(--ink-700)', borderRadius: 8 }}
            >
              <option value="all">All Branches</option>
              {branches.map((b) => <option key={b.id} value={b.id}>{b.branch}</option>)}
            </select>
          </div>

          <div className="space-y-1">
            <div className="flex items-center text-xs font-semibold text-ink-400 px-2 pb-2" style={{ borderBottom: '1px solid var(--ink-100)' }}>
              <span style={{ flex: 1 }}>Name</span>
              <span style={{ width: 120 }}>Role</span>
              <span style={{ width: 100 }}>Branch</span>
              <span style={{ width: 70, textAlign: 'center' }}>Status</span>
              <span style={{ width: 60, textAlign: 'center' }}>Util.</span>
              <span style={{ width: 80, textAlign: 'center' }}>Certs</span>
            </div>
            {filtered.slice(0, 50).map((e) => (
              <div key={e.id} className="flex items-center px-2 py-2 rounded-lg hover:bg-ink-50 transition-colors">
                <div className="flex items-center gap-2" style={{ flex: 1 }}>
                  <span style={{
                    width: 28, height: 28, borderRadius: '50%', background: 'var(--brand-100)', color: 'var(--brand-700)',
                    fontSize: 11, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                  }}>{e.name.split(' ').map((n) => n[0]).join('')}</span>
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-ink-800 truncate">{e.name}</div>
                    <div className="text-xs text-ink-400 truncate">{e.email}</div>
                  </div>
                </div>
                <span className="text-xs text-ink-600 truncate" style={{ width: 120 }}>{e.role}</span>
                <span className="text-xs text-ink-500 truncate" style={{ width: 100 }}>{e.branch.split(' - ')[0]}</span>
                <span style={{ width: 70, textAlign: 'center' }}>
                  <Badge tone={e.status === 'Active' ? 'green' : e.status === 'On Leave' ? 'amber' : 'blue'}>{e.status}</Badge>
                </span>
                <span style={{ width: 60, textAlign: 'center' }}>
                  <span className="text-xs font-semibold" style={{ color: e.utilization >= 80 ? 'var(--red-600)' : e.utilization >= 70 ? 'var(--amber-600)' : 'var(--emerald-600)' }}>{e.utilization}%</span>
                </span>
                <span style={{ width: 80, textAlign: 'center' }}>
                  {e.certifications.length > 0 ? (
                    <span className="text-xs text-ink-500">{e.certifications.length} cert{e.certifications.length > 1 ? 's' : ''}</span>
                  ) : <span className="text-xs text-ink-300">—</span>}
                </span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  )
}
