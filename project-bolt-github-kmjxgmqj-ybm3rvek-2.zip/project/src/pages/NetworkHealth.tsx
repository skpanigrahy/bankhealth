import { Card, KPI, Badge, ProgressBar } from '../components/ui'
import { Network, Wifi, TriangleAlert as AlertTriangle, Activity, Gauge, Radio, Server } from 'lucide-react'
import { branches, networkCircuits } from '../data/mockData'

const typeColors: Record<string, string> = {
  WAN: '#3b82f6', LAN: '#10b981', WiFi: '#8b5cf6', 'SIP Trunk': '#f59e0b',
}

export default function NetworkHealth() {
  const wanCircuits = networkCircuits.filter((c) => c.type === 'WAN')
  const sipCircuits = networkCircuits.filter((c) => c.type === 'SIP Trunk')
  const avgLatency = Math.round(wanCircuits.reduce((s, c) => s + c.latency, 0) / wanCircuits.length)
  const avgUtil = Math.round(wanCircuits.reduce((s, c) => s + c.utilization, 0) / wanCircuits.length)
  const degraded = networkCircuits.filter((c) => c.status !== 'Healthy').length
  const failed = networkCircuits.filter((c) => c.status === 'Critical').length

  return (
    <div>
      <div className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4" style={{ gap: 12 }}>
          <KPI icon={<Network style={{ width: 18, height: 18 }} />} label="Network Health" value="94%" tone="green" delta="1" trend="up" />
          <KPI icon={<Gauge style={{ width: 18, height: 18 }} />} label="Avg WAN Latency" value={`${avgLatency}ms`} tone="blue" delta="2" trend="down" />
          <KPI icon={<AlertTriangle style={{ width: 18, height: 18 }} />} label="Degraded Circuits" value={String(degraded)} tone="amber" />
          <KPI icon={<Activity style={{ width: 18, height: 18 }} />} label="Critical / Failed" value={String(failed)} tone="red" />
        </div>

        {/* Circuit type summary */}
        <div className="grid grid-cols-2 md:grid-cols-4" style={{ gap: 12 }}>
          {(['WAN', 'LAN', 'WiFi', 'SIP Trunk'] as const).map((type) => {
            const circuits = networkCircuits.filter((c) => c.type === type)
            const healthy = circuits.filter((c) => c.status === 'Healthy').length
            const Icon = type === 'WAN' ? Network : type === 'LAN' ? Server : type === 'WiFi' ? Wifi : Radio
            const color = typeColors[type]
            return (
              <Card key={type}>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Icon style={{ width: 16, height: 16, color }} />
                    <span className="text-sm font-bold text-ink-800">{type}</span>
                  </div>
                  <Badge tone={healthy === circuits.length ? 'green' : healthy >= circuits.length * 0.8 ? 'amber' : 'red'}>
                    {healthy}/{circuits.length}
                  </Badge>
                </div>
                <ProgressBar value={healthy} max={circuits.length} color={color} />
                <div className="text-xs text-ink-400 mt-2">{circuits.length} circuits monitored</div>
              </Card>
            )
          })}
        </div>

        {/* WAN circuit details */}
        <Card title="WAN Circuit Status" subtitle="Primary circuit health and utilization by branch">
          <div className="space-y-1">
            <div className="flex items-center text-xs font-semibold text-ink-400 px-2 pb-2" style={{ borderBottom: '1px solid var(--ink-100)' }}>
              <span style={{ flex: 1 }}>Branch</span>
              <span style={{ width: 80 }}>Provider</span>
              <span style={{ width: 80 }}>Bandwidth</span>
              <span style={{ width: 120 }}>Utilization</span>
              <span style={{ width: 50, textAlign: 'center' }}>Latency</span>
              <span style={{ width: 50, textAlign: 'center' }}>Loss</span>
              <span style={{ width: 60, textAlign: 'center' }}>Status</span>
            </div>
            {wanCircuits.map((c) => (
              <div key={c.branchId} className="flex items-center px-2 py-2 rounded-lg hover:bg-ink-50 transition-colors">
                <span className="text-sm font-medium text-ink-800 truncate" style={{ flex: 1 }}>{c.branch}</span>
                <span className="text-xs text-ink-500" style={{ width: 80 }}>{c.provider}</span>
                <span className="text-xs text-ink-500" style={{ width: 80 }}>{c.bandwidth}</span>
                <div style={{ width: 120 }}>
                  <div className="flex items-center gap-2">
                    <ProgressBar value={c.utilization} max={100} color={c.utilization > 85 ? '#ef4444' : c.utilization > 70 ? '#f59e0b' : '#10b981'} />
                    <span className="text-xs text-ink-500" style={{ width: 32 }}>{c.utilization}%</span>
                  </div>
                </div>
                <span className="text-xs text-ink-600" style={{ width: 50, textAlign: 'center' }}>{c.latency}ms</span>
                <span className="text-xs text-ink-600" style={{ width: 50, textAlign: 'center' }}>{c.packetLoss}%</span>
                <span style={{ width: 60, textAlign: 'center' }}>
                  <Badge tone={c.status === 'Healthy' ? 'green' : c.status === 'Warning' ? 'amber' : 'red'}>{c.status}</Badge>
                </span>
              </div>
            ))}
          </div>
        </Card>

        {/* SIP Trunk details */}
        <Card title="SIP Trunk Status" subtitle="Telephony trunk health for IVR and voice services">
          <div className="space-y-1">
            {sipCircuits.map((c) => (
              <div key={c.branchId} className="flex items-center px-2 py-2 rounded-lg hover:bg-ink-50 transition-colors">
                <span className="text-sm font-medium text-ink-800 truncate" style={{ flex: 1 }}>{c.branch}</span>
                <span className="text-xs text-ink-500" style={{ width: 100 }}>{c.provider}</span>
                <span className="text-xs text-ink-500" style={{ width: 100 }}>{c.bandwidth}</span>
                <div style={{ width: 120 }}>
                  <div className="flex items-center gap-2">
                    <ProgressBar value={c.utilization} max={100} color={c.utilization > 85 ? '#ef4444' : c.utilization > 70 ? '#f59e0b' : '#10b981'} />
                    <span className="text-xs text-ink-500" style={{ width: 32 }}>{c.utilization}%</span>
                  </div>
                </div>
                <span className="text-xs text-ink-600" style={{ width: 50, textAlign: 'center' }}>{c.latency}ms</span>
                <span style={{ width: 60, textAlign: 'center' }}>
                  <Badge tone={c.status === 'Healthy' ? 'green' : 'red'}>{c.status}</Badge>
                </span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  )
}
