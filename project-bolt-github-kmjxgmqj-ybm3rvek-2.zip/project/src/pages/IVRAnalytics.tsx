import { Card, KPI, Badge, ProgressBar } from '../components/ui'
import { PhoneCall, PhoneOutgoing, PhoneIncoming, PhoneMissed, Gauge, Activity, Volume2, Mic, CircleArrowRight as ArrowRightCircle } from 'lucide-react'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, Legend, Cell,
} from 'recharts'
import { ivrFlows, ivrHourlyVolume, voiceQualityMetrics, branches } from '../data/mockData'

export default function IVRAnalytics() {
  const totalCalls = ivrFlows.reduce((s, f) => s + f.calls, 0)
  const avgContainment = Math.round(ivrFlows.reduce((s, f) => s + f.containment, 0) / ivrFlows.length)
  const totalTransfers = ivrFlows.reduce((s, f) => s + Math.round(f.calls * (100 - f.containment) / 100), 0)
  const avgAbandonment = Math.round(ivrFlows.reduce((s, f) => s + f.abandonment, 0) / ivrFlows.length * 10) / 10

  return (
    <div>
      <div className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4" style={{ gap: 12 }}>
          <KPI icon={<PhoneCall style={{ width: 18, height: 18 }} />} label="Total Calls (30d)" value={(totalCalls / 1000).toFixed(1) + 'K'} tone="blue" />
          <KPI icon={<PhoneOutgoing style={{ width: 18, height: 18 }} />} label="Containment Rate" value={`${avgContainment}%`} tone="green" delta="3" trend="up" />
          <KPI icon={<PhoneMissed style={{ width: 18, height: 18 }} />} label="Avg Abandonment" value={`${avgAbandonment}%`} tone="amber" delta="0.5" trend="down" />
          <KPI icon={<Gauge style={{ width: 18, height: 18 }} />} label="MOS Voice Quality" value={String(voiceQualityMetrics.avgMosScore)} tone="blue" />
        </div>

        {/* Voice quality metrics */}
        <div className="grid grid-cols-2 md:grid-cols-6" style={{ gap: 12 }}>
          <Card><div className="text-xs text-ink-400">Avg MOS Score</div><div className="text-lg font-bold text-ink-900">{voiceQualityMetrics.avgMosScore}</div></Card>
          <Card><div className="text-xs text-ink-400">Jitter Avg</div><div className="text-lg font-bold text-ink-900">{voiceQualityMetrics.jitterAvg}ms</div></Card>
          <Card><div className="text-xs text-ink-400">Jitter Peak</div><div className="text-lg font-bold text-amber-600">{voiceQualityMetrics.jitterPeak}ms</div></Card>
          <Card><div className="text-xs text-ink-400">Packet Loss</div><div className="text-lg font-bold text-ink-900">{voiceQualityMetrics.packetLossAvg}%</div></Card>
          <Card><div className="text-xs text-ink-400">Avg Latency</div><div className="text-lg font-bold text-ink-900">{voiceQualityMetrics.latencyAvg}ms</div></Card>
          <Card><div className="text-xs text-ink-400">Poor Quality Calls</div><div className="text-lg font-bold text-red-600">{voiceQualityMetrics.poorQualityCalls}</div></Card>
        </div>

        {/* Hourly call volume chart */}
        <Card title="Hourly Call Volume & Transfers" subtitle="Peak hour analysis — 12 PM sees highest traffic">
          <div style={{ width: '100%', height: 280 }}>
            <ResponsiveContainer>
              <BarChart data={ivrHourlyVolume} margin={{ top: 8, right: 8, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="hour" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={{ stroke: '#e2e8f0' }} />
                <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={{ stroke: '#e2e8f0' }} />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: '1px solid #e2e8f0' }} />
                <Bar dataKey="calls" name="Calls" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                <Bar dataKey="transfers" name="Transfers" fill="#f59e0b" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {/* IVR flow performance */}
        <Card title="IVR Flow Performance" subtitle="Containment rate by call flow — lower containment means more agent transfers">
          <div className="space-y-2">
            {ivrFlows.map((f) => {
              const transferCount = Math.round(f.calls * (100 - f.containment) / 100)
              return (
                <div key={f.name} className="p-3 rounded-lg" style={{ background: 'var(--ink-50)' }}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-semibold text-ink-800">{f.name}</span>
                    <div className="flex items-center gap-3">
                      <span className="text-xs text-ink-400">{f.calls.toLocaleString()} calls</span>
                      <Badge tone={f.containment >= 80 ? 'green' : f.containment >= 60 ? 'amber' : 'red'}>{f.containment}% contained</Badge>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div style={{ flex: 1 }}>
                      <ProgressBar value={f.containment} max={100} color={f.containment >= 80 ? '#10b981' : f.containment >= 60 ? '#f59e0b' : '#ef4444'} />
                    </div>
                    <span className="text-xs text-ink-500" style={{ width: 80 }}>Avg: {f.avgDuration}</span>
                    <span className="text-xs text-red-500" style={{ width: 70 }}>Abandon: {f.abandonment}%</span>
                    <span className="text-xs text-ink-500" style={{ width: 80 }}>→ {transferCount.toLocaleString()} transfers</span>
                  </div>
                </div>
              )
            })}
          </div>
        </Card>

        {/* Branch IVR performance */}
        <Card title="Branch IVR Performance" subtitle="Call volume and containment by branch">
          <div className="space-y-1">
            <div className="flex items-center text-xs font-semibold text-ink-400 px-2 pb-2" style={{ borderBottom: '1px solid var(--ink-100)' }}>
              <span style={{ flex: 1 }}>Branch</span>
              <span style={{ width: 80, textAlign: 'center' }}>Calls</span>
              <span style={{ width: 80, textAlign: 'center' }}>IVR Transfers</span>
              <span style={{ width: 80, textAlign: 'center' }}>Containment</span>
              <span style={{ width: 60, textAlign: 'center' }}>Wait Time</span>
            </div>
            {branches.map((b) => (
              <div key={b.id} className="flex items-center px-2 py-2 rounded-lg hover:bg-ink-50 transition-colors">
                <span className="text-sm font-medium text-ink-800 truncate" style={{ flex: 1 }}>{b.branch}</span>
                <span className="text-sm text-ink-600" style={{ width: 80, textAlign: 'center' }}>{b.calls.toLocaleString()}</span>
                <span className="text-sm text-ink-600" style={{ width: 80, textAlign: 'center' }}>{b.ivrTransfers.toLocaleString()}</span>
                <span style={{ width: 80, textAlign: 'center' }}>
                  <Badge tone={b.ivrContainment >= 78 ? 'green' : b.ivrContainment >= 70 ? 'amber' : 'red'}>{b.ivrContainment}%</Badge>
                </span>
                <span className="text-sm text-ink-600" style={{ width: 60, textAlign: 'center' }}>{b.waitTime}m</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  )
}
