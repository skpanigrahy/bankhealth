import { Card, KPI, Badge, ProgressBar } from '../components/ui'
import { Package, TriangleAlert as AlertTriangle, DollarSign, Box, Search } from 'lucide-react'
import { useState } from 'react'
import { inventory, branches } from '../data/mockData'

const categoryColors: Record<string, string> = {
  Hardware: '#3b82f6', Software: '#8b5cf6', 'Network Equipment': '#10b981',
  Furniture: '#f59e0b', Security: '#ef4444',
}
const lifecycleColors: Record<string, string> = {
  Active: '#10b981', Aging: '#f59e0b', 'Replacement Due': '#f97316', 'End of Life': '#ef4444',
}

export default function Inventory() {
  const [search, setSearch] = useState('')
  const [categoryFilter, setCategoryFilter] = useState('all')

  const filtered = inventory.filter((item) => {
    if (categoryFilter !== 'all' && item.category !== categoryFilter) return false
    if (search && !item.name.toLowerCase().includes(search.toLowerCase()) && !item.vendor.toLowerCase().includes(search.toLowerCase())) return false
    return true
  })

  const total = inventory.length
  const totalValue = inventory.reduce((s, i) => s + i.cost, 0)
  const eol = inventory.filter((i) => i.lifecycle === 'End of Life' || i.lifecycle === 'Replacement Due').length
  const aging = inventory.filter((i) => i.lifecycle === 'Aging').length

  const byCategory = [...new Set(inventory.map((i) => i.category))].map((cat) => ({
    category: cat,
    count: inventory.filter((i) => i.category === cat).length,
    value: inventory.filter((i) => i.category === cat).reduce((s, i) => s + i.cost, 0),
  }))

  return (
    <div>
      <div className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4" style={{ gap: 12 }}>
          <KPI icon={<Package style={{ width: 18, height: 18 }} />} label="Total Assets" value={String(total)} tone="blue" />
          <KPI icon={<DollarSign style={{ width: 18, height: 18 }} />} label="Total Value" value={`$${(totalValue / 1000000).toFixed(1)}M`} tone="green" />
          <KPI icon={<AlertTriangle style={{ width: 18, height: 18 }} />} label="Aging" value={String(aging)} tone="amber" />
          <KPI icon={<AlertTriangle style={{ width: 18, height: 18 }} />} label="EOL / Replace" value={String(eol)} tone="red" />
        </div>

        {/* Category breakdown */}
        <div className="grid grid-cols-2 md:grid-cols-5" style={{ gap: 12 }}>
          {byCategory.map((c) => {
            const color = categoryColors[c.category]
            return (
              <Card key={c.category}>
                <div className="flex items-center gap-2 mb-2">
                  <span style={{ width: 10, height: 10, borderRadius: 3, background: color }} />
                  <span className="text-xs font-bold text-ink-800">{c.category}</span>
                </div>
                <div className="text-lg font-bold text-ink-900">{c.count}</div>
                <div className="text-xs text-ink-400">${(c.value / 1000).toFixed(0)}K</div>
              </Card>
            )
          })}
        </div>

        {/* Asset register */}
        <Card title="Asset Register" subtitle={`${filtered.length} assets across ${branches.length} branches`}>
          <div className="flex items-center gap-3 mb-4">
            <div className="flex items-center gap-2 px-3 py-2 rounded-lg" style={{ background: 'var(--ink-50)', border: '1px solid var(--ink-200)', flex: 1 }}>
              <Search style={{ width: 15, height: 15, color: 'var(--ink-400)' }} />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by asset name or vendor..."
                style={{ flex: 1, border: 'none', background: 'none', outline: 'none', fontSize: 13, color: 'var(--ink-800)' }}
              />
            </div>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="px-3 py-2 rounded-lg"
              style={{ background: 'var(--ink-50)', border: '1px solid var(--ink-200)', fontSize: 13, color: 'var(--ink-700)', borderRadius: 8 }}
            >
              <option value="all">All Categories</option>
              {[...new Set(inventory.map((i) => i.category))].map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>

          <div className="space-y-1">
            <div className="flex items-center text-xs font-semibold text-ink-400 px-2 pb-2" style={{ borderBottom: '1px solid var(--ink-100)' }}>
              <span style={{ flex: 1 }}>Asset</span>
              <span style={{ width: 80 }}>Branch</span>
              <span style={{ width: 70 }}>Category</span>
              <span style={{ width: 70 }}>Vendor</span>
              <span style={{ width: 90 }}>Serial</span>
              <span style={{ width: 70, textAlign: 'center' }}>Lifecycle</span>
              <span style={{ width: 60, textAlign: 'right' }}>Cost</span>
            </div>
            {filtered.slice(0, 80).map((item) => (
              <div key={item.id} className="flex items-center px-2 py-2 rounded-lg hover:bg-ink-50 transition-colors">
                <div className="flex items-center gap-2" style={{ flex: 1 }}>
                  <Box style={{ width: 14, height: 14, color: categoryColors[item.category] }} />
                  <span className="text-sm font-medium text-ink-800 truncate">{item.name}</span>
                </div>
                <span className="text-xs text-ink-500 truncate" style={{ width: 80 }}>{item.branch.split(' - ')[0]}</span>
                <span style={{ width: 70 }}>
                  <span className="text-xs" style={{ color: categoryColors[item.category] }}>{item.category}</span>
                </span>
                <span className="text-xs text-ink-500 truncate" style={{ width: 70 }}>{item.vendor}</span>
                <span className="text-xs font-mono text-ink-400 truncate" style={{ width: 90 }}>{item.serialNumber}</span>
                <span style={{ width: 70, textAlign: 'center' }}>
                  <span className="text-xs font-semibold" style={{ color: lifecycleColors[item.lifecycle] }}>{item.lifecycle}</span>
                </span>
                <span className="text-sm font-semibold text-ink-700" style={{ width: 60, textAlign: 'right' }}>${item.cost.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  )
}
