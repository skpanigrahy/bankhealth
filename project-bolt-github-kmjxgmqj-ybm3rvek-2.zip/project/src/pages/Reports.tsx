import { Card, KPI, Badge } from '../components/ui'
import {
  FileBarChart, Download, Calendar, FileText, FileSpreadsheet, FileCheck,
  TrendingUp, Activity, HeartPulse, Network, Cpu, PhoneCall, Users, DollarSign,
  Clock, CheckCircle2, AlertTriangle,
} from 'lucide-react'
import { branches, incidents, executiveKPIs, incidentMetrics } from '../data/mockData'

const reportCategories = [
  {
    category: 'Executive Reports',
    color: '#3b82f6',
    bg: '#eff6ff',
    icon: FileBarChart,
    reports: [
      { name: 'Daily Branch Health Summary', schedule: 'Every day at 6:00 AM', lastRun: '2026-07-24 06:00', format: 'PDF', status: 'active' },
      { name: 'Weekly Executive Briefing', schedule: 'Every Monday at 7:00 AM', lastRun: '2026-07-22 07:00', format: 'PDF', status: 'active' },
      { name: 'Monthly SLA Compliance Report', schedule: '1st of every month', lastRun: '2026-07-01 09:00', format: 'PDF', status: 'active' },
      { name: 'Quarterly Board Review', schedule: 'Every quarter', lastRun: '2026-07-01 10:00', format: 'PDF', status: 'active' },
    ],
  },
  {
    category: 'Operational Reports',
    color: '#10b981',
    bg: '#ecfdf5',
    icon: Activity,
    reports: [
      { name: 'Weekly Network Performance', schedule: 'Every Monday at 8:00 AM', lastRun: '2026-07-22 08:00', format: 'Excel', status: 'active' },
      { name: 'Device Health Weekly', schedule: 'Every Friday at 5:00 PM', lastRun: '2026-07-19 17:00', format: 'Excel', status: 'active' },
      { name: 'Application Availability Monthly', schedule: '1st of every month', lastRun: '2026-07-01 08:00', format: 'Excel', status: 'active' },
    ],
  },
  {
    category: 'Incident Reports',
    color: '#ef4444',
    bg: '#fef2f2',
    icon: AlertTriangle,
    reports: [
      { name: 'Daily Incident Summary', schedule: 'Every day at 11:59 PM', lastRun: '2026-07-24 23:59', format: 'PDF', status: 'active' },
      { name: 'MTTD/MTTR Trend Report', schedule: 'Every Monday at 9:00 AM', lastRun: '2026-07-22 09:00', format: 'Excel', status: 'active' },
      { name: 'SLA Breach Analysis', schedule: 'Every Friday at 6:00 PM', lastRun: '2026-07-19 18:00', format: 'PDF', status: 'active' },
    ],
  },
  {
    category: 'IVR & Telephony',
    color: '#06b6d4',
    bg: '#ecfeff',
    icon: PhoneCall,
    reports: [
      { name: 'IVR Containment Weekly', schedule: 'Every Friday at 5:00 PM', lastRun: '2026-07-19 17:00', format: 'CSV', status: 'active' },
      { name: 'Voice Quality Monthly', schedule: '1st of every month', lastRun: '2026-07-01 08:00', format: 'Excel', status: 'active' },
      { name: 'Call Volume Trends', schedule: 'Every Monday at 8:00 AM', lastRun: '2026-07-22 08:00', format: 'CSV', status: 'active' },
    ],
  },
  {
    category: 'Inventory & Assets',
    color: '#f59e0b',
    bg: '#fffbeb',
    icon: FileSpreadsheet,
    reports: [
      { name: 'Quarterly Device Inventory', schedule: 'Every quarter', lastRun: '2026-07-01 10:00', format: 'Excel', status: 'active' },
      { name: 'Asset Lifecycle Report', schedule: 'Every month', lastRun: '2026-07-01 10:00', format: 'Excel', status: 'active' },
      { name: 'Warranty Expiry Report', schedule: 'Every Monday at 8:00 AM', lastRun: '2026-07-22 08:00', format: 'PDF', status: 'active' },
    ],
  },
  {
    category: 'Workforce',
    color: '#ec4899',
    bg: '#fdf2f8',
    icon: Users,
    reports: [
      { name: 'Employee Utilization Weekly', schedule: 'Every Friday at 5:00 PM', lastRun: '2026-07-19 17:00', format: 'Excel', status: 'active' },
      { name: 'Certification Status Report', schedule: 'Every month', lastRun: '2026-07-01 09:00', format: 'PDF', status: 'active' },
    ],
  },
]

const formatIcons: Record<string, any> = {
  PDF: FileText, Excel: FileSpreadsheet, CSV: FileCheck,
}

export default function Reports() {
  const totalReports = reportCategories.reduce((s, c) => s + c.reports.length, 0)
  const resolvedIncidents = incidents.filter((i) => i.status === 'Resolved').length

  return (
    <div>
      <div className="space-y-6">
        {/* Report KPIs */}
        <div className="grid grid-cols-2 md:grid-cols-5" style={{ gap: 12 }}>
          <KPI icon={<FileBarChart style={{ width: 18, height: 18 }} />} label="Total Reports" value={String(totalReports)} tone="blue" />
          <KPI icon={<Calendar style={{ width: 18, height: 18 }} />} label="Scheduled" value={String(totalReports)} tone="green" hint="All active" />
          <KPI icon={<Download style={{ width: 18, height: 18 }} />} label="Available Formats" value="3" tone="amber" hint="PDF, Excel, CSV" />
          <KPI icon={<Clock style={{ width: 18, height: 18 }} />} label="Last Run" value="2h ago" tone="blue" />
          <KPI icon={<CheckCircle2 style={{ width: 18, height: 18 }} />} label="Success Rate" value="100%" tone="green" />
        </div>

        {/* Quick stats */}
        <div className="grid grid-cols-2 md:grid-cols-4" style={{ gap: 12 }}>
          <Card>
            <div className="flex items-center gap-2 mb-1"><HeartPulse style={{ width: 14, height: 14, color: '#10b981' }} /><span className="text-xs text-ink-400">Avg Branch Health</span></div>
            <div className="text-xl font-bold text-ink-900">{executiveKPIs.overallHealth}%</div>
          </Card>
          <Card>
            <div className="flex items-center gap-2 mb-1"><AlertTriangle style={{ width: 14, height: 14, color: '#ef4444' }} /><span className="text-xs text-ink-400">Active Incidents</span></div>
            <div className="text-xl font-bold text-ink-900">{incidentMetrics.openIncidents}</div>
          </Card>
          <Card>
            <div className="flex items-center gap-2 mb-1"><TrendingUp style={{ width: 14, height: 14, color: '#3b82f6' }} /><span className="text-xs text-ink-400">Avg SLA</span></div>
            <div className="text-xl font-bold text-ink-900">{executiveKPIs.avgSla}%</div>
          </Card>
          <Card>
            <div className="flex items-center gap-2 mb-1"><DollarSign style={{ width: 14, height: 14, color: '#f59e0b' }} /><span className="text-xs text-ink-400">Cost Index</span></div>
            <div className="text-xl font-bold text-ink-900">{executiveKPIs.operationalCostIndex}</div>
          </Card>
        </div>

        {/* Report categories */}
        {reportCategories.map((cat) => {
          const FormatIcon = formatIcons[cat.reports[0].format] || FileText
          return (
            <Card key={cat.category} title={cat.category} subtitle={`${cat.reports.length} reports`}>
              <div className="space-y-2">
                {cat.reports.map((r, i) => {
                  const RIcon = formatIcons[r.format] || FileText
                  return (
                    <div key={i} className="report-card">
                      <div className="report-card-icon" style={{ background: cat.bg }}>
                        <cat.icon style={{ width: 20, height: 20, color: cat.color }} />
                      </div>
                      <div className="report-card-body">
                        <div className="report-card-title">{r.name}</div>
                        <div className="report-card-meta flex items-center gap-2">
                          <Calendar style={{ width: 11, height: 11 }} /> {r.schedule}
                          <span>·</span>
                          <span>Last run: {r.lastRun}</span>
                        </div>
                      </div>
                      <div className="report-card-actions">
                        <Badge tone="neutral">{r.format}</Badge>
                        <Badge tone="green">Active</Badge>
                        <button className="report-btn">
                          <Download style={{ width: 13, height: 13 }} /> Download
                        </button>
                        <button className="report-btn report-btn-primary">
                          Generate Now
                        </button>
                      </div>
                    </div>
                  )
                })}
              </div>
            </Card>
          )
        })}

        {/* On-demand report builder */}
        <Card title="On-Demand Report Builder" subtitle="Generate custom reports with filters">
          <div className="p-4 rounded-lg" style={{ background: 'var(--ink-50)' }}>
            <div className="grid grid-cols-2 md:grid-cols-4" style={{ gap: 12 }}>
              <div>
                <label className="text-xs font-semibold text-ink-500 mb-1 block">Report Type</label>
                <select className="text-sm rounded-lg" style={{ padding: '8px 12px', border: '1px solid var(--ink-200)', width: '100%', background: 'white', outline: 'none' }}>
                  <option>Branch Health Summary</option>
                  <option>Incident Analysis</option>
                  <option>Network Performance</option>
                  <option>Device Inventory</option>
                  <option>IVR Analytics</option>
                  <option>Employee Report</option>
                </select>
              </div>
              <div>
                <label className="text-xs font-semibold text-ink-500 mb-1 block">Region</label>
                <select className="text-sm rounded-lg" style={{ padding: '8px 12px', border: '1px solid var(--ink-200)', width: '100%', background: 'white', outline: 'none' }}>
                  <option>All Regions</option>
                  {[...new Set(branches.map((b) => b.region))].map((r) => <option key={r}>{r}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs font-semibold text-ink-500 mb-1 block">Format</label>
                <select className="text-sm rounded-lg" style={{ padding: '8px 12px', border: '1px solid var(--ink-200)', width: '100%', background: 'white', outline: 'none' }}>
                  <option>PDF</option>
                  <option>Excel</option>
                  <option>CSV</option>
                </select>
              </div>
              <div>
                <label className="text-xs font-semibold text-ink-500 mb-1 block">Date Range</label>
                <select className="text-sm rounded-lg" style={{ padding: '8px 12px', border: '1px solid var(--ink-200)', width: '100%', background: 'white', outline: 'none' }}>
                  <option>Last 7 days</option>
                  <option>Last 30 days</option>
                  <option>Last 90 days</option>
                  <option>Custom range</option>
                </select>
              </div>
            </div>
            <div className="flex items-center gap-3 mt-4">
              <button className="report-btn report-btn-primary" style={{ padding: '8px 16px' }}>
                <FileBarChart style={{ width: 14, height: 14 }} /> Generate Report
              </button>
              <button className="report-btn" style={{ padding: '8px 16px' }}>
                <Download style={{ width: 14, height: 14 }} /> Export All
              </button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}
