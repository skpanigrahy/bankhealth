import { useState, useRef, useEffect } from 'react'
import { Card, Badge } from '../components/ui'
import { Bot, Send, Sparkles, TrendingUp, AlertTriangle, Activity, Network, PhoneCall, Users, HeartPulse, FileBarChart, Zap } from 'lucide-react'
import { branches, incidents, devices, networkCircuits, aiRecommendations, executiveKPIs, regionPerformance, ivrFlows, incidentMetrics } from '../data/mockData'

interface Message {
  role: 'user' | 'assistant'
  text: string
  confidence?: number
  sources?: string[]
  actions?: { label: string; link: string }[]
}

const suggestedQuestions = [
  { icon: HeartPulse, text: 'Why is Kolkata health low?', color: '#ef4444' },
  { icon: AlertTriangle, text: 'Which branches need attention?', color: '#f59e0b' },
  { icon: Activity, text: 'Show critical incidents', color: '#3b82f6' },
  { icon: Network, text: 'Network status summary', color: '#10b981' },
  { icon: PhoneCall, text: 'Which IVR flows have high abandonment?', color: '#06b6d4' },
  { icon: TrendingUp, text: 'Compare regions', color: '#8b5cf6' },
  { icon: Users, text: 'Show offline devices', color: '#ec4899' },
  { icon: Zap, text: 'What are the AI recommendations?', color: '#0ea5e9' },
  { icon: FileBarChart, text: 'Generate an executive summary', color: '#64748b' },
]

function generateResponse(q: string): Message {
  const lower = q.toLowerCase()

  if (lower.includes('kolkata') || (lower.includes('why') && lower.includes('health'))) {
    return {
      role: 'assistant',
      text: `Kolkata - Park Street has a health score of 79 (Critical) due to a primary WAN circuit failure at 10:35 AM.\n\nRoot Cause Chain:\n1. Primary WAN circuit failure (10:35 AM)\n2. SIP trunk unavailable (10:38 AM)\n3. IVR self-service down (10:41 AM)\n4. Calls routed to backup queue (10:44 AM)\n5. Wait time exceeded 6 min (10:52 AM)\n6. Branch health dropped to 79 (10:55 AM)\n\nRecommended Actions:\n• Fail over to backup ISP circuit (94% confidence)\n• Dispatch network engineer to Kolkata (88% confidence)\n\nThe backup circuit is currently at 92% utilization. A field engineer has been dispatched and is expected on-site within 2 hours.`,
      confidence: 94,
      sources: ['INC-2026-001', 'Root Cause Analysis', 'AI Recommendations'],
      actions: [{ label: 'View Branch Detail', link: '/branch/BR-305' }, { label: 'View Incidents', link: '/tickets' }],
    }
  }
  if (lower.includes('attention') || lower.includes('which branch') || lower.includes('needs')) {
    const critical = branches.filter((b) => b.health < 85).sort((a, b) => a.health - b.health)
    return {
      role: 'assistant',
      text: `${critical.length} branches require immediate attention:\n\n${critical.map((b) => `• ${b.branch} — Health: ${b.health}, ${b.openTickets} tickets, ${b.devicesOffline} devices offline, SLA: ${b.sla}%`).join('\n')}\n\nKolkata is the most critical with an active SIP trunk outage affecting 1,200+ customers.\n\nThe East (India) region has the lowest average health at 79, driven primarily by the Kolkata outage.`,
      confidence: 96,
      sources: ['Branch Health', 'Incident Management', 'Regional Performance'],
      actions: [{ label: 'View Branch Health', link: '/branch-health' }, { label: 'View All Branches', link: '/branch-search' }],
    }
  }
  if (lower.includes('critical') && (lower.includes('incident') || lower.includes('ticket'))) {
    const crit = incidents.filter((i) => i.severity === 'Critical' && i.status !== 'Resolved')
    return {
      role: 'assistant',
      text: `There ${crit.length === 1 ? 'is' : 'are'} ${crit.length} critical incident${crit.length > 1 ? 's' : ''}:\n\n${crit.map((i) => `• ${i.id}: ${i.title}\n  Branch: ${i.branch}\n  Status: ${i.status}, Assigned: ${i.assignedTo}\n  MTTD: ${i.mttd} min, Created: ${i.createdAt}\n  Impact: ${i.impact}`).join('\n\n')}\n\nSLA status: ${crit.filter((i) => i.slaBreached).length} SLA breach(es). Average MTTD: ${Math.round(crit.reduce((s, i) => s + i.mttd, 0) / crit.length)} min.`,
      confidence: 100,
      sources: ['Incident Management'],
      actions: [{ label: 'View All Incidents', link: '/tickets' }],
    }
  }
  if (lower.includes('network') || lower.includes('wan') || lower.includes('latency')) {
    const degraded = networkCircuits.filter((c) => c.status !== 'Healthy')
    const avgLat = Math.round(networkCircuits.filter((c) => c.type === 'WAN').reduce((s, c) => s + c.latency, 0) / 27)
    return {
      role: 'assistant',
      text: `Network Status Summary:\n\n• Overall network availability: 99.1% (down 0.2% from last week)\n• Average WAN latency: ${avgLat}ms\n• ${degraded.length} degraded circuits across ${new Set(degraded.map((c) => c.branch)).size} branches\n\nMost Affected Branches:\n${degraded.slice(0, 5).map((c) => `• ${c.branch} — ${c.type}: ${c.status}, ${c.latency}ms, ${c.packetLoss}% loss`).join('\n')}\n\nThe primary concern is Kolkata's SIP trunk, which has been down since 10:35 AM. The backup circuit is at 92% utilization and approaching capacity limits.`,
      confidence: 92,
      sources: ['Network Health', 'Circuit Monitoring', 'Alert History'],
      actions: [{ label: 'View Network Health', link: '/network-health' }],
    }
  }
  if (lower.includes('ivr') || lower.includes('abandon') || lower.includes('call')) {
    const highAbandon = ivrFlows.filter((f) => f.abandonment > 8).sort((a, b) => b.abandonment - a.abandonment)
    return {
      role: 'assistant',
      text: `IVR Analytics Summary:\n\n• Total calls (30d): 61,490\n• Average containment: 75% (up 3% from last month)\n• Average abandonment: 7.9%\n• Peak hour: 12 PM with 4,180 calls\n\nHighest Abandonment Flows:\n${highAbandon.map((f) => `• ${f.name}: ${f.abandonment}% abandonment, ${f.containment}% containment, ${f.calls.toLocaleString()} calls`).join('\n')}\n\nRecommendation: Add self-service options for "Lost/Stolen Card" and "Live Agent Request" flows to reduce abandonment. The "Live Agent Request" flow has only 12% containment, meaning 88% of callers bypass IVR entirely.`,
      confidence: 91,
      sources: ['IVR Analytics', 'Voice Quality Metrics', 'Customer Journey'],
      actions: [{ label: 'View IVR Analytics', link: '/ivr-analytics' }],
    }
  }
  if (lower.includes('region') || lower.includes('compare')) {
    const regions = regionPerformance.slice(0, 8).sort((a, b) => a.avgHealth - b.avgHealth)
    return {
      role: 'assistant',
      text: `Regional Health Comparison (sorted by health):\n\n${regions.map((r, i) => `${i + 1}. ${r.region}: ${r.avgHealth} avg health (${r.branches} branches, ${r.incidents} incidents, ${r.avgSla}% SLA)`).join('\n')}\n\nLowest performing: East (India) at 79 — driven by Kolkata WAN/SIP outage.\nHighest performing: South (India) at 95 — led by Bengaluru MG Road (health: 95).\n\nThe Northeast US region has recovered 3.2% this week after resolving a previous network issue.`,
      confidence: 95,
      sources: ['Regional Performance', 'Branch Health'],
      actions: [{ label: 'View All Branches', link: '/branch-search' }],
    }
  }
  if (lower.includes('device') || lower.includes('offline')) {
    const off = devices.filter((d) => d.status === 'Offline')
    const degraded = devices.filter((d) => d.status === 'Degraded')
    return {
      role: 'assistant',
      text: `Device Status:\n\n• ${off.length} devices offline across all branches\n• ${degraded.length} devices degraded\n• Total devices monitored: ${devices.length}\n• Online rate: ${Math.round(((devices.length - off.length) / devices.length) * 100)}%\n\nOffline Devices:\n${off.map((d) => `• ${d.branch} — ${d.type} (${d.model})`).join('\n')}\n\nDegraded Devices:\n${degraded.map((d) => `• ${d.branch} — ${d.type} (${d.model})`).join('\n')}\n\nRecommendation: Dispatch field engineers for ATM and camera repairs. The Miami ATM #3 has a cash dispenser fault requiring cash replenishment.`,
      confidence: 93,
      sources: ['Device Health', 'Asset Inventory'],
      actions: [{ label: 'View Device Health', link: '/device-health' }],
    }
  }
  if (lower.includes('recommend') || lower.includes('action') || lower.includes('should')) {
    return {
      role: 'assistant',
      text: `AI Recommendations (${aiRecommendations.length} active):\n\n${aiRecommendations.map((r) => `• [${r.priority.toUpperCase()}] ${r.action}\n  Branch: ${branches.find((b) => b.id === r.branchId)?.branch}\n  Impact: ${r.impact}\n  Confidence: ${r.confidence}%`).join('\n\n')}\n\nThe most urgent action is failing over Kolkata's backup ISP circuit (94% confidence). This would restore IVR and telephony services within 5 minutes.`,
      confidence: 90,
      sources: ['AI Recommendations', 'Root Cause Analysis'],
      actions: [{ label: 'View Branch Health', link: '/branch-health' }],
    }
  }
  if (lower.includes('executive') || lower.includes('summary') || lower.includes('report')) {
    return {
      role: 'assistant',
      text: `Executive Summary — ${new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}\n\nBranch Network Overview:\n• ${executiveKPIs.totalBranches} branches across 9 countries\n• Overall health: ${executiveKPIs.overallHealth}% (${executiveKPIs.healthyBranches} healthy, ${executiveKPIs.warningBranches} warning, ${executiveKPIs.criticalBranches} critical)\n• Active incidents: ${executiveKPIs.activeIncidents} (${executiveKPIs.majorOutages} major outage)\n• Average SLA: ${executiveKPIs.avgSla}%\n• Customer satisfaction: ${executiveKPIs.customerSatisfaction}/5\n• IVR containment: ${executiveKPIs.ivrContainment}%\n• Employee availability: ${executiveKPIs.employeeAvailability}%\n\nKey Risks:\n1. Kolkata - Park Street: SIP trunk down, health at 79 (Critical)\n2. Miami - Brickell: ATM #3 offline, health at 82\n3. Houston - Galleria: WAN latency spike, health at 85\n\nPositive Trends:\n• Branch availability improved 3.2% this week\n• IVR containment up 3%, reducing call center load by ~1,200 calls/day\n• Northeast region fully recovered from previous network issues`,
      confidence: 97,
      sources: ['Executive Dashboard', 'Branch Health', 'Incident Management', 'IVR Analytics'],
      actions: [{ label: 'View Dashboard', link: '/' }, { label: 'View Reports', link: '/reports' }],
    }
  }
  return {
    role: 'assistant',
    text: `I can help you with:\n\n• Branch health analysis and root cause investigation\n• Incident summaries and timelines\n• Network and device status across all branches\n• IVR performance and call flow analysis\n• Regional comparisons and rankings\n• AI-generated recommendations and actions\n• Executive summaries and report generation\n\nTry asking: "Why is Kolkata health low?" or "Which branches need attention?" or "Generate an executive summary"`,
    confidence: 88,
  }
}

export default function Assistant() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      text: 'Hello! I am your Branch Operations AI Assistant. I can analyze branch health, investigate incidents, explain metrics, compare regions, and recommend actions. I provide confidence scores and cite my sources for every response.\n\nTry one of the suggested questions below, or ask me anything about your branch network.',
      confidence: 99,
      sources: ['Branch Intelligence Platform'],
    },
  ])
  const [input, setInput] = useState('')
  const messagesRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (messagesRef.current) {
      messagesRef.current.scrollTop = messagesRef.current.scrollHeight
    }
  }, [messages])

  const send = (text?: string) => {
    const query = text || input
    if (!query.trim()) return
    const response = generateResponse(query)
    setMessages((prev) => [...prev, { role: 'user', text: query }, response])
    setInput('')
  }

  return (
    <div>
      <div className="space-y-4" style={{ maxWidth: 860, margin: '0 auto' }}>
        <div className="flex items-center gap-2 mb-2">
          <div style={{ width: 36, height: 36, borderRadius: 10, background: 'linear-gradient(135deg, var(--brand-500), var(--brand-700))', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Bot style={{ width: 20, height: 20, color: 'white' }} />
          </div>
          <div>
            <h2 className="text-lg font-bold text-ink-900">AI Assistant</h2>
            <div className="text-xs text-ink-400">Conversational branch intelligence with confidence scoring</div>
          </div>
          <Badge tone="blue"><Sparkles style={{ width: 12, height: 12 }} /> Powered by Branch Intelligence</Badge>
        </div>

        <Card>
          <div ref={messagesRef} className="space-y-4" style={{ minHeight: 400, maxHeight: 500, overflowY: 'auto', padding: 4 }}>
            {messages.map((m, i) => (
              <div key={i} className="flex" style={{ justifyContent: m.role === 'user' ? 'flex-end' : 'flex-start' }}>
                <div className="rounded-lg p-3" style={{ maxWidth: '85%', background: m.role === 'user' ? 'var(--brand-600)' : 'var(--ink-50)', color: m.role === 'user' ? 'white' : 'var(--ink-800)', whiteSpace: 'pre-wrap' }}>
                  {m.text}
                  {m.confidence && m.role === 'assistant' && (
                    <div className="flex items-center gap-2 mt-3 pt-2" style={{ borderTop: '1px solid rgba(0,0,0,0.06)' }}>
                      <div className="flex items-center gap-1">
                        <Sparkles style={{ width: 10, height: 10, color: 'var(--brand-500)' }} />
                        <span className="text-xs font-semibold text-ink-500">Confidence: {m.confidence}%</span>
                      </div>
                      {m.sources && m.sources.length > 0 && (
                        <span className="text-xs text-ink-400">· Sources: {m.sources.join(', ')}</span>
                      )}
                    </div>
                  )}
                  {m.actions && m.actions.length > 0 && (
                    <div className="flex items-center gap-2 mt-2 flex-wrap">
                      {m.actions.map((a, j) => (
                        <a key={j} href={`#${a.link}`} className="text-xs font-semibold text-brand-600 rounded-full px-3 py-1 hover:bg-brand-50" style={{ border: '1px solid var(--brand-200)' }}>
                          {a.label}
                        </a>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
          <div className="flex items-center gap-2 mt-4 pt-3" style={{ borderTop: '1px solid var(--ink-100)' }}>
            <input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && send()} placeholder="Ask about branch health, incidents, devices, network, IVR…"
              className="flex-1 text-sm rounded-lg px-3 py-2" style={{ border: '1px solid var(--ink-200)', outline: 'none' }} />
            <button onClick={() => send()} className="flex items-center gap-1 text-sm font-medium text-white rounded-lg px-4 py-2" style={{ background: 'var(--brand-600)' }}><Send style={{ width: 14, height: 14 }} /> Send</button>
          </div>
        </Card>

        <div>
          <div className="text-xs font-semibold text-ink-500 mb-2">Suggested Questions</div>
          <div className="flex flex-wrap gap-2">
            {suggestedQuestions.map((s) => (
              <button key={s.text} onClick={() => send(s.text)} className="flex items-center gap-1.5 text-xs font-medium rounded-full px-3 py-1.5 hover:bg-brand-50 transition-colors" style={{ border: '1px solid var(--brand-200)', color: 'var(--brand-700)' }}>
                <s.icon style={{ width: 12, height: 12, color: s.color }} />
                {s.text}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
