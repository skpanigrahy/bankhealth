import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Card, Badge, HealthDot } from '../components/ui'
import { branches } from '../data/mockData'
import { Search, Building2, MapPin, ChevronRight } from 'lucide-react'

export default function BranchSearch() {
  const navigate = useNavigate()
  const [q, setQ] = useState('')
  const [country, setCountry] = useState('')
  const [status, setStatus] = useState('')
  const [region, setRegion] = useState('')
  const [healthMin, setHealthMin] = useState('')

  const countries = [...new Set(branches.map((b) => b.country))]
  const regions = [...new Set(branches.map((b) => b.region))].sort()
  const filtered = branches.filter((b) => {
    const matchQ = !q || b.branch.toLowerCase().includes(q.toLowerCase()) || b.city.toLowerCase().includes(q.toLowerCase()) || b.id.toLowerCase().includes(q.toLowerCase()) || b.manager.toLowerCase().includes(q.toLowerCase()) || b.costCenter.toLowerCase().includes(q.toLowerCase())
    const matchC = !country || b.country === country
    const matchS = !status || b.operatingStatus === status
    const matchR = !region || b.region === region
    const matchH = !healthMin || b.health <= parseInt(healthMin)
    return matchQ && matchC && matchS && matchR && matchH
  })

  return (
    <div>
      <div className="space-y-6">
        <Card>
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative" style={{ flex: 1, minWidth: 200 }}>
              <Search style={{ width: 16, height: 16, color: 'var(--ink-400)', position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)' }} />
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by name, city, ID, manager, or cost center…"
                className="text-sm rounded-lg" style={{ paddingLeft: 36, paddingRight: 12, paddingTop: 8, paddingBottom: 8, width: '100%', border: '1px solid var(--ink-200)', outline: 'none' }} />
            </div>
            <select value={country} onChange={(e) => setCountry(e.target.value)} className="text-sm rounded-lg" style={{ padding: '8px 12px', border: '1px solid var(--ink-200)', outline: 'none', background: 'white' }}>
              <option value="">All Countries</option>
              {countries.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
            <select value={region} onChange={(e) => setRegion(e.target.value)} className="text-sm rounded-lg" style={{ padding: '8px 12px', border: '1px solid var(--ink-200)', outline: 'none', background: 'white' }}>
              <option value="">All Regions</option>
              {regions.map((r) => <option key={r} value={r}>{r}</option>)}
            </select>
            <select value={status} onChange={(e) => setStatus(e.target.value)} className="text-sm rounded-lg" style={{ padding: '8px 12px', border: '1px solid var(--ink-200)', outline: 'none', background: 'white' }}>
              <option value="">All Statuses</option>
              <option value="Open">Open</option>
              <option value="Degraded">Degraded</option>
            </select>
            <select value={healthMin} onChange={(e) => setHealthMin(e.target.value)} className="text-sm rounded-lg" style={{ padding: '8px 12px', border: '1px solid var(--ink-200)', outline: 'none', background: 'white' }}>
              <option value="">Any Health</option>
              <option value="95">Excellent (95+)</option>
              <option value="89">Healthy (85-94)</option>
              <option value="84">Warning (70-84)</option>
              <option value="69">Critical (&lt;70)</option>
            </select>
          </div>
        </Card>

        <div className="text-sm text-ink-400">{filtered.length} branches found</div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3" style={{ gap: 16 }}>
          {filtered.map((b) => (
            <div key={b.id} onClick={() => navigate(`/branch/${b.id}`)} className="card cursor-pointer" style={{ transition: 'all 0.2s' }}>
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Building2 style={{ width: 16, height: 16, color: 'var(--brand-500)' }} />
                  <div className="font-bold text-ink-900">{b.branch}</div>
                </div>
                <HealthDot value={b.health} />
              </div>
              <div className="text-xs text-ink-400 mb-3 flex items-center gap-1"><MapPin style={{ width: 11, height: 11 }} /> {b.id} · {b.city}, {b.country}</div>
              <div className="flex items-center gap-2 mb-3 flex-wrap">
                <Badge tone={b.operatingStatus === 'Open' ? 'green' : 'red'}>{b.operatingStatus}</Badge>
                <Badge tone="neutral">{b.branchType}</Badge>
                <Badge tone={b.health >= 90 ? 'green' : b.health >= 80 ? 'amber' : 'red'}>Health: {b.health}</Badge>
              </div>
              <div className="grid grid-cols-2" style={{ gap: 8 }}>
                <div className="text-xs"><span className="text-ink-400">Manager:</span> <span className="text-ink-700 font-medium">{b.manager}</span></div>
                <div className="text-xs"><span className="text-ink-400">Employees:</span> <span className="text-ink-700 font-medium">{b.employees}</span></div>
                <div className="text-xs"><span className="text-ink-400">Devices:</span> <span className="text-ink-700 font-medium">{b.devices} ({b.devicesOffline} off)</span></div>
                <div className="text-xs"><span className="text-ink-400">Tickets:</span> <span className="text-ink-700 font-medium">{b.openTickets}</span></div>
              </div>
              <div className="flex items-center gap-1 text-xs font-semibold mt-3" style={{ color: 'var(--brand-600)' }}>
                View Details <ChevronRight style={{ width: 12, height: 12 }} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
