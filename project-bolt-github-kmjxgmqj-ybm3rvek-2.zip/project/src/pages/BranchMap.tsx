import { useState, useMemo, useCallback } from 'react'
import { Link } from 'react-router-dom'
import { Globe, ChevronRight, Building2, Users, Cpu, Ticket, PhoneCall, TrendingUp, TriangleAlert as AlertTriangle, ArrowLeft, MapPin, Search, X } from 'lucide-react'
import { Card, Badge, HealthDot, ProgressBar } from '../components/ui'
import { branches, BranchRow } from '../data/mockData'
import { worldGeoJSON } from '../data/worldMap'

type DrillLevel = 'world' | 'country' | 'state'

interface RegionSummary {
  name: string; branchCount: number; avgHealth: number; totalCustomers: number;
  totalTransactions: number; totalDevices: number; offlineDevices: number;
  openTickets: number; totalEmployees: number; avgSla: number; totalCalls: number;
  degraded: number; branches: BranchRow[]
}

function summarize(list: BranchRow[], keyFn: (b: BranchRow) => string): RegionSummary[] {
  const groups: Record<string, BranchRow[]> = {}
  list.forEach((b) => { const k = keyFn(b); if (!groups[k]) groups[k] = []; groups[k].push(b) })
  return Object.entries(groups).map(([name, items]) => ({
    name, branchCount: items.length,
    avgHealth: Math.round(items.reduce((s, b) => s + b.health, 0) / items.length),
    totalCustomers: items.reduce((s, b) => s + b.customers, 0),
    totalTransactions: items.reduce((s, b) => s + b.transactions, 0),
    totalDevices: items.reduce((s, b) => s + b.devices, 0),
    offlineDevices: items.reduce((s, b) => s + b.devicesOffline, 0),
    openTickets: items.reduce((s, b) => s + b.openTickets, 0),
    totalEmployees: items.reduce((s, b) => s + b.employees, 0),
    avgSla: Math.round(items.reduce((s, b) => s + b.sla, 0) / items.length),
    totalCalls: items.reduce((s, b) => s + b.calls, 0),
    degraded: items.filter((b) => b.health < 85).length,
    branches: items,
  })).sort((a, b) => b.branchCount - a.branchCount)
}

const healthColor = (h: number) => h >= 90 ? '#10b981' : h >= 80 ? '#f59e0b' : '#ef4444'

// Equirectangular projection: lng/lat -> x/y on an SVG viewBox of 0..1000 x 0..500
const W = 1000
const H = 500
function projectLngLat(lng: number, lat: number): [number, number] {
  const x = ((lng + 180) / 360) * W
  const y = ((90 - lat) / 180) * H
  return [x, y]
}

function polygonToPath(coords: [number, number][][]): string {
  // coords is array of rings; each ring is array of [lng, lat]
  return coords.map((ring) => {
    const pts = ring.map(([lng, lat]) => {
      const [x, y] = projectLngLat(lng, lat)
      return `${x.toFixed(1)},${y.toFixed(1)}`
    })
    return 'M' + pts.join(' L') + ' Z'
  }).join(' ')
}

export default function BranchMap() {
  const [level, setLevel] = useState<DrillLevel>('world')
  const [selectedCountry, setSelectedCountry] = useState<string | null>(null)
  const [selectedState, setSelectedState] = useState<string | null>(null)
  const [selectedBranch, setSelectedBranch] = useState<BranchRow | null>(null)
  const [search, setSearch] = useState('')

  const countries = useMemo(() => summarize(branches, (b) => b.country), [])
  const countryBranches = useMemo(() => selectedCountry ? branches.filter((b) => b.country === selectedCountry) : [], [selectedCountry])
  const states = useMemo(() => selectedCountry ? summarize(countryBranches, (b) => b.state) : [], [selectedCountry, countryBranches])
  const stateBranches = useMemo(() => selectedCountry && selectedState ? countryBranches.filter((b) => b.state === selectedState) : [], [selectedCountry, selectedState, countryBranches])

  const drillIntoCountry = useCallback((country: string) => {
    const cb = branches.filter((b) => b.country === country)
    if (!cb.length) return
    setSelectedCountry(country); setSelectedState(null); setLevel('country')
  }, [])

  const drillIntoState = useCallback((state: string) => {
    setSelectedState(state); setLevel('state')
  }, [])

  const resetToWorld = useCallback(() => { setLevel('world'); setSelectedCountry(null); setSelectedState(null); setSelectedBranch(null) }, [])
  const resetToCountry = useCallback(() => {
    if (!selectedCountry) return
    setSelectedState(null); setLevel('country')
  }, [selectedCountry])

  const visibleBranches = level === 'world' ? branches : level === 'country' ? countryBranches : stateBranches
  const filteredSearch = useMemo(() => {
    if (!search) return null
    const q = search.toLowerCase()
    return branches.filter((b) => b.branch.toLowerCase().includes(q) || b.city.toLowerCase().includes(q) || b.country.toLowerCase().includes(q) || b.id.toLowerCase().includes(q))
  }, [search])

  const breadcrumbs = useMemo(() => {
    const crumbs: { label: string; action: () => void }[] = [{ label: 'World', action: resetToWorld }]
    if (selectedCountry) crumbs.push({ label: selectedCountry, action: resetToCountry })
    if (selectedState) crumbs.push({ label: selectedState, action: () => drillIntoState(selectedState) })
    return crumbs
  }, [selectedCountry, selectedState, resetToWorld, resetToCountry, drillIntoState])

  const currentSummary = useMemo(() => {
    if (level === 'world') return summarize(branches, () => 'World')[0] || null
    if (level === 'country' && selectedCountry) return summarize(countryBranches, () => selectedCountry)[0] || null
    if (level === 'state' && selectedState) return summarize(stateBranches, () => selectedState)[0] || null
    return null
  }, [level, selectedCountry, selectedState, countryBranches, stateBranches])

  const countryNames = useMemo(() => new Set(branches.map((b) => b.country)), [])

  // Pre-compute country paths
  const countryPaths = useMemo(() => {
    return worldGeoJSON.features.map((f) => {
      const geo = f.geometry as any
      const name = (f.properties as any).name as string
      let pathStr: string
      if (geo.type === 'Polygon') {
        pathStr = polygonToPath(geo.coordinates as [number, number][][])
      } else if (geo.type === 'MultiPolygon') {
        pathStr = (geo.coordinates as [number, number][][][]).map(polygon => polygonToPath(polygon)).join(' ')
      } else {
        pathStr = ''
      }
      return { name, pathStr, hasBranches: countryNames.has(name) }
    })
  }, [countryNames])

  // Compute SVG viewBox for zoom to selected region
  const viewBox = useMemo(() => {
    if (level === 'world' || !selectedCountry) return `0 0 ${W} ${H}`
    const cb = level === 'country' ? countryBranches : stateBranches
    if (!cb.length) return `0 0 ${W} ${H}`
    const lngs = cb.map((b) => b.lng)
    const lats = cb.map((b) => b.lat)
    const minLng = Math.min(...lngs) - 5
    const maxLng = Math.max(...lngs) + 5
    const minLat = Math.min(...lats) - 5
    const maxLat = Math.max(...lats) + 5
    const [x1, y1] = projectLngLat(minLng, maxLat)
    const [x2, y2] = projectLngLat(maxLng, minLat)
    const pad = 20
    return `${x1 - pad} ${y1 - pad} ${(x2 - x1) + pad * 2} ${(y2 - y1) + pad * 2}`
  }, [level, selectedCountry, countryBranches, stateBranches])

  return (
    <div>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between flex-wrap" style={{ gap: 16 }}>
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Globe style={{ width: 20, height: 20, color: 'var(--brand-600)' }} />
              <h2 className="text-lg font-bold text-ink-900">Geospatial Branch Map</h2>
            </div>
            <div className="flex items-center gap-1.5 text-sm">
              {breadcrumbs.map((c, i) => (
                <div key={i} className="flex items-center gap-1.5">
                  {i > 0 && <ChevronRight style={{ width: 14, height: 14, color: 'var(--ink-300)' }} />}
                  <button onClick={c.action} className={`hover:underline ${i === breadcrumbs.length - 1 ? 'font-semibold text-brand-700' : 'text-ink-500'}`}>{c.label}</button>
                </div>
              ))}
            </div>
          </div>
          <div className="relative">
            <Search style={{ width: 16, height: 16, color: 'var(--ink-400)', position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)' }} />
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search branches…"
              className="text-sm rounded-lg" style={{ paddingLeft: 36, paddingRight: 12, paddingTop: 8, paddingBottom: 8, width: 224, border: '1px solid var(--ink-200)', background: 'white', outline: 'none' }} />
          </div>
        </div>

        {/* Search results */}
        {filteredSearch && filteredSearch.length > 0 && (
          <Card>
            <div className="text-xs text-ink-400 mb-2">{filteredSearch.length} branches found</div>
            <div className="grid grid-cols-2 md:grid-cols-3" style={{ gap: 8 }}>
              {filteredSearch.slice(0, 9).map((b) => (
                <button key={b.id} onClick={() => { drillIntoCountry(b.country); setTimeout(() => setSelectedBranch(b), 100); setSearch('') }}
                  className="flex items-center gap-2 p-2 rounded-lg hover:bg-ink-50 text-left transition-colors">
                  <HealthDot value={b.health} />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-ink-800 truncate">{b.branch}</div>
                    <div className="text-xs text-ink-400">{b.city}, {b.country}</div>
                  </div>
                </button>
              ))}
            </div>
          </Card>
        )}

        {/* Summary cards */}
        {currentSummary && (
          <div className="grid grid-cols-2 md:grid-cols-6" style={{ gap: 12 }}>
            {[
              { icon: Building2, label: 'Branches', value: String(currentSummary.branchCount), color: 'var(--brand-500)' },
              { icon: TrendingUp, label: 'Avg Health', value: `${currentSummary.avgHealth}%`, color: 'var(--emerald-500)' },
              { icon: Users, label: 'Employees', value: String(currentSummary.totalEmployees), color: 'var(--purple-500)' },
              { icon: Cpu, label: 'Offline Devices', value: String(currentSummary.offlineDevices), color: 'var(--amber-500)' },
              { icon: Ticket, label: 'Open Tickets', value: String(currentSummary.openTickets), color: 'var(--red-500)' },
              { icon: PhoneCall, label: 'Daily Calls', value: `${(currentSummary.totalCalls / 1000).toFixed(1)}K`, color: 'var(--cyan-500)' },
            ].map((k, i) => (
              <div key={i} className="card" style={{ padding: 16 }}>
                <k.icon style={{ width: 16, height: 16, color: k.color, marginBottom: 8 }} />
                <div className="text-xl font-bold text-ink-900">{k.value}</div>
                <div className="text-xs text-ink-400">{k.label}</div>
              </div>
            ))}
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3" style={{ gap: 16 }}>
          {/* Map */}
          <Card className="lg:col-span-2 overflow-hidden">
            <div className="relative rounded-lg overflow-hidden" style={{ height: 520, background: 'linear-gradient(to bottom, #eff6ff, #dbeafe)' }}>
              <svg viewBox={viewBox} style={{ width: '100%', height: '100%', display: 'block' }} preserveAspectRatio="xMidYMid meet">
                {/* Ocean background */}
                <rect x={0} y={0} width={W} height={H} fill="transparent" />

                {/* Country shapes */}
                {countryPaths.map((c, i) => {
                  const isDimmed = selectedCountry && c.name !== selectedCountry
                  const fill = isDimmed ? '#e2e8f0' : c.hasBranches ? '#bfdbfe' : '#e2e8f0'
                  return (
                    <path
                      key={i}
                      d={c.pathStr}
                      fill={fill}
                      stroke="#94a3b8"
                      strokeWidth={0.5}
                      style={{ cursor: c.hasBranches ? 'pointer' : 'default', transition: 'fill 0.2s' }}
                      onMouseEnter={(e) => { if (c.hasBranches) e.currentTarget.setAttribute('fill', '#93c5fd') }}
                      onMouseLeave={(e) => { e.currentTarget.setAttribute('fill', isDimmed ? '#e2e8f0' : c.hasBranches ? '#bfdbfe' : '#e2e8f0') }}
                      onClick={() => { if (c.hasBranches) drillIntoCountry(c.name) }}
                    />
                  )
                })}

                {/* Branch markers */}
                {visibleBranches.map((b) => {
                  const [cx, cy] = projectLngLat(b.lng, b.lat)
                  const r = level === 'world' ? 5 : level === 'country' ? 7 : 9
                  return (
                    <g key={b.id} style={{ cursor: 'pointer' }} onClick={() => { setSelectedBranch(b); if (level === 'world') drillIntoCountry(b.country); else if (level === 'country') drillIntoState(b.state) }}>
                      {b.health < 85 && (
                        <circle cx={cx} cy={cy} r={r * 2} fill="none" stroke={healthColor(b.health)} strokeWidth={1.5} opacity={0.4} className="animate-ping" style={{ pointerEvents: 'none' }} />
                      )}
                      <circle cx={cx} cy={cy} r={r} fill={healthColor(b.health)} stroke="#fff" strokeWidth={1.5} opacity={0.9} />
                    </g>
                  )
                })}
              </svg>

              {/* Legend */}
              <div className="absolute" style={{ bottom: 12, left: 12, background: 'rgba(255,255,255,0.9)', backdropFilter: 'blur(4px)', borderRadius: 8, padding: 12, boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)' }}>
                <div className="text-xs font-semibold text-ink-700 mb-2">Health Status</div>
                <div className="flex items-center" style={{ gap: 12 }}>
                  {[{ c: '#10b981', l: 'Healthy (90+)' }, { c: '#f59e0b', l: 'At Risk (80-89)' }, { c: '#ef4444', l: 'Critical (<80)' }].map((x, i) => (
                    <div key={i} className="flex items-center gap-1.5">
                      <span className="rounded-full" style={{ width: 12, height: 12, background: x.c }} />
                      <span className="text-xs text-ink-600">{x.l}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="absolute" style={{ top: 12, right: 12, background: 'rgba(255,255,255,0.9)', backdropFilter: 'blur(4px)', borderRadius: 8, padding: '6px 12px', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)', fontSize: 11, color: 'var(--ink-500)' }}>
                Click countries or markers to drill down
              </div>
            </div>
          </Card>

          {/* Side panel */}
          <div className="space-y-4">
            {selectedBranch ? (
              <Card>
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="font-bold text-ink-900">{selectedBranch.branch}</div>
                    <div className="text-xs text-ink-400 mt-2">{selectedBranch.id} · {selectedBranch.costCenter}</div>
                  </div>
                  <button onClick={() => setSelectedBranch(null)} className="text-ink-400 hover:text-ink-600"><X style={{ width: 16, height: 16 }} /></button>
                </div>
                <div className="flex items-center" style={{ gap: 12, marginBottom: 16 }}>
                  <HealthDot value={selectedBranch.health} />
                  <span className="text-2xl font-bold" style={{ color: selectedBranch.health >= 90 ? 'var(--emerald-600)' : selectedBranch.health >= 80 ? 'var(--amber-600)' : 'var(--red-600)' }}>{selectedBranch.health}</span>
                  <Badge tone={selectedBranch.operatingStatus === 'Open' ? 'green' : 'red'}>{selectedBranch.operatingStatus}</Badge>
                  <Badge tone="neutral">{selectedBranch.branchType}</Badge>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2 text-ink-500"><MapPin style={{ width: 14, height: 14, color: 'var(--ink-400)' }} />{selectedBranch.city}, {selectedBranch.state}, {selectedBranch.country}</div>
                  <div className="flex items-center gap-2 text-ink-500"><Users style={{ width: 14, height: 14, color: 'var(--ink-400)' }} />{selectedBranch.manager} · {selectedBranch.employees} staff</div>
                </div>
                <div className="grid grid-cols-2" style={{ gap: 8, marginTop: 16 }}>
                  {[
                    { l: 'Customers', v: selectedBranch.customers.toLocaleString() },
                    { l: 'Transactions', v: selectedBranch.transactions.toLocaleString() },
                    { l: 'SLA', v: `${selectedBranch.sla}%` },
                    { l: 'IVR', v: `${selectedBranch.ivrContainment}%` },
                    { l: 'Devices', v: `${selectedBranch.devices} (${selectedBranch.devicesOffline} off)` },
                    { l: 'Tickets', v: String(selectedBranch.openTickets) },
                  ].map((x, i) => (
                    <div key={i} className="rounded-lg bg-ink-50 p-3"><div className="text-lg font-bold text-ink-900">{x.v}</div><div className="text-xs text-ink-400">{x.l}</div></div>
                  ))}
                </div>
                <div className="mt-3 space-y-2">
                  <div className="text-xs text-ink-400">Utilisation</div>
                  <ProgressBar value={selectedBranch.utilisation} />
                  <div className="text-xs text-ink-400 mt-2">SLA Compliance</div>
                  <ProgressBar value={selectedBranch.sla} tone="green" />
                </div>
                <Link to={`/branch/${selectedBranch.id}`} className="flex items-center justify-center gap-1.5 mt-4 text-sm font-semibold text-white rounded-lg py-2.5" style={{ background: 'var(--brand-600)' }}>
                  View Full Details <ChevronRight style={{ width: 14, height: 14 }} />
                </Link>
              </Card>
            ) : level === 'world' ? (
              <Card title="Countries" subtitle={`${countries.length} countries · ${branches.length} branches`}>
                <div className="space-y-2 overflow-y-auto" style={{ maxHeight: 460 }}>
                  {countries.map((c) => (
                    <button key={c.name} onClick={() => drillIntoCountry(c.name)} className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-ink-50 text-left transition-colors">
                      <div className="rounded-lg flex items-center justify-center font-bold text-sm" style={{ width: 40, height: 40, background: 'var(--brand-50)', color: 'var(--brand-700)' }}>{c.branchCount}</div>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-semibold text-ink-800 truncate">{c.name}</div>
                        <div className="text-xs text-ink-400">{c.branchCount} branches · {c.totalEmployees} staff · {c.openTickets} tickets</div>
                      </div>
                      <div className="flex items-center gap-2">
                        <HealthDot value={c.avgHealth} />
                        <span className="text-sm font-bold" style={{ color: c.avgHealth >= 90 ? 'var(--emerald-600)' : c.avgHealth >= 80 ? 'var(--amber-600)' : 'var(--red-600)' }}>{c.avgHealth}</span>
                        <ChevronRight style={{ width: 16, height: 16, color: 'var(--ink-300)' }} />
                      </div>
                    </button>
                  ))}
                </div>
              </Card>
            ) : level === 'country' ? (
              <Card title={`${selectedCountry} — Regions`} subtitle={`${states.length} states · ${countryBranches.length} branches`}>
                <button onClick={resetToWorld} className="flex items-center gap-1.5 text-xs text-brand-600 hover:underline mb-3"><ArrowLeft style={{ width: 14, height: 14 }} /> Back to world</button>
                <div className="space-y-2 overflow-y-auto" style={{ maxHeight: 420 }}>
                  {states.map((s) => (
                    <button key={s.name} onClick={() => drillIntoState(s.name)} className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-ink-50 text-left transition-colors">
                      <div className="rounded-lg flex items-center justify-center font-bold text-sm" style={{ width: 40, height: 40, background: 'var(--brand-50)', color: 'var(--brand-700)' }}>{s.branchCount}</div>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-semibold text-ink-800 truncate">{s.name}</div>
                        <div className="text-xs text-ink-400">{s.branchCount} branches · {s.totalCustomers.toLocaleString()} customers</div>
                      </div>
                      <div className="flex items-center gap-2">
                        <HealthDot value={s.avgHealth} />
                        <span className="text-sm font-bold" style={{ color: s.avgHealth >= 90 ? 'var(--emerald-600)' : s.avgHealth >= 80 ? 'var(--amber-600)' : 'var(--red-600)' }}>{s.avgHealth}</span>
                        <ChevronRight style={{ width: 16, height: 16, color: 'var(--ink-300)' }} />
                      </div>
                    </button>
                  ))}
                </div>
              </Card>
            ) : (
              <Card title={`${selectedState} — Branches`} subtitle={`${stateBranches.length} branches`}>
                <button onClick={resetToCountry} className="flex items-center gap-1.5 text-xs text-brand-600 hover:underline mb-3"><ArrowLeft style={{ width: 14, height: 14 }} /> Back to {selectedCountry}</button>
                <div className="space-y-2 overflow-y-auto" style={{ maxHeight: 420 }}>
                  {stateBranches.map((b) => (
                    <button key={b.id} onClick={() => setSelectedBranch(b)} className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-ink-50 text-left transition-colors">
                      <HealthDot value={b.health} />
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-semibold text-ink-800 truncate">{b.branch}</div>
                        <div className="text-xs text-ink-400">{b.city} · {b.openTickets} tickets · {b.devicesOffline} offline</div>
                      </div>
                      <span className="text-sm font-bold" style={{ color: b.health >= 90 ? 'var(--emerald-600)' : b.health >= 80 ? 'var(--amber-600)' : 'var(--red-600)' }}>{b.health}</span>
                      <ChevronRight style={{ width: 16, height: 16, color: 'var(--ink-300)' }} />
                    </button>
                  ))}
                </div>
              </Card>
            )}
          </div>
        </div>

        {/* Country heat strip */}
        {level === 'world' && (
          <Card title="Country Health Overview" subtitle="Click any country to drill down">
            <div className="space-y-2">
              {countries.map((c) => (
                <button key={c.name} onClick={() => drillIntoCountry(c.name)} className="w-full flex items-center gap-4 p-2 rounded-lg hover:bg-ink-50 transition-colors">
                  <span className="text-sm font-medium text-ink-700 text-left truncate" style={{ width: 160 }}>{c.name}</span>
                  <div className="flex-1 rounded-full bg-ink-100 overflow-hidden" style={{ height: 12 }}>
                    <div className="rounded-full" style={{ width: `${c.avgHealth}%`, height: '100%', background: c.avgHealth >= 90 ? 'var(--emerald-500)' : c.avgHealth >= 80 ? 'var(--amber-500)' : 'var(--red-500)' }} />
                  </div>
                  <span className="text-sm font-bold text-right" style={{ width: 40, color: c.avgHealth >= 90 ? 'var(--emerald-600)' : c.avgHealth >= 80 ? 'var(--amber-600)' : 'var(--red-600)' }}>{c.avgHealth}%</span>
                  <span className="text-xs text-ink-400 text-right" style={{ width: 80 }}>{c.branchCount} branches</span>
                  {c.degraded > 0 && <span className="flex items-center gap-1 text-xs" style={{ color: 'var(--red-500)' }}><AlertTriangle style={{ width: 12, height: 12 }} /> {c.degraded} at risk</span>}
                </button>
              ))}
            </div>
          </Card>
        )}
      </div>
    </div>
  )
}
