import { useState } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import { Card, KPI, Badge, HealthDot, ProgressBar, TrendArrow } from '../components/ui'
import {
  ArrowLeft, Building2, MapPin, Phone, Clock, Users, Cpu, Network, AppWindow,
  HeartPulse, Ticket, Package, CalendarClock, PhoneCall, Bot, Sparkles,
  CircleAlert as AlertCircle, Activity, ShieldCheck, Gauge, Banknote, Wifi,
} from 'lucide-react'
import {
  branches, branchDomainScores, rootCauseChains, aiRecommendations,
  incidents, devices, applications, networkCircuits, events, employees, inventory,
  healthDomains,
} from '../data/mockData'

type Tab = 'overview' | 'directory' | 'inventory' | 'incidents' | 'events' | 'network' | 'devices' | 'applications' | 'ivr' | 'ai'

const tabs: { key: Tab; label: string; icon: any }[] = [
  { key: 'overview', label: 'Overview', icon: Building2 },
  { key: 'directory', label: 'Directory', icon: Users },
  { key: 'inventory', label: 'Inventory', icon: Package },
  { key: 'incidents', label: 'Incidents', icon: Ticket },
  { key: 'events', label: 'Events', icon: CalendarClock },
  { key: 'network', label: 'Network', icon: Network },
  { key: 'devices', label: 'Devices', icon: Cpu },
  { key: 'applications', label: 'Applications', icon: AppWindow },
  { key: 'ivr', label: 'IVR', icon: PhoneCall },
  { key: 'ai', label: 'AI Insights', icon: Bot },
]

export default function BranchDetail() {
  const { branchId } = useParams()
  const navigate = useNavigate()
  const [tab, setTab] = useState<Tab>('overview')

  const branch = branches.find((b) => b.id === branchId)
  if (!branch) {
    return (
      <div>
        <Link to="/branch-search" className="back-link"><ArrowLeft style={{ width: 14, height: 14 }} /> Back to Search</Link>
        <Card><div className="text-center py-8 text-ink-400">Branch not found.</div></Card>
      </div>
    )
  }

  const scores = branchDomainScores(branch.id)
  const branchIncidents = incidents.filter((i) => i.branchId === branch.id)
  const branchDevices = devices.filter((d) => d.branchId === branch.id)
  const branchApps = applications.filter((a) => a.branchId === branch.id)
  const branchCircuits = networkCircuits.filter((c) => c.branchId === branch.id)
  const branchEvents = events.filter((e) => e.branchId === branch.id)
  const branchEmployees = employees.filter((e) => e.branchId === branch.id)
  const branchInventory = inventory.filter((i) => i.branchId === branch.id)
  const branchRCA = rootCauseChains.find((c) => c.branchId === branch.id)
  const branchRecs = aiRecommendations.filter((r) => r.branchId === branch.id)

  return (
    <div>
      <Link to="/branch-search" className="back-link"><ArrowLeft style={{ width: 14, height: 14 }} /> Back to Branches</Link>

      {/* Branch header */}
      <Card>
        <div className="flex items-start justify-between flex-wrap" style={{ gap: 16 }}>
          <div className="flex items-start gap-4">
            <div style={{ width: 56, height: 56, borderRadius: 12, background: 'linear-gradient(135deg, var(--brand-500), var(--brand-700))', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <Building2 style={{ width: 28, height: 28, color: 'white' }} />
            </div>
            <div>
              <h2 className="text-lg font-bold text-ink-900">{branch.branch}</h2>
              <div className="flex items-center gap-3 mt-1 flex-wrap">
                <span className="text-xs text-ink-400 flex items-center gap-1"><MapPin style={{ width: 12, height: 12 }} /> {branch.city}, {branch.state}, {branch.country}</span>
                <span className="text-xs text-ink-400">·</span>
                <span className="text-xs text-ink-400">{branch.id} · CC: {branch.costCenter}</span>
              </div>
              <div className="flex items-center gap-2 mt-2 flex-wrap">
                <Badge tone={branch.operatingStatus === 'Open' ? 'green' : 'red'}>{branch.operatingStatus}</Badge>
                <Badge tone="neutral">{branch.branchType}</Badge>
                <Badge tone={branch.health >= 90 ? 'green' : branch.health >= 80 ? 'amber' : 'red'}>Health: {branch.health}</Badge>
                <Badge tone="blue">SLA: {branch.sla}%</Badge>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold" style={{ color: branch.health >= 90 ? 'var(--emerald-600)' : branch.health >= 80 ? 'var(--amber-600)' : 'var(--red-600)' }}>{branch.health}</div>
              <div className="text-xs text-ink-400">Health Score</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-ink-900">{branch.openTickets}</div>
              <div className="text-xs text-ink-400">Open Tickets</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-ink-900">{branch.devicesOffline}</div>
              <div className="text-xs text-ink-400">Devices Offline</div>
            </div>
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 mt-4 pt-4" style={{ gap: 12, borderTop: '1px solid var(--ink-100)' }}>
          <div className="text-xs"><span className="text-ink-400">Manager:</span> <span className="text-ink-700 font-medium">{branch.manager}</span></div>
          <div className="text-xs"><span className="text-ink-400">Region:</span> <span className="text-ink-700 font-medium">{branch.region}</span></div>
          <div className="text-xs"><span className="text-ink-400">Market:</span> <span className="text-ink-700 font-medium">{branch.market}</span></div>
          <div className="text-xs"><span className="text-ink-400">Building:</span> <span className="text-ink-700 font-medium">{branch.buildingStatus}</span></div>
        </div>
      </Card>

      {/* Tabs */}
      <div className="detail-tabs">
        {tabs.map((t) => {
          const count = t.key === 'incidents' ? branchIncidents.length : t.key === 'events' ? branchEvents.length : t.key === 'devices' ? branchDevices.filter((d) => d.status !== 'Online').length : 0
          return (
            <button
              key={t.key}
              className={`detail-tab ${tab === t.key ? 'detail-tab-active' : ''}`}
              onClick={() => setTab(t.key)}
            >
              <t.icon style={{ width: 14, height: 14 }} />
              {t.label}
              {count > 0 && <span className="detail-tab-badge">{count}</span>}
            </button>
          )
        })}
      </div>

      {/* Tab content */}
      {tab === 'overview' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4" style={{ gap: 12 }}>
            <KPI icon={<Users style={{ width: 18, height: 18 }} />} label="Employees" value={String(branch.employees)} tone="blue" hint={`${branch.utilisation}% utilisation`} />
            <KPI icon={<Banknote style={{ width: 18, height: 18 }} />} label="Customers Today" value={branch.customers.toLocaleString()} tone="green" />
            <KPI icon={<Activity style={{ width: 18, height: 18 }} />} label="Transactions" value={branch.transactions.toLocaleString()} tone="blue" />
            <KPI icon={<PhoneCall style={{ width: 18, height: 18 }} />} label="Calls Today" value={branch.calls.toLocaleString()} tone="amber" hint={`${branch.ivrTransfers} IVR transfers`} />
          </div>

          <Card title="Health Score Breakdown" subtitle="Domain scores contributing to the composite health">
            <div className="space-y-2">
              {scores.map((s) => (
                <div key={s.name} className="flex items-center gap-3">
                  <span className="text-sm text-ink-700" style={{ width: 160 }}>{s.name}</span>
                  <div style={{ flex: 1 }}><ProgressBar value={s.score} max={100} color={s.score >= 90 ? '#10b981' : s.score >= 75 ? '#f59e0b' : '#ef4444'} /></div>
                  <span className="text-sm font-bold" style={{ width: 30, color: s.score >= 90 ? 'var(--emerald-600)' : s.score >= 75 ? 'var(--amber-600)' : 'var(--red-600)' }}>{s.score}</span>
                  <TrendArrow value={s.trend} />
                  <span className="text-xs text-ink-400" style={{ width: 40 }}>{s.weight}% wt</span>
                </div>
              ))}
            </div>
          </Card>

          {branchRCA && (
            <Card title="Root Cause Analysis" subtitle={`Confidence: ${branchRCA.confidence}%`}>
              <div className="flex items-center flex-wrap" style={{ gap: 4 }}>
                {branchRCA.chain.map((step, i) => (
                  <div key={i} className="flex items-center" style={{ gap: 4 }}>
                    <div className="px-3 py-2 rounded-lg" style={{ background: 'var(--ink-50)', border: '1px solid var(--ink-100)' }}>
                      <div className="text-xs font-semibold text-ink-800">{step.event}</div>
                      <div className="text-xs text-ink-400">{step.domain} · {step.time}</div>
                    </div>
                    {i < branchRCA.chain.length - 1 && <span style={{ color: 'var(--ink-400)' }}>↓</span>}
                  </div>
                ))}
              </div>
            </Card>
          )}

          {branchRecs.length > 0 && (
            <Card title="AI Recommendations" subtitle="Contextual actions for this branch">
              <div className="space-y-2">
                {branchRecs.map((r, i) => (
                  <div key={i} className="flex items-start gap-3 p-3 rounded-lg" style={{ background: 'var(--ink-50)' }}>
                    <Sparkles style={{ width: 16, height: 16, color: r.priority === 'critical' ? 'var(--red-500)' : r.priority === 'high' ? 'var(--amber-500)' : 'var(--blue-500)', marginTop: 1, flexShrink: 0 }} />
                    <div className="flex-1">
                      <div className="text-sm font-semibold text-ink-900">{r.action}</div>
                      <div className="text-xs text-ink-500 mt-1">{r.impact}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs text-ink-400">Confidence</div>
                      <div className="text-sm font-bold" style={{ color: r.priority === 'critical' ? 'var(--red-600)' : 'var(--amber-600)' }}>{r.confidence}%</div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </div>
      )}

      {tab === 'directory' && (
        <Card title="Branch Directory" subtitle={`${branchEmployees.length} employees at this branch`}>
          <div className="space-y-1">
            {branchEmployees.map((e) => (
              <div key={e.id} className="flex items-center gap-3 px-2 py-2 rounded-lg hover:bg-ink-50 transition-colors">
                <span style={{ width: 32, height: 32, borderRadius: '50%', background: 'var(--brand-100)', color: 'var(--brand-700)', fontSize: 11, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{e.name.split(' ').map((n) => n[0]).join('')}</span>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-ink-800">{e.name}</div>
                  <div className="text-xs text-ink-400">{e.role} · {e.department}</div>
                </div>
                <Badge tone={e.status === 'Active' ? 'green' : e.status === 'On Leave' ? 'amber' : 'blue'}>{e.status}</Badge>
                <span className="text-xs text-ink-500" style={{ width: 50 }}>{e.utilization}%</span>
              </div>
            ))}
          </div>
        </Card>
      )}

      {tab === 'inventory' && (
        <Card title="Asset Inventory" subtitle={`${branchInventory.length} assets at this branch`}>
          <div className="space-y-1">
            {branchInventory.map((item) => (
              <div key={item.id} className="flex items-center gap-3 px-2 py-2 rounded-lg hover:bg-ink-50 transition-colors">
                <Package style={{ width: 14, height: 14, color: 'var(--ink-400)' }} />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-ink-800">{item.name}</div>
                  <div className="text-xs text-ink-400">{item.vendor} · {item.serialNumber}</div>
                </div>
                <span className="text-xs font-semibold" style={{ color: item.lifecycle === 'Active' ? 'var(--emerald-600)' : item.lifecycle === 'End of Life' ? 'var(--red-600)' : 'var(--amber-600)' }}>{item.lifecycle}</span>
                <span className="text-sm font-semibold text-ink-700">${item.cost.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </Card>
      )}

      {tab === 'incidents' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4" style={{ gap: 12 }}>
            <KPI icon={<Ticket style={{ width: 18, height: 18 }} />} label="Open Incidents" value={String(branchIncidents.filter((i) => i.status !== 'Resolved').length)} tone="red" />
            <KPI icon={<AlertCircle style={{ width: 18, height: 18 }} />} label="Critical" value={String(branchIncidents.filter((i) => i.severity === 'Critical').length)} tone="red" />
            <KPI icon={<ShieldCheck style={{ width: 18, height: 18 }} />} label="SLA Breaches" value={String(branchIncidents.filter((i) => i.slaBreached).length)} tone="amber" />
            <KPI icon={<Gauge style={{ width: 18, height: 18 }} />} label="Avg MTTD" value={`${Math.round(branchIncidents.reduce((s, i) => s + i.mttd, 0) / branchIncidents.length)}m`} tone="blue" />
          </div>
          <Card title="Incidents" subtitle="All incidents for this branch">
            <div className="space-y-2">
              {branchIncidents.length === 0 ? <div className="text-sm text-ink-400 text-center py-4">No incidents recorded for this branch.</div> : branchIncidents.map((inc) => (
                <div key={inc.id} className="flex items-start gap-3 p-3 rounded-lg" style={{ background: 'var(--ink-50)' }}>
                  <span style={{ width: 8, height: 8, borderRadius: '50%', background: inc.severity === 'Critical' ? 'var(--red-500)' : inc.severity === 'High' ? 'var(--amber-500)' : 'var(--blue-500)', marginTop: 6, flexShrink: 0 }} />
                  <div className="flex-1">
                    <div className="text-sm font-semibold text-ink-800">{inc.title}</div>
                    <div className="text-xs text-ink-400 mt-1">{inc.id} · {inc.category} · Created: {inc.createdAt} · Assigned: {inc.assignedTo}</div>
                    <div className="text-xs text-ink-500 mt-1">{inc.impact}</div>
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    <Badge tone={inc.status === 'Resolved' ? 'green' : inc.status === 'Escalated' ? 'red' : 'amber'}>{inc.status}</Badge>
                    {inc.slaBreached && <Badge tone="red">SLA Breached</Badge>}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}

      {tab === 'events' && (
        <Card title="Branch Events" subtitle="Chronological timeline of incidents, alerts, and activities">
          <div className="space-y-3">
            {branchEvents.length === 0 ? <div className="text-sm text-ink-400 text-center py-4">No events recorded for this branch.</div> : branchEvents.map((e, i) => (
              <div key={e.id} className="flex items-start gap-3">
                <div className="flex flex-col items-center" style={{ flexShrink: 0 }}>
                  <span style={{ width: 8, height: 8, borderRadius: '50%', background: e.severity === 'Critical' ? 'var(--red-500)' : e.severity === 'High' ? 'var(--amber-500)' : 'var(--blue-500)' }} />
                  {i < branchEvents.length - 1 && <span style={{ width: 2, flex: 1, background: 'var(--ink-100)', minHeight: 20 }} />}
                </div>
                <div className="pb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-ink-800">{e.title}</span>
                    <Badge tone={e.severity === 'Critical' ? 'red' : e.severity === 'High' ? 'amber' : 'neutral'}>{e.severity}</Badge>
                  </div>
                  <div className="text-sm text-ink-600 mt-1">{e.description}</div>
                  <div className="text-xs text-ink-400 mt-1">{e.type} · {e.timestamp}</div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {tab === 'network' && (
        <Card title="Network Circuits" subtitle="WAN, LAN, WiFi, and SIP trunk status">
          <div className="space-y-2">
            {branchCircuits.map((c) => (
              <div key={c.type} className="flex items-center gap-3 p-3 rounded-lg" style={{ background: 'var(--ink-50)' }}>
                <div className="flex items-center gap-2" style={{ width: 100 }}>
                  {c.type === 'WAN' ? <Network style={{ width: 16, height: 16, color: '#3b82f6' }} /> : c.type === 'WiFi' ? <Wifi style={{ width: 16, height: 16, color: '#8b5cf6' }} /> : c.type === 'LAN' ? <Network style={{ width: 16, height: 16, color: '#10b981' }} /> : <PhoneCall style={{ width: 16, height: 16, color: '#f59e0b' }} />}
                  <span className="text-sm font-semibold text-ink-800">{c.type}</span>
                </div>
                <span className="text-xs text-ink-500" style={{ width: 100 }}>{c.provider}</span>
                <span className="text-xs text-ink-500" style={{ width: 80 }}>{c.bandwidth}</span>
                <div style={{ flex: 1, maxWidth: 120 }}><ProgressBar value={c.utilization} max={100} color={c.utilization > 85 ? '#ef4444' : c.utilization > 70 ? '#f59e0b' : '#10b981'} /></div>
                <span className="text-xs text-ink-500" style={{ width: 40 }}>{c.utilization}%</span>
                <span className="text-xs text-ink-500" style={{ width: 50 }}>{c.latency}ms</span>
                <Badge tone={c.status === 'Healthy' ? 'green' : c.status === 'Warning' ? 'amber' : 'red'}>{c.status}</Badge>
              </div>
            ))}
          </div>
        </Card>
      )}

      {tab === 'devices' && (
        <Card title="Device Inventory" subtitle={`${branchDevices.length} devices at this branch`}>
          <div className="space-y-2">
            {branchDevices.map((d) => (
              <div key={d.type} className="flex items-center gap-3 p-3 rounded-lg" style={{ background: 'var(--ink-50)' }}>
                <Cpu style={{ width: 16, height: 16, color: d.status === 'Online' ? 'var(--emerald-500)' : d.status === 'Degraded' ? 'var(--amber-500)' : 'var(--red-500)' }} />
                <div className="flex-1">
                  <div className="text-sm font-semibold text-ink-800">{d.type}</div>
                  <div className="text-xs text-ink-400">{d.model} · {d.lastSeen}</div>
                </div>
                <span className="text-xs text-ink-500">Uptime: {d.uptime}%</span>
                <Badge tone={d.status === 'Online' ? 'green' : d.status === 'Degraded' ? 'amber' : 'red'}>{d.status}</Badge>
              </div>
            ))}
          </div>
        </Card>
      )}

      {tab === 'applications' && (
        <Card title="Application Health" subtitle={`${branchApps.length} applications at this branch`}>
          <div className="space-y-2">
            {branchApps.map((a) => (
              <div key={a.name} className="flex items-center gap-3 p-3 rounded-lg" style={{ background: 'var(--ink-50)' }}>
                <AppWindow style={{ width: 16, height: 16, color: a.status === 'Healthy' ? 'var(--emerald-500)' : a.status === 'Warning' ? 'var(--amber-500)' : 'var(--red-500)' }} />
                <div className="flex-1">
                  <div className="text-sm font-semibold text-ink-800">{a.name}</div>
                  <div className="text-xs text-ink-400">{a.category} · Deps: {a.dependencies.join(', ')}</div>
                </div>
                <span className="text-xs text-ink-500" style={{ width: 60 }}>Avail: {a.availability}%</span>
                <span className="text-xs text-ink-500" style={{ width: 50 }}>{a.latency}ms</span>
                <span className="text-xs text-ink-500" style={{ width: 50 }}>{a.errorRate}% err</span>
                <Badge tone={a.status === 'Healthy' ? 'green' : a.status === 'Warning' ? 'amber' : 'red'}>{a.status}</Badge>
              </div>
            ))}
          </div>
        </Card>
      )}

      {tab === 'ivr' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4" style={{ gap: 12 }}>
            <KPI icon={<PhoneCall style={{ width: 18, height: 18 }} />} label="Calls Today" value={branch.calls.toLocaleString()} tone="blue" />
            <KPI icon={<PhoneCall style={{ width: 18, height: 18 }} />} label="IVR Transfers" value={branch.ivrTransfers.toLocaleString()} tone="amber" />
            <KPI icon={<Gauge style={{ width: 18, height: 18 }} />} label="Containment" value={`${branch.ivrContainment}%`} tone="green" />
            <KPI icon={<Clock style={{ width: 18, height: 18 }} />} label="Avg Wait" value={`${branch.waitTime}m`} tone="amber" />
          </div>
          <Card title="IVR & Telephony" subtitle="Call volume, containment, and voice quality for this branch">
            <div className="p-4 rounded-lg" style={{ background: 'var(--ink-50)' }}>
              <div className="grid grid-cols-2 md:grid-cols-4" style={{ gap: 12 }}>
                <div><div className="text-xs text-ink-400">Total Calls</div><div className="text-lg font-bold text-ink-900">{branch.calls.toLocaleString()}</div></div>
                <div><div className="text-xs text-ink-400">IVR Contained</div><div className="text-lg font-bold text-emerald-600">{Math.round(branch.calls * branch.ivrContainment / 100).toLocaleString()}</div></div>
                <div><div className="text-xs text-ink-400">Transferred to Agent</div><div className="text-lg font-bold text-amber-600">{branch.ivrTransfers.toLocaleString()}</div></div>
                <div><div className="text-xs text-ink-400">Avg Wait Time</div><div className="text-lg font-bold text-ink-900">{branch.waitTime} min</div></div>
              </div>
            </div>
          </Card>
        </div>
      )}

      {tab === 'ai' && (
        <div className="space-y-4">
          <Card title="AI Insights" subtitle="AI-generated analysis and recommendations for this branch">
            <div className="p-4 rounded-lg" style={{ background: 'linear-gradient(135deg, #eff6ff, #f5f3ff)' }}>
              <div className="flex items-start gap-3">
                <div style={{ width: 36, height: 36, borderRadius: 10, background: 'var(--brand-600)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <Bot style={{ width: 20, height: 20, color: 'white' }} />
                </div>
                <div>
                  <div className="text-sm font-semibold text-ink-900 mb-2">AI Executive Summary</div>
                  <div className="text-sm text-ink-700">
                    {branch.health >= 90
                      ? `${branch.branch} is operating at excellent health (${branch.health}). All critical systems are functioning normally. ${branch.devicesOffline === 0 ? 'All devices are online.' : `${branch.devicesOffline} device(s) need attention.`} SLA compliance is at ${branch.sla}%.`
                      : branch.health >= 80
                      ? `${branch.branch} is operating with minor degradation (${branch.health}). ${branchIncidents.length > 0 ? `There ${branchIncidents.length === 1 ? 'is' : 'are'} ${branchIncidents.length} active incident(s).` : 'No active incidents.'} ${branch.devicesOffline > 0 ? `${branch.devicesOffline} device(s) are offline.` : 'All devices are online.'} Monitor closely.`
                      : `${branch.branch} requires immediate attention. Health score is ${branch.health} (Critical). ${branchIncidents.filter((i) => i.severity === 'Critical').length} critical incident(s) active. ${branch.devicesOffline} device(s) offline. Immediate remediation recommended.`}
                  </div>
                  <div className="flex items-center gap-2 mt-3">
                    <Badge tone="blue"><Sparkles style={{ width: 10, height: 10 }} /> Confidence: {branch.health >= 85 ? 96 : 91}%</Badge>
                    <span className="text-xs text-ink-400">Based on {scores.length} domain scores, {branchIncidents.length} incidents, {branchDevices.length} devices</span>
                  </div>
                </div>
              </div>
            </div>
          </Card>
          {branchRecs.length > 0 && (
            <Card title="Recommended Actions" subtitle="Prioritized actions generated by AI">
              <div className="space-y-2">
                {branchRecs.map((r, i) => (
                  <div key={i} className="flex items-start gap-3 p-3 rounded-lg" style={{ background: 'var(--ink-50)' }}>
                    <div style={{ width: 28, height: 28, borderRadius: 8, background: r.priority === 'critical' ? '#fee2e2' : r.priority === 'high' ? '#fef3c7' : '#dbeafe', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                      <Sparkles style={{ width: 14, height: 14, color: r.priority === 'critical' ? 'var(--red-600)' : r.priority === 'high' ? 'var(--amber-600)' : 'var(--blue-600)' }} />
                    </div>
                    <div className="flex-1">
                      <div className="text-sm font-semibold text-ink-900">{r.action}</div>
                      <div className="text-xs text-ink-500 mt-1">{r.impact}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs text-ink-400">Confidence</div>
                      <div className="text-sm font-bold" style={{ color: r.priority === 'critical' ? 'var(--red-600)' : 'var(--amber-600)' }}>{r.confidence}%</div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </div>
      )}
    </div>
  )
}
