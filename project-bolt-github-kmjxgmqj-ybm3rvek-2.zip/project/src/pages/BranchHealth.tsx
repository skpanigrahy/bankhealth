import { Card, KPI, ProgressBar, HealthDot, Badge, TrendArrow } from '../components/ui'
import { Link } from 'react-router-dom'
import { HeartPulse, Network, AppWindow, Cpu, Building2, Users, TriangleAlert as AlertTriangle, PhoneCall, Sparkles, ArrowDown, ArrowRight, Bot, ShieldCheck } from 'lucide-react'
import {
  branches, healthDomains, healthStatusLevels, branchDomainScores,
  rootCauseChains, aiRecommendations,
} from '../data/mockData'

const domainIcons: Record<string, any> = {
  'Network Health': Network,
  'Application Health': AppWindow,
  'Device Health': Cpu,
  'Building & Facilities': Building2,
  'Employee Availability': Users,
  'Incident Severity': AlertTriangle,
  'Customer Experience': HeartPulse,
  'IVR & Telephony': PhoneCall,
}

const recPriorityColors: Record<string, string> = {
  critical: '#ef4444', high: '#f59e0b', medium: '#3b82f6', low: '#64748b',
}

export default function BranchHealth() {
  const overall = Math.round(branches.reduce((s, b) => s + b.health, 0) / branches.length)
  const degraded = branches.filter((b) => b.health < 85).length
  const critical = branches.filter((b) => b.health < 80).length

  return (
    <div>
      <div className="space-y-6">
        {/* Overall health KPIs */}
        <div className="grid grid-cols-2 md:grid-cols-4" style={{ gap: 12 }}>
          <KPI icon={<HeartPulse style={{ width: 18, height: 18 }} />} label="Overall Health Score" value={`${overall}`} tone="green" hint="Weighted composite" />
          <KPI icon={<ShieldCheck style={{ width: 18, height: 18 }} />} label="Healthy Branches" value={String(branches.filter((b) => b.health >= 85).length)} tone="green" />
          <KPI icon={<AlertTriangle style={{ width: 18, height: 18 }} />} label="Degraded" value={String(degraded)} tone="amber" />
          <KPI icon={<AlertTriangle style={{ width: 18, height: 18 }} />} label="Critical" value={String(critical)} tone="red" />
        </div>

        {/* Health Score Model */}
        <Card title="Health Score Composition" subtitle="Weighted domains contributing to the composite score">
          <div className="grid grid-cols-2 md:grid-cols-4" style={{ gap: 12 }}>
            {healthDomains.map((d) => {
              const Icon = domainIcons[d.name] || HeartPulse
              return (
                <div key={d.name} className="p-3 rounded-lg" style={{ background: 'var(--ink-50)' }}>
                  <div className="flex items-center gap-2 mb-2">
                    <Icon style={{ width: 16, height: 16, color: d.color }} />
                    <span className="text-xs font-semibold text-ink-700 truncate" style={{ flex: 1 }}>{d.name}</span>
                  </div>
                  <div className="flex items-baseline gap-1">
                    <span className="text-lg font-bold" style={{ color: d.color }}>{d.weight}%</span>
                    <span className="text-xs text-ink-400">weight</span>
                  </div>
                </div>
              )
            })}
          </div>
          <div className="mt-3 p-3 rounded-lg" style={{ background: 'var(--ink-50)' }}>
            <div className="text-xs font-semibold text-ink-500 mb-2">Health Status Levels</div>
            <div className="flex gap-2 flex-wrap">
              {healthStatusLevels.map((l) => (
                <div key={l.status} className="flex items-center gap-1.5 px-2 py-1 rounded" style={{ background: 'white', border: '1px solid var(--ink-100)' }}>
                  <span style={{ width: 8, height: 8, borderRadius: '50%', background: l.color }} />
                  <span className="text-xs font-medium text-ink-700">{l.status}</span>
                  <span className="text-xs text-ink-400">{l.range}</span>
                </div>
              ))}
            </div>
          </div>
        </Card>

        {/* Root Cause Analysis */}
        <Card title="Root Cause Analysis" subtitle="Correlated telemetry chains ranked by confidence">
          <div className="space-y-4">
            {rootCauseChains.map((chain) => (
              <div key={chain.branchId} className="p-4 rounded-lg" style={{ background: 'var(--ink-50)' }}>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Link to="/branch-map" className="text-sm font-bold text-ink-900 hover:underline">{chain.title}</Link>
                    <Badge tone={chain.confidence >= 90 ? 'green' : chain.confidence >= 80 ? 'amber' : 'neutral'}>{chain.confidence}% confidence</Badge>
                  </div>
                </div>
                <div className="flex items-center flex-wrap" style={{ gap: 4 }}>
                  {chain.chain.map((step, i) => (
                    <div key={i} className="flex items-center" style={{ gap: 4 }}>
                      <div className="px-3 py-2 rounded-lg" style={{ background: 'white', border: '1px solid var(--ink-100)' }}>
                        <div className="text-xs font-semibold text-ink-800">{step.event}</div>
                        <div className="text-xs text-ink-400">{step.domain} · {step.time}</div>
                      </div>
                      {i < chain.chain.length - 1 && <ArrowDown style={{ width: 14, height: 14, color: 'var(--ink-400)' }} />}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* AI Recommendations */}
        <Card title="AI Recommendations" subtitle="Contextual actions generated by the platform">
          <div className="space-y-2">
            {aiRecommendations.map((r, i) => {
              const b = branches.find((b) => b.id === r.branchId)
              const color = recPriorityColors[r.priority]
              return (
                <div key={i} className="flex items-start gap-3 p-3 rounded-lg" style={{ background: 'var(--ink-50)' }}>
                  <div style={{ width: 32, height: 32, borderRadius: 8, background: `${color}1a`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <Sparkles style={{ width: 16, height: 16, color }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-semibold text-ink-900">{r.action}</span>
                      <Badge tone={r.priority === 'critical' ? 'red' : r.priority === 'high' ? 'amber' : r.priority === 'medium' ? 'blue' : 'neutral'}>{r.priority}</Badge>
                    </div>
                    <div className="text-xs text-ink-500 mt-1">{b?.branch} · {r.impact}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-ink-400">Confidence</div>
                    <div className="text-sm font-bold" style={{ color }}>{r.confidence}%</div>
                  </div>
                </div>
              )
            })}
          </div>
        </Card>

        {/* All branches with domain breakdown */}
        <Card title="Branch Health Breakdown" subtitle={`${branches.length} branches · click to view on map`}>
          <div className="space-y-1">
            <div className="flex items-center text-xs font-semibold text-ink-400 px-2 pb-2" style={{ borderBottom: '1px solid var(--ink-100)' }}>
              <span style={{ flex: 1 }}>Branch</span>
              {healthDomains.slice(0, 5).map((d) => (
                <span key={d.name} style={{ width: 56, textAlign: 'center' }} title={d.name}>{d.name.split(' ')[0]}</span>
              ))}
              <span style={{ width: 50, textAlign: 'center' }}>Score</span>
              <span style={{ width: 60, textAlign: 'center' }}>Status</span>
            </div>
            {branches.map((b) => {
              const scores = branchDomainScores(b.id)
              return (
                <Link key={b.id} to="/branch-map" className="block">
                  <div className="flex items-center px-2 py-2 rounded-lg hover:bg-ink-50 transition-colors">
                    <div className="flex items-center gap-2" style={{ flex: 1 }}>
                      <HealthDot value={b.health} />
                      <div className="min-w-0">
                        <div className="text-sm font-semibold text-ink-800 truncate">{b.branch}</div>
                        <div className="text-xs text-ink-400 truncate">{b.city}, {b.country}</div>
                      </div>
                    </div>
                    {scores.slice(0, 5).map((s) => (
                      <div key={s.name} style={{ width: 56, textAlign: 'center' }}>
                        <div className="flex items-center justify-center gap-1">
                          <span className="text-xs font-semibold" style={{ color: s.score >= 90 ? 'var(--emerald-600)' : s.score >= 75 ? 'var(--amber-600)' : 'var(--red-600)' }}>{s.score}</span>
                          <TrendArrow value={s.trend} />
                        </div>
                      </div>
                    ))}
                    <span className="text-sm font-bold" style={{ width: 50, textAlign: 'center', color: b.health >= 90 ? 'var(--emerald-600)' : b.health >= 80 ? 'var(--amber-600)' : 'var(--red-600)' }}>{b.health}</span>
                    <span style={{ width: 60, textAlign: 'center' }}>
                      <Badge tone={b.health >= 90 ? 'green' : b.health >= 80 ? 'amber' : 'red'}>{b.health >= 95 ? 'Excellent' : b.health >= 85 ? 'Healthy' : b.health >= 70 ? 'Warning' : 'Critical'}</Badge>
                    </span>
                  </div>
                </Link>
              )
            })}
          </div>
        </Card>
      </div>
    </div>
  )
}
