import { useParams, useNavigate } from 'react-router-dom'
import { Card } from '../components/ui'
import { products } from '../data/projects'
import * as Icons from 'lucide-react'
import { ArrowLeft, Sparkles, Clock, CircleCheck as CheckCircle2 } from 'lucide-react'

export default function ProductLanding() {
  const { productId } = useParams()
  const navigate = useNavigate()
  const product = products.find((p) => p.id === productId)

  if (!product) {
    return (
      <div>
        <Card>
          <div className="text-center py-12">
            <div className="text-lg font-bold text-ink-900 mb-2">Product not found</div>
            <button onClick={() => navigate('/')} className="text-sm font-semibold text-brand-600">Return to Know Your Branch</button>
          </div>
        </Card>
      </div>
    )
  }

  const Icon = (Icons as any)[product.icon] as Icons.LucideIcon

  return (
    <div>
      <button onClick={() => navigate('/')} className="back-link">
        <ArrowLeft style={{ width: 14, height: 14 }} /> Back to Know Your Branch
      </button>

      <Card>
        <div className="flex flex-col items-center text-center py-12">
          <div style={{
            width: 72, height: 72, borderRadius: 18,
            background: `${product.color}1a`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            marginBottom: 20,
          }}>
            <Icon style={{ width: 36, height: 36, color: product.color }} />
          </div>

          <h2 className="text-xl font-bold text-ink-900">{product.name}</h2>
          <div className="text-sm text-ink-400 mt-1">{product.short} · Enterprise Suite</div>
          <p className="text-sm text-ink-500 mt-3" style={{ maxWidth: 420 }}>
            {product.description}. This product is part of the enterprise operational intelligence suite and is currently in the roadmap for future development.
          </p>

          <div className="flex items-center gap-2 mt-6">
            <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-full" style={{ background: '#fef3c7', color: '#92400e', fontSize: 12, fontWeight: 600 }}>
              <Clock style={{ width: 12, height: 12 }} /> Coming Soon
            </span>
            <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-full" style={{ background: '#eff6ff', color: '#1e40af', fontSize: 12, fontWeight: 600 }}>
              <Sparkles style={{ width: 12, height: 12 }} /> Roadmap Phase 2
            </span>
          </div>
        </div>
      </Card>

      <Card title="What to expect" subtitle={`Planned capabilities for ${product.name}`}>
        <div className="grid grid-cols-1 md:grid-cols-2" style={{ gap: 12 }}>
          {[
            'Unified dashboard with real-time monitoring',
            'AI-powered insights and recommendations',
            'Drill-down navigation from enterprise to entity level',
            'Integrated alerting and incident management',
            'Executive reporting and export capabilities',
            'Role-based access for different personas',
          ].map((cap, i) => (
            <div key={i} className="flex items-center gap-2 p-3 rounded-lg" style={{ background: 'var(--ink-50)' }}>
              <CheckCircle2 style={{ width: 16, height: 16, color: 'var(--emerald-500)', flexShrink: 0 }} />
              <span className="text-sm text-ink-700">{cap}</span>
            </div>
          ))}
        </div>
      </Card>

      <Card>
        <div className="text-center py-6">
          <p className="text-sm text-ink-500 mb-4">Know Your Branch is the first product in the enterprise suite and is available now.</p>
          <button
            onClick={() => navigate('/')}
            className="inline-flex items-center gap-2 text-sm font-semibold text-white rounded-lg px-5 py-2.5"
            style={{ background: 'var(--brand-600)' }}
          >
            Go to Know Your Branch
          </button>
        </div>
      </Card>
    </div>
  )
}
