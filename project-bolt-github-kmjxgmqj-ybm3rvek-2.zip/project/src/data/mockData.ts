export interface BranchRow {
  id: string
  branch: string
  country: string
  countryCode: string
  region: string
  market: string
  city: string
  state: string
  lat: number
  lng: number
  manager: string
  costCenter: string
  health: number
  ivrContainment: number
  openTickets: number
  devices: number
  devicesOffline: number
  sla: number
  employees: number
  utilisation: number
  customers: number
  transactions: number
  calls: number
  ivrTransfers: number
  waitTime: number
  buildingStatus: string
  operatingStatus: string
  branchType: string
}

export const branches: BranchRow[] = [
  // --- United States ---
  { id: 'BR-101', branch: 'New York - Midtown', country: 'United States', countryCode: 'US', region: 'Northeast', market: 'Metro', city: 'New York', state: 'New York', lat: 40.7549, lng: -73.9840, manager: 'J. Anderson', costCenter: 'CC-NYC-01', health: 94, ivrContainment: 81, openTickets: 3, devices: 156, devicesOffline: 1, sla: 99, employees: 52, utilisation: 85, customers: 1820, transactions: 5210, calls: 6210, ivrTransfers: 1180, waitTime: 2.8, buildingStatus: 'Excellent', operatingStatus: 'Open', branchType: 'Full Service' },
  { id: 'BR-102', branch: 'San Francisco - Financial District', country: 'United States', countryCode: 'US', region: 'West', market: 'Metro', city: 'San Francisco', state: 'California', lat: 37.7946, lng: -122.3999, manager: 'S. Chen', costCenter: 'CC-SF-01', health: 91, ivrContainment: 78, openTickets: 4, devices: 134, devicesOffline: 1, sla: 98, employees: 44, utilisation: 82, customers: 1410, transactions: 4120, calls: 4920, ivrTransfers: 1082, waitTime: 3.1, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Full Service' },
  { id: 'BR-103', branch: 'Chicago - Loop', country: 'United States', countryCode: 'US', region: 'Midwest', market: 'Metro', city: 'Chicago', state: 'Illinois', lat: 41.8781, lng: -87.6298, manager: 'M. Johnson', costCenter: 'CC-CHI-01', health: 89, ivrContainment: 74, openTickets: 6, devices: 112, devicesOffline: 2, sla: 96, employees: 38, utilisation: 78, customers: 1180, transactions: 3480, calls: 4180, ivrTransfers: 1087, waitTime: 3.6, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Full Service' },
  { id: 'BR-104', branch: 'Houston - Galleria', country: 'United States', countryCode: 'US', region: 'South', market: 'Metro', city: 'Houston', state: 'Texas', lat: 29.7380, lng: -95.4612, manager: 'R. Martinez', costCenter: 'CC-HOU-01', health: 85, ivrContainment: 70, openTickets: 8, devices: 98, devicesOffline: 2, sla: 94, employees: 33, utilisation: 75, customers: 920, transactions: 2740, calls: 3310, ivrTransfers: 993, waitTime: 4.2, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Standard' },
  { id: 'BR-105', branch: 'Atlanta - Buckhead', country: 'United States', countryCode: 'US', region: 'Southeast', market: 'Metro', city: 'Atlanta', state: 'Georgia', lat: 33.8467, lng: -84.3646, manager: 'D. Williams', costCenter: 'CC-ATL-01', health: 87, ivrContainment: 73, openTickets: 5, devices: 104, devicesOffline: 1, sla: 95, employees: 35, utilisation: 77, customers: 1020, transactions: 3020, calls: 3680, ivrTransfers: 994, waitTime: 3.8, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Full Service' },
  { id: 'BR-106', branch: 'Seattle - Downtown', country: 'United States', countryCode: 'US', region: 'West', market: 'Metro', city: 'Seattle', state: 'Washington', lat: 47.6062, lng: -122.3321, manager: 'L. Park', costCenter: 'CC-SEA-01', health: 93, ivrContainment: 80, openTickets: 2, devices: 128, devicesOffline: 0, sla: 99, employees: 41, utilisation: 83, customers: 1340, transactions: 3960, calls: 4720, ivrTransfers: 944, waitTime: 2.9, buildingStatus: 'Excellent', operatingStatus: 'Open', branchType: 'Full Service' },
  { id: 'BR-107', branch: 'Miami - Brickell', country: 'United States', countryCode: 'US', region: 'Southeast', market: 'Metro', city: 'Miami', state: 'Florida', lat: 25.7934, lng: -80.1902, manager: 'C. Rodriguez', costCenter: 'CC-MIA-01', health: 82, ivrContainment: 67, openTickets: 9, devices: 86, devicesOffline: 3, sla: 91, employees: 28, utilisation: 71, customers: 740, transactions: 2180, calls: 2680, ivrTransfers: 884, waitTime: 5.2, buildingStatus: 'Fair', operatingStatus: 'Open', branchType: 'Standard' },
  { id: 'BR-108', branch: 'Denver - Cherry Creek', country: 'United States', countryCode: 'US', region: 'West', market: 'Urban', city: 'Denver', state: 'Colorado', lat: 39.7174, lng: -104.9534, manager: 'B. Taylor', costCenter: 'CC-DEN-01', health: 88, ivrContainment: 75, openTickets: 4, devices: 92, devicesOffline: 1, sla: 96, employees: 30, utilisation: 76, customers: 860, transactions: 2520, calls: 3020, ivrTransfers: 755, waitTime: 3.5, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Standard' },
  { id: 'BR-109', branch: 'Boston - Back Bay', country: 'United States', countryCode: 'US', region: 'Northeast', market: 'Metro', city: 'Boston', state: 'Massachusetts', lat: 42.3505, lng: -71.0810, manager: 'E. Murphy', costCenter: 'CC-BOS-01', health: 90, ivrContainment: 77, openTickets: 3, devices: 108, devicesOffline: 0, sla: 97, employees: 36, utilisation: 80, customers: 1120, transactions: 3340, calls: 4020, ivrTransfers: 925, waitTime: 3.0, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Full Service' },
  { id: 'BR-110', branch: 'Phoenix - Scottsdale', country: 'United States', countryCode: 'US', region: 'West', market: 'Urban', city: 'Phoenix', state: 'Arizona', lat: 33.4942, lng: -111.9256, manager: 'T. Nguyen', costCenter: 'CC-PHX-01', health: 86, ivrContainment: 72, openTickets: 6, devices: 88, devicesOffline: 2, sla: 94, employees: 27, utilisation: 73, customers: 780, transactions: 2280, calls: 2780, ivrTransfers: 778, waitTime: 4.0, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Standard' },
  // --- China ---
  { id: 'BR-201', branch: 'Shanghai - Lujiazui', country: 'China', countryCode: 'CN', region: 'East', market: 'Metro', city: 'Shanghai', state: 'Shanghai', lat: 31.2397, lng: 121.4998, manager: 'W. Zhang', costCenter: 'CC-SHA-01', health: 92, ivrContainment: 79, openTickets: 4, devices: 148, devicesOffline: 1, sla: 98, employees: 46, utilisation: 83, customers: 1620, transactions: 4720, calls: 5720, ivrTransfers: 1201, waitTime: 3.0, buildingStatus: 'Excellent', operatingStatus: 'Open', branchType: 'Full Service' },
  { id: 'BR-202', branch: 'Beijing - CBD', country: 'China', countryCode: 'CN', region: 'North', market: 'Metro', city: 'Beijing', state: 'Beijing', lat: 39.9087, lng: 116.3974, manager: 'L. Wang', costCenter: 'CC-BJ-01', health: 90, ivrContainment: 76, openTickets: 5, devices: 132, devicesOffline: 2, sla: 97, employees: 42, utilisation: 81, customers: 1380, transactions: 4080, calls: 4880, ivrTransfers: 1171, waitTime: 3.4, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Full Service' },
  { id: 'BR-203', branch: 'Shenzhen - Futian', country: 'China', countryCode: 'CN', region: 'South', market: 'Metro', city: 'Shenzhen', state: 'Guangdong', lat: 22.5431, lng: 114.0579, manager: 'H. Liu', costCenter: 'CC-SZ-01', health: 88, ivrContainment: 73, openTickets: 7, devices: 118, devicesOffline: 2, sla: 95, employees: 38, utilisation: 79, customers: 1140, transactions: 3380, calls: 4080, ivrTransfers: 1102, waitTime: 3.8, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Full Service' },
  { id: 'BR-204', branch: 'Guangzhou - Tianhe', country: 'China', countryCode: 'CN', region: 'South', market: 'Metro', city: 'Guangzhou', state: 'Guangdong', lat: 23.1376, lng: 113.3246, manager: 'X. Chen', costCenter: 'CC-GZ-01', health: 84, ivrContainment: 68, openTickets: 9, devices: 96, devicesOffline: 3, sla: 92, employees: 32, utilisation: 74, customers: 880, transactions: 2620, calls: 3180, ivrTransfers: 1018, waitTime: 4.6, buildingStatus: 'Fair', operatingStatus: 'Open', branchType: 'Standard' },
  // --- India ---
  { id: 'BR-301', branch: 'Mumbai - Fort', country: 'India', countryCode: 'IN', region: 'West', market: 'Metro', city: 'Mumbai', state: 'Maharashtra', lat: 18.9289, lng: 72.8320, manager: 'A. Sharma', costCenter: 'CC-MUM-01', health: 92, ivrContainment: 78, openTickets: 4, devices: 126, devicesOffline: 1, sla: 98, employees: 42, utilisation: 81, customers: 1240, transactions: 3820, calls: 4820, ivrTransfers: 1060, waitTime: 3.2, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Full Service' },
  { id: 'BR-302', branch: 'Delhi - Connaught', country: 'India', countryCode: 'IN', region: 'North', market: 'Metro', city: 'Delhi', state: 'Delhi', lat: 28.6328, lng: 77.2197, manager: 'P. Gupta', costCenter: 'CC-DEL-01', health: 88, ivrContainment: 71, openTickets: 7, devices: 98, devicesOffline: 2, sla: 95, employees: 36, utilisation: 77, customers: 980, transactions: 2940, calls: 3940, ivrTransfers: 1142, waitTime: 4.1, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Full Service' },
  { id: 'BR-303', branch: 'Bengaluru - MG Road', country: 'India', countryCode: 'IN', region: 'South', market: 'Metro', city: 'Bengaluru', state: 'Karnataka', lat: 12.9756, lng: 77.6067, manager: 'D. Reddy', costCenter: 'CC-BLR-01', health: 95, ivrContainment: 82, openTickets: 2, devices: 142, devicesOffline: 0, sla: 99, employees: 48, utilisation: 84, customers: 1520, transactions: 4210, calls: 5210, ivrTransfers: 938, waitTime: 2.5, buildingStatus: 'Excellent', operatingStatus: 'Open', branchType: 'Full Service' },
  { id: 'BR-304', branch: 'Chennai - T. Nagar', country: 'India', countryCode: 'IN', region: 'South', market: 'Urban', city: 'Chennai', state: 'Tamil Nadu', lat: 13.0418, lng: 80.2341, manager: 'L. Krishnan', costCenter: 'CC-MAA-01', health: 84, ivrContainment: 69, openTickets: 9, devices: 87, devicesOffline: 3, sla: 92, employees: 31, utilisation: 73, customers: 760, transactions: 2180, calls: 2870, ivrTransfers: 891, waitTime: 5.4, buildingStatus: 'Fair', operatingStatus: 'Open', branchType: 'Standard' },
  { id: 'BR-305', branch: 'Kolkata - Park Street', country: 'India', countryCode: 'IN', region: 'East', market: 'Metro', city: 'Kolkata', state: 'West Bengal', lat: 22.5547, lng: 88.3510, manager: 'S. Banerjee', costCenter: 'CC-CCU-01', health: 79, ivrContainment: 64, openTickets: 12, devices: 76, devicesOffline: 4, sla: 89, employees: 28, utilisation: 69, customers: 640, transactions: 1820, calls: 2210, ivrTransfers: 796, waitTime: 6.8, buildingStatus: 'Fair', operatingStatus: 'Degraded', branchType: 'Standard' },
  // --- United Kingdom ---
  { id: 'BR-401', branch: 'London - City', country: 'United Kingdom', countryCode: 'GB', region: 'Greater London', market: 'Metro', city: 'London', state: 'England', lat: 51.5144, lng: -0.0929, manager: 'O. Bennett', costCenter: 'CC-LON-01', health: 91, ivrContainment: 77, openTickets: 4, devices: 124, devicesOffline: 1, sla: 97, employees: 40, utilisation: 80, customers: 1280, transactions: 3760, calls: 4560, ivrTransfers: 1050, waitTime: 3.1, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Full Service' },
  { id: 'BR-402', branch: 'Manchester - Spinningfields', country: 'United Kingdom', countryCode: 'GB', region: 'North West', market: 'Urban', city: 'Manchester', state: 'England', lat: 53.4794, lng: -2.2540, manager: 'G. Hughes', costCenter: 'CC-MAN-01', health: 85, ivrContainment: 71, openTickets: 7, devices: 92, devicesOffline: 2, sla: 94, employees: 30, utilisation: 75, customers: 820, transactions: 2420, calls: 2920, ivrTransfers: 847, waitTime: 4.0, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Standard' },
  // --- Singapore ---
  { id: 'BR-501', branch: 'Singapore - Raffles Place', country: 'Singapore', countryCode: 'SG', region: 'Central', market: 'Metro', city: 'Singapore', state: 'Singapore', lat: 1.2833, lng: 103.8513, manager: 'J. Tan', costCenter: 'CC-SG-01', health: 93, ivrContainment: 80, openTickets: 3, devices: 116, devicesOffline: 0, sla: 99, employees: 38, utilisation: 82, customers: 1320, transactions: 3880, calls: 4680, ivrTransfers: 936, waitTime: 2.7, buildingStatus: 'Excellent', operatingStatus: 'Open', branchType: 'Full Service' },
  // --- Germany ---
  { id: 'BR-601', branch: 'Frankfurt - Bankenviertel', country: 'Germany', countryCode: 'DE', region: 'Hesse', market: 'Metro', city: 'Frankfurt', state: 'Hesse', lat: 50.1136, lng: 8.6785, manager: 'K. Müller', costCenter: 'CC-FRA-01', health: 89, ivrContainment: 74, openTickets: 5, devices: 104, devicesOffline: 1, sla: 96, employees: 34, utilisation: 78, customers: 980, transactions: 2880, calls: 3480, ivrTransfers: 905, waitTime: 3.4, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Full Service' },
  // --- Japan ---
  { id: 'BR-701', branch: 'Tokyo - Marunouchi', country: 'Japan', countryCode: 'JP', region: 'Kanto', market: 'Metro', city: 'Tokyo', state: 'Tokyo', lat: 35.6812, lng: 139.7671, manager: 'Y. Sato', costCenter: 'CC-TYO-01', health: 90, ivrContainment: 76, openTickets: 4, devices: 130, devicesOffline: 1, sla: 97, employees: 42, utilisation: 81, customers: 1480, transactions: 4320, calls: 5180, ivrTransfers: 1243, waitTime: 3.2, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Full Service' },
  // --- UAE ---
  { id: 'BR-801', branch: 'Dubai - DIFC', country: 'United Arab Emirates', countryCode: 'AE', region: 'Dubai', market: 'Metro', city: 'Dubai', state: 'Dubai', lat: 25.2138, lng: 55.2790, manager: 'F. Al-Hashimi', costCenter: 'CC-DXB-01', health: 87, ivrContainment: 72, openTickets: 6, devices: 100, devicesOffline: 2, sla: 95, employees: 32, utilisation: 76, customers: 1060, transactions: 3120, calls: 3820, ivrTransfers: 1069, waitTime: 3.6, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Full Service' },
  // --- Australia ---
  { id: 'BR-901', branch: 'Sydney - Martin Place', country: 'Australia', countryCode: 'AU', region: 'New South Wales', market: 'Metro', city: 'Sydney', state: 'New South Wales', lat: -33.8678, lng: 151.2073, manager: 'N. Clarke', costCenter: 'CC-SYD-01', health: 88, ivrContainment: 73, openTickets: 5, devices: 108, devicesOffline: 1, sla: 96, employees: 35, utilisation: 77, customers: 1020, transactions: 3020, calls: 3680, ivrTransfers: 994, waitTime: 3.5, buildingStatus: 'Good', operatingStatus: 'Open', branchType: 'Full Service' },
]

export const alerts = [
  { id: 1, severity: 'critical', title: 'Kolkata - SIP trunk down', time: '12 min ago', branch: 'Kolkata - Park Street' },
  { id: 2, severity: 'high', title: 'Miami - ATM #3 offline', time: '28 min ago', branch: 'Miami - Brickell' },
  { id: 3, severity: 'medium', title: 'Houston - WAN latency > 45ms', time: '41 min ago', branch: 'Houston - Galleria' },
  { id: 4, severity: 'low', title: 'London - certificate expiring in 7 days', time: '1 hr ago', branch: 'London - City' },
  { id: 5, severity: 'medium', title: 'Chicago - queue wait time > 5 min', time: '2 hr ago', branch: 'Chicago - Loop' },
  { id: 6, severity: 'high', title: 'Kolkata - backup circuit at 92% utilization', time: '15 min ago', branch: 'Kolkata - Park Street' },
]

// === Health Score Composition (per PRD Module 4) ===
export const healthDomains = [
  { name: 'Network Health', weight: 20, color: '#3b82f6' },
  { name: 'Application Health', weight: 20, color: '#8b5cf6' },
  { name: 'Device Health', weight: 15, color: '#f59e0b' },
  { name: 'Building & Facilities', weight: 10, color: '#10b981' },
  { name: 'Employee Availability', weight: 10, color: '#06b6d4' },
  { name: 'Incident Severity', weight: 10, color: '#ef4444' },
  { name: 'Customer Experience', weight: 10, color: '#ec4899' },
  { name: 'IVR & Telephony', weight: 5, color: '#6366f1' },
]

export const healthStatusLevels = [
  { range: '95-100', status: 'Excellent', color: '#10b981' },
  { range: '85-94', status: 'Healthy', color: '#84cc16' },
  { range: '70-84', status: 'Warning', color: '#f59e0b' },
  { range: '50-69', status: 'Degraded', color: '#f97316' },
  { range: '<50', status: 'Critical', color: '#ef4444' },
]

// Domain scores per branch (deterministic from branch id)
export function branchDomainScores(branchId: string) {
  const seed = branchId.charCodeAt(3) + branchId.charCodeAt(4)
  const base = branches.find((b) => b.id === branchId)?.health ?? 85
  const variance = (i: number) => ((seed * (i + 1)) % 21) - 10
  return healthDomains.map((d, i) => {
    const score = Math.max(40, Math.min(100, base + variance(i)))
    const trend = ((seed + i) % 3) - 1
    return { ...d, score, trend: (trend > 0 ? 'up' : trend < 0 ? 'down' : 'flat') as 'up' | 'down' | 'flat' }
  })
}

// === Root Cause Analysis (per PRD Module 4, Section 4) ===
export const rootCauseChains = [
  {
    branchId: 'BR-305',
    title: 'Kolkata - Park Street',
    confidence: 92,
    chain: [
      { event: 'Primary WAN circuit failure', domain: 'Network', time: '10:35 AM' },
      { event: 'SIP trunk unavailable', domain: 'Telephony', time: '10:38 AM' },
      { event: 'IVR self-service down', domain: 'Application', time: '10:41 AM' },
      { event: 'Calls routed to backup queue', domain: 'Customer Experience', time: '10:44 AM' },
      { event: 'Wait time exceeded 6 min', domain: 'Customer Experience', time: '10:52 AM' },
      { event: 'Branch health dropped to 79', domain: 'Health', time: '10:55 AM' },
    ],
  },
  {
    branchId: 'BR-107',
    title: 'Miami - Brickell',
    confidence: 87,
    chain: [
      { event: 'ATM #3 cash dispenser fault', domain: 'Device', time: '11:02 AM' },
      { event: 'ATM marked offline', domain: 'Device', time: '11:05 AM' },
      { event: 'Customer transactions rerouted', domain: 'Application', time: '11:10 AM' },
      { event: 'Teller queue increased 23%', domain: 'Customer Experience', time: '11:18 AM' },
    ],
  },
  {
    branchId: 'BR-104',
    title: 'Houston - Galleria',
    confidence: 78,
    chain: [
      { event: 'WAN latency spike to 47ms', domain: 'Network', time: '09:15 AM' },
      { event: 'Core banking response slow', domain: 'Application', time: '09:20 AM' },
      { event: 'Teller transactions delayed', domain: 'Customer Experience', time: '09:28 AM' },
    ],
  },
]

// === AI Recommendations (per PRD Module 4, Section 5) ===
export const aiRecommendations = [
  { branchId: 'BR-305', priority: 'critical', action: 'Fail over to backup ISP circuit', impact: 'Restore IVR and telephony within 5 min', confidence: 94 },
  { branchId: 'BR-305', priority: 'high', action: 'Dispatch network engineer to Kolkata', impact: 'On-site circuit repair estimated 2 hrs', confidence: 88 },
  { branchId: 'BR-107', priority: 'high', action: 'Dispatch cash replenishment team', impact: 'Restore ATM #3 within 90 min', confidence: 91 },
  { branchId: 'BR-104', priority: 'medium', action: 'Schedule WAN circuit upgrade', impact: 'Reduce latency below 30ms baseline', confidence: 76 },
  { branchId: 'BR-401', priority: 'low', action: 'Renew SSL certificate (expires in 7 days)', impact: 'Prevent authentication service disruption', confidence: 99 },
  { branchId: 'BR-103', priority: 'medium', action: 'Add 2 tellers during 12-2 PM peak', impact: 'Reduce queue wait below 3 min', confidence: 82 },
]

// === Executive KPI Cards (per PRD Module 1) ===
export const executiveKPIs = {
  overallHealth: 88,
  totalBranches: 27,
  healthyBranches: 18,
  warningBranches: 7,
  criticalBranches: 2,
  activeIncidents: 14,
  majorOutages: 1,
  avgSla: 96,
  customerSatisfaction: 4.2,
  ivrContainment: 75,
  employeeAvailability: 91,
  operationalCostIndex: 103,
}

// === 30-day Executive Trends (per PRD Module 1) ===
export const executiveTrends = {
  branchHealth: [85, 86, 84, 87, 88, 86, 89, 90, 88, 87, 89, 90, 91, 88, 87, 88, 89, 90, 88, 87, 88, 89, 90, 91, 88, 89, 88, 89, 88, 88],
  incidentVolume: [12, 10, 14, 11, 9, 13, 15, 12, 10, 8, 11, 13, 14, 12, 10, 9, 11, 13, 15, 12, 10, 9, 11, 10, 12, 14, 13, 11, 14, 14],
  networkAvailability: [99.2, 99.1, 99.3, 99.4, 99.2, 99.0, 98.8, 99.1, 99.3, 99.4, 99.5, 99.3, 99.2, 99.1, 99.0, 98.9, 99.1, 99.2, 99.3, 99.4, 99.3, 99.2, 99.1, 99.0, 98.8, 98.9, 99.0, 99.1, 99.0, 98.9],
  customerTransactions: [8200, 8500, 8100, 8800, 9100, 8700, 8900, 9200, 8800, 8500, 8900, 9100, 9300, 8800, 8600, 8900, 9100, 9300, 8900, 8600, 8900, 9100, 9300, 9500, 9100, 8900, 9100, 9300, 8900, 8700],
  voiceQuality: [4.1, 4.0, 4.2, 4.1, 4.0, 3.9, 4.0, 4.1, 4.2, 4.1, 4.0, 4.1, 4.2, 4.1, 4.0, 3.9, 4.0, 4.1, 4.2, 4.1, 4.0, 4.1, 4.2, 4.1, 4.0, 3.9, 4.0, 4.1, 4.0, 3.9],
  ivrContainment: [72, 73, 74, 73, 72, 74, 75, 76, 75, 74, 73, 75, 76, 77, 75, 74, 73, 75, 76, 75, 74, 75, 76, 75, 74, 75, 76, 75, 75, 75],
  employeeUtilization: [78, 79, 77, 80, 81, 79, 82, 83, 81, 80, 79, 81, 82, 83, 81, 80, 79, 81, 82, 81, 80, 81, 82, 83, 81, 80, 79, 81, 80, 79],
}

// === AI Executive Summary (per PRD Module 1) ===
export const aiExecutiveSummary = [
  { type: 'positive', text: 'Branch availability improved by 3.2% this week, driven by Northeast region recovery.' },
  { type: 'warning', text: 'Network latency increased across the Northeast region by 12% over the last 48 hours.' },
  { type: 'negative', text: 'Customer abandonment increased by 5% during peak hours (12-2 PM) at 4 branches.' },
  { type: 'critical', text: 'Kolkata - Park Street requires immediate attention: SIP trunk down, health at 79.' },
  { type: 'positive', text: 'IVR containment rate improved to 75%, reducing call center load by ~1,200 calls/day.' },
]

// === Network Health (per PRD Module - Network Monitoring) ===
export interface NetworkCircuit {
  branchId: string
  branch: string
  type: 'WAN' | 'LAN' | 'WiFi' | 'SIP Trunk'
  provider: string
  bandwidth: string
  utilization: number
  latency: number
  packetLoss: number
  status: 'Healthy' | 'Warning' | 'Critical'
}

export const networkCircuits: NetworkCircuit[] = branches.flatMap((b) => {
  const seed = b.id.charCodeAt(3) + b.id.charCodeAt(4)
  const lat = 18 + (seed % 30)
  const util = 30 + (seed % 60)
  const loss = seed % 5 === 0 ? 2.1 : 0.3 + (seed % 10) / 10
  const status: NetworkCircuit['status'] = b.health < 82 ? 'Critical' : b.health < 88 ? 'Warning' : 'Healthy'
  return [
    { branchId: b.id, branch: b.branch, type: 'WAN', provider: 'AT&T MPLS', bandwidth: '100 Mbps', utilization: util, latency: lat, packetLoss: loss, status },
    { branchId: b.id, branch: b.branch, type: 'LAN', provider: 'Cisco Catalyst', bandwidth: '1 Gbps', utilization: Math.min(95, util + 15), latency: 2, packetLoss: 0, status: 'Healthy' },
    { branchId: b.id, branch: b.branch, type: 'WiFi', provider: 'Aruba AP-535', bandwidth: '500 Mbps', utilization: Math.min(80, util - 10), latency: 5, packetLoss: 0.1, status: 'Healthy' },
    { branchId: b.id, branch: b.branch, type: 'SIP Trunk', provider: 'Twilio Voice', bandwidth: '50 concurrent', utilization: Math.min(90, util + 20), latency: lat + 8, packetLoss: loss, status: b.health < 82 ? 'Critical' : 'Healthy' },
  ]
})

// === Device Health (per PRD Module - Device Monitoring) ===
export interface DeviceRecord {
  branchId: string
  branch: string
  type: 'ATM' | 'Teller' | 'Kiosk' | 'POS' | 'Printer' | 'Camera' | 'UPS' | 'Server'
  model: string
  status: 'Online' | 'Offline' | 'Degraded'
  uptime: number
  lastSeen: string
}

const deviceModels: Record<DeviceRecord['type'], string[]> = {
  ATM: ['NCR SelfServ 6622', 'Diebold Opteva 5625', 'Hyosung Halo II'],
  Teller: ['Dell OptiPlex 7090', 'HP EliteDesk 800 G6'],
  Kiosk: ['Samsung KMX-550', 'Olea Kiosk K21'],
  POS: ['Verifone MX925', 'Ingenico ICT250'],
  Printer: ['HP LaserJet Pro M404', 'Canon imageRUNNER 2630'],
  Camera: ['Axis Q3517', 'Hikvision DS-2CD2146'],
  UPS: ['APC Smart-UPS 1500VA', 'Eaton 9PX 3000VA'],
  Server: ['Dell PowerEdge R650', 'HPE ProLiant DL380 Gen10'],
}

export const devices: DeviceRecord[] = branches.flatMap((b) => {
  const seed = b.id.charCodeAt(3) + b.id.charCodeAt(4)
  const types: DeviceRecord['type'][] = ['ATM', 'Teller', 'Kiosk', 'POS', 'Printer', 'Camera', 'UPS', 'Server']
  return types.map((type, i) => {
    const models = deviceModels[type]
    const model = models[(seed + i) % models.length]
    const isOffline = b.devicesOffline > 0 && i === 0 && b.health < 85
    const isDegraded = !isOffline && b.health < 85 && i === 1
    const status: DeviceRecord['status'] = isOffline ? 'Offline' : isDegraded ? 'Degraded' : 'Online'
    const uptime = isOffline ? 0 : isDegraded ? 94 + (seed % 5) : 99 + (seed % 2)
    return {
      branchId: b.id, branch: b.branch, type, model, status, uptime,
      lastSeen: isOffline ? '2 hr ago' : isDegraded ? '5 min ago' : 'Online now',
    }
  })
})

// === Application Health (per PRD Module - Application Monitoring) ===
export interface AppRecord {
  branchId: string
  branch: string
  name: string
  category: 'Core Banking' | 'Teller' | 'CRM' | 'Authentication' | 'Branch Portal' | 'Payments'
  availability: number
  latency: number
  errorRate: number
  dependencies: string[]
  status: 'Healthy' | 'Warning' | 'Critical'
}

const appTemplates = [
  { name: 'Core Banking System', category: 'Core Banking' as const, deps: ['Oracle DB', 'MQ Broker', 'Auth Service'] },
  { name: 'Teller Application', category: 'Teller' as const, deps: ['Core Banking', 'Auth Service', 'Printer Service'] },
  { name: 'CRM Platform', category: 'CRM' as const, deps: ['PostgreSQL', 'Cache Layer'] },
  { name: 'Authentication Service', category: 'Authentication' as const, deps: ['LDAP', 'Token Service'] },
  { name: 'Branch Portal', category: 'Branch Portal' as const, deps: ['CRM', 'Core Banking', 'Auth Service'] },
  { name: 'Payment Gateway', category: 'Payments' as const, deps: ['Core Banking', 'HSM Module', 'Network'] },
]

export const applications: AppRecord[] = branches.flatMap((b) =>
  appTemplates.map((tmpl, i) => {
    const seed = b.id.charCodeAt(3) + b.id.charCodeAt(4) + i
    const avail = b.health < 82 ? 92 + (seed % 4) : b.health < 88 ? 97 + (seed % 2) : 99.5
    const lat = 40 + (seed % 80)
    const err = b.health < 82 ? 1.2 + (seed % 20) / 10 : 0.1 + (seed % 5) / 10
    const status: AppRecord['status'] = avail < 95 ? 'Critical' : avail < 98 ? 'Warning' : 'Healthy'
    return { branchId: b.id, branch: b.branch, name: tmpl.name, category: tmpl.category, availability: avail, latency: lat, errorRate: err, dependencies: tmpl.deps, status }
  })
)

// === IVR Analytics (per PRD Module - IVR Analytics) ===
export const ivrFlows = [
  { name: 'Balance Inquiry', calls: 18420, containment: 94, avgDuration: '0:42', abandonment: 2.1 },
  { name: 'Card Activation', calls: 6210, containment: 71, avgDuration: '2:15', abandonment: 8.4 },
  { name: 'Lost/Stolen Card', calls: 3140, containment: 48, avgDuration: '3:48', abandonment: 12.7 },
  { name: 'Account Transfer', calls: 9280, containment: 82, avgDuration: '1:34', abandonment: 5.2 },
  { name: 'Loan Inquiry', calls: 4520, containment: 65, avgDuration: '2:52', abandonment: 9.8 },
  { name: 'Branch Hours & Location', calls: 12100, containment: 96, avgDuration: '0:28', abandonment: 1.5 },
  { name: 'Live Agent Request', calls: 7820, containment: 12, avgDuration: '4:12', abandonment: 15.3 },
]

export const ivrHourlyVolume = [
  { hour: '6 AM', calls: 320, transfers: 80 },
  { hour: '7 AM', calls: 680, transfers: 170 },
  { hour: '8 AM', calls: 1240, transfers: 310 },
  { hour: '9 AM', calls: 2180, transfers: 545 },
  { hour: '10 AM', calls: 2940, transfers: 735 },
  { hour: '11 AM', calls: 3520, transfers: 880 },
  { hour: '12 PM', calls: 4180, transfers: 1254 },
  { hour: '1 PM', calls: 3920, transfers: 1176 },
  { hour: '2 PM', calls: 3210, transfers: 803 },
  { hour: '3 PM', calls: 2840, transfers: 710 },
  { hour: '4 PM', calls: 2260, transfers: 565 },
  { hour: '5 PM', calls: 1680, transfers: 420 },
  { hour: '6 PM', calls: 980, transfers: 245 },
  { hour: '7 PM', calls: 540, transfers: 135 },
]

export const voiceQualityMetrics = {
  avgMosScore: 4.1,
  jitterAvg: 8.2,
  jitterPeak: 24.5,
  packetLossAvg: 0.4,
  latencyAvg: 42,
  callsMonitored: 18420,
  poorQualityCalls: 412,
}

// === Incident Management (per PRD Module 5) ===
export interface IncidentRecord {
  id: string
  branchId: string
  branch: string
  title: string
  category: 'Infrastructure' | 'Application' | 'Device' | 'Building' | 'Customer Impact'
  severity: 'Critical' | 'High' | 'Medium' | 'Low'
  status: 'Open' | 'In Progress' | 'Escalated' | 'Resolved'
  assignedTo: string
  createdAt: string
  slaBreached: boolean
  mttd: number
  mttr: number | null
  impact: string
}

export const incidents: IncidentRecord[] = [
  { id: 'INC-2026-001', branchId: 'BR-305', branch: 'Kolkata - Park Street', title: 'SIP trunk down — IVR unavailable', category: 'Infrastructure', severity: 'Critical', status: 'Escalated', assignedTo: 'NOC Tier 2', createdAt: '10:35 AM', slaBreached: true, mttd: 3, mttr: null, impact: '1,200 customers unable to use IVR self-service' },
  { id: 'INC-2026-002', branchId: 'BR-107', branch: 'Miami - Brickell', title: 'ATM #3 cash dispenser offline', category: 'Device', severity: 'High', status: 'In Progress', assignedTo: 'Field Eng. Team', createdAt: '11:02 AM', slaBreached: false, mttd: 5, mttr: null, impact: 'ATM queue rerouted to 2 remaining units' },
  { id: 'INC-2026-003', branchId: 'BR-104', branch: 'Houston - Galleria', title: 'WAN latency exceeding 45ms', category: 'Infrastructure', severity: 'Medium', status: 'Open', assignedTo: 'Unassigned', createdAt: '09:15 AM', slaBreached: false, mttd: 12, mttr: null, impact: 'Teller transactions delayed 3-5 sec' },
  { id: 'INC-2026-004', branchId: 'BR-401', branch: 'London - City', title: 'SSL certificate expiring in 7 days', category: 'Application', severity: 'Low', status: 'Open', assignedTo: 'App Support', createdAt: '08:00 AM', slaBreached: false, mttd: 1, mttr: null, impact: 'No current impact — preventive action' },
  { id: 'INC-2026-005', branchId: 'BR-103', branch: 'Chicago - Loop', title: 'Queue wait time exceeding 5 minutes', category: 'Customer Impact', severity: 'Medium', status: 'In Progress', assignedTo: 'Branch Manager', createdAt: '11:30 AM', slaBreached: false, mttd: 8, mttr: null, impact: 'Customer satisfaction trending down' },
  { id: 'INC-2026-006', branchId: 'BR-305', branch: 'Kolkata - Park Street', title: 'Backup circuit at 92% utilization', category: 'Infrastructure', severity: 'High', status: 'Open', assignedTo: 'NOC Tier 1', createdAt: '10:48 AM', slaBreached: false, mttd: 2, mttr: null, impact: 'Risk of complete network failure if primary not restored' },
  { id: 'INC-2026-007', branchId: 'BR-204', branch: 'Guangzhou - Tianhe', title: 'CRM sync failure — customer data stale', category: 'Application', severity: 'Medium', status: 'In Progress', assignedTo: 'App Support', createdAt: 'Yesterday', slaBreached: false, mttd: 22, mttr: null, impact: 'Tellers seeing outdated customer profiles' },
  { id: 'INC-2026-008', branchId: 'BR-302', branch: 'Delhi - Connaught', title: 'Camera #2 offline — security blind spot', category: 'Device', severity: 'Low', status: 'Open', assignedTo: 'Security Team', createdAt: 'Yesterday', slaBreached: false, mttd: 18, mttr: null, impact: 'Entrance camera offline, no recording' },
  { id: 'INC-2026-009', branchId: 'BR-101', branch: 'New York - Midtown', title: 'Resolved — Teller app slow response', category: 'Application', severity: 'Medium', status: 'Resolved', assignedTo: 'App Support', createdAt: '2 days ago', slaBreached: false, mttd: 6, mttr: 42, impact: 'Resolved by clearing cache and restarting service' },
  { id: 'INC-2026-010', branchId: 'BR-402', branch: 'Manchester - Spinningfields', title: 'Resolved — UPS battery failure', category: 'Building', severity: 'High', status: 'Resolved', assignedTo: 'Facilities', createdAt: '3 days ago', slaBreached: true, mttd: 4, mttr: 180, impact: 'Battery replaced, power backup restored' },
]

export const incidentMetrics = {
  openIncidents: incidents.filter((i) => i.status !== 'Resolved').length,
  criticalIncidents: incidents.filter((i) => i.severity === 'Critical').length,
  slaBreaches: incidents.filter((i) => i.slaBreached).length,
  avgMttd: Math.round(incidents.reduce((s, i) => s + i.mttd, 0) / incidents.length * 10) / 10,
  avgMttr: Math.round(incidents.filter((i) => i.mttr).reduce((s, i) => s + (i.mttr || 0), 0) / incidents.filter((i) => i.mttr).length * 10) / 10,
  avgIncidentAge: 6.4,
}

// Incident timeline (for a single incident)
export const incidentTimeline = [
  { time: '10:35 AM', event: 'Alert generated — SIP trunk unreachable', actor: 'Monitoring System', type: 'alert' },
  { time: '10:36 AM', event: 'Incident INC-2026-001 created', actor: 'NOC Tier 1', type: 'created' },
  { time: '10:42 AM', event: 'Severity escalated to Critical', actor: 'NOC Tier 2', type: 'escalation' },
  { time: '10:48 AM', event: 'Field engineer dispatched to branch', actor: 'NOC Tier 2', type: 'assignment' },
  { time: '10:55 AM', event: 'Branch manager notified via mobile alert', actor: 'System', type: 'notification' },
  { time: '11:10 AM', event: 'Failover to backup ISP initiated', actor: 'NOC Tier 2', type: 'action' },
  { time: '11:18 AM', event: 'Backup circuit at 92% — monitoring closely', actor: 'NOC Tier 1', type: 'update' },
  { time: '11:25 AM', event: 'Awaiting primary circuit repair', actor: 'Field Eng. Team', type: 'update' },
]

// === Employee Directory (per PRD Module - Employee Information) ===
export interface EmployeeRecord {
  id: string
  branchId: string
  branch: string
  name: string
  role: string
  department: string
  email: string
  phone: string
  certifications: string[]
  manager: string
  status: 'Active' | 'On Leave' | 'Remote'
  utilization: number
}

const firstNames = ['James', 'Sarah', 'Michael', 'Emily', 'David', 'Jessica', 'Robert', 'Lisa', 'Daniel', 'Anna', 'Kevin', 'Maria', 'Brian', 'Linda', 'Carlos', 'Priya', 'Wei', 'Yuki', 'Omar', 'Sophie']
const lastNames = ['Smith', 'Johnson', 'Lee', 'Patel', 'Garcia', 'Kim', 'Brown', 'Davis', 'Miller', 'Wilson', 'Tanaka', 'Khan', 'Müller', 'Rossi', 'Silva', 'Andersson', 'Chen', 'Singh', 'Costa', 'Novak']
const roles = [
  { role: 'Branch Manager', dept: 'Management', certs: ['PMP', 'Six Sigma Black Belt'] },
  { role: 'Assistant Branch Manager', dept: 'Management', certs: ['PMP'] },
  { role: 'Senior Teller', dept: 'Operations', certs: ['AML Certification'] },
  { role: 'Teller', dept: 'Operations', certs: [] },
  { role: 'Customer Service Rep', dept: 'Customer Service', certs: ['Customer Experience Cert'] },
  { role: 'Loan Officer', dept: 'Lending', certs: ['NMLS License'] },
  { role: 'Financial Advisor', dept: 'Wealth Management', certs: ['CFP', 'Series 7'] },
  { role: 'Operations Manager', dept: 'Operations', certs: ['Six Sigma Green Belt'] },
]

export const employees: EmployeeRecord[] = branches.flatMap((b, bi) => {
  const count = Math.min(8, Math.max(4, Math.floor(b.employees / 6)))
  return Array.from({ length: count }, (_, i) => {
    const seed = bi * 10 + i
    const fn = firstNames[seed % firstNames.length]
    const ln = lastNames[(seed * 3) % lastNames.length]
    const r = roles[i % roles.length]
    const status: EmployeeRecord['status'] = i === 0 ? 'Active' : (seed % 7 === 0 ? 'On Leave' : seed % 4 === 0 ? 'Remote' : 'Active')
    return {
      id: `EMP-${b.id}-${i + 1}`,
      branchId: b.id,
      branch: b.branch,
      name: `${fn} ${ln}`,
      role: r.role,
      department: r.dept,
      email: `${fn.toLowerCase()}.${ln.toLowerCase()}@enterprise.com`,
      phone: `+1-555-${1000 + seed}`,
      certifications: r.certs,
      manager: b.manager,
      status,
      utilization: 60 + (seed % 35),
    }
  })
})

// === Inventory (per PRD Module - Inventory) ===
export interface InventoryRecord {
  id: string
  branchId: string
  branch: string
  name: string
  category: 'Hardware' | 'Software' | 'Network Equipment' | 'Furniture' | 'Security'
  vendor: string
  serialNumber: string
  purchaseDate: string
  warrantyExpiry: string
  lifecycle: 'Active' | 'Aging' | 'End of Life' | 'Replacement Due'
  cost: number
}

const inventoryItems = [
  { name: 'Dell PowerEdge R650 Server', category: 'Hardware' as const, vendor: 'Dell', cost: 8500 },
  { name: 'NCR SelfServ 6622 ATM', category: 'Hardware' as const, vendor: 'NCR', cost: 28000 },
  { name: 'Cisco Catalyst 9300 Switch', category: 'Network Equipment' as const, vendor: 'Cisco', cost: 4200 },
  { name: 'Aruba AP-535 WiFi AP', category: 'Network Equipment' as const, vendor: 'Aruba', cost: 1200 },
  { name: 'Microsoft Office 365 License', category: 'Software' as const, vendor: 'Microsoft', cost: 240 },
  { name: 'Symantec Endpoint Security', category: 'Software' as const, vendor: 'Broadcom', cost: 85 },
  { name: 'Teller Counter Workstation', category: 'Furniture' as const, vendor: 'Steelcase', cost: 3200 },
  { name: 'Axis Q3517 Security Camera', category: 'Security' as const, vendor: 'Axis', cost: 950 },
  { name: 'APC Smart-UPS 1500VA', category: 'Hardware' as const, vendor: 'APC', cost: 780 },
  { name: 'Verifone MX925 POS Terminal', category: 'Hardware' as const, vendor: 'Verifone', cost: 650 },
]

export const inventory: InventoryRecord[] = branches.flatMap((b, bi) =>
  inventoryItems.map((item, i) => {
    const seed = bi * 10 + i
    const ageYears = (seed % 6)
    const lifecycle: InventoryRecord['lifecycle'] = ageYears >= 5 ? 'End of Life' : ageYears >= 4 ? 'Replacement Due' : ageYears >= 3 ? 'Aging' : 'Active'
    const purchaseYear = 2026 - ageYears
    return {
      id: `INV-${b.id}-${i + 1}`,
      branchId: b.id,
      branch: b.branch,
      name: item.name,
      category: item.category,
      vendor: item.vendor,
      serialNumber: `${item.vendor.slice(0, 3).toUpperCase()}-${b.id}-${1000 + seed}`,
      purchaseDate: `${purchaseYear}-03-15`,
      warrantyExpiry: `${purchaseYear + 3}-03-15`,
      lifecycle,
      cost: item.cost,
    }
  })
)

// === Events Timeline (per PRD Module - Branch Events) ===
export interface EventRecord {
  id: string
  branchId: string
  branch: string
  type: 'Incident' | 'Alert' | 'Maintenance' | 'Deployment' | 'Audit'
  title: string
  description: string
  timestamp: string
  severity: 'Critical' | 'High' | 'Medium' | 'Low' | 'Info'
}

export const events: EventRecord[] = [
  { id: 'EVT-001', branchId: 'BR-305', branch: 'Kolkata - Park Street', type: 'Incident', title: 'SIP trunk down', description: 'Primary SIP trunk became unreachable, IVR self-service unavailable.', timestamp: 'Today 10:35 AM', severity: 'Critical' },
  { id: 'EVT-002', branchId: 'BR-305', branch: 'Kolkata - Park Street', type: 'Alert', title: 'Backup circuit at 92%', description: 'Failover circuit approaching capacity limit.', timestamp: 'Today 10:48 AM', severity: 'High' },
  { id: 'EVT-003', branchId: 'BR-107', branch: 'Miami - Brickell', type: 'Incident', title: 'ATM #3 offline', description: 'Cash dispenser hardware fault detected, ATM marked offline.', timestamp: 'Today 11:02 AM', severity: 'High' },
  { id: 'EVT-004', branchId: 'BR-104', branch: 'Houston - Galleria', type: 'Alert', title: 'WAN latency spike', description: 'WAN latency exceeded 45ms threshold for 15 minutes.', timestamp: 'Today 09:15 AM', severity: 'Medium' },
  { id: 'EVT-005', branchId: 'BR-401', branch: 'London - City', type: 'Alert', title: 'Certificate expiring', description: 'SSL certificate for auth service expires in 7 days.', timestamp: 'Today 08:00 AM', severity: 'Low' },
  { id: 'EVT-006', branchId: 'BR-101', branch: 'New York - Midtown', type: 'Deployment', title: 'Teller app v4.2 deployed', description: 'Scheduled deployment of teller application update v4.2.0.', timestamp: 'Yesterday 02:00 AM', severity: 'Info' },
  { id: 'EVT-007', branchId: 'BR-303', branch: 'Bengaluru - MG Road', type: 'Maintenance', title: 'UPS battery replacement', description: 'Scheduled UPS battery replacement completed successfully.', timestamp: 'Yesterday 06:00 AM', severity: 'Info' },
  { id: 'EVT-008', branchId: 'BR-103', branch: 'Chicago - Loop', type: 'Alert', title: 'Queue wait time high', description: 'Customer queue wait time exceeded 5 minute threshold.', timestamp: 'Today 11:30 AM', severity: 'Medium' },
  { id: 'EVT-009', branchId: 'BR-204', branch: 'Guangzhou - Tianhe', type: 'Incident', title: 'CRM sync failure', description: 'CRM platform sync with core banking failed, customer data stale.', timestamp: 'Yesterday 14:20', severity: 'Medium' },
  { id: 'EVT-010', branchId: 'BR-302', branch: 'Delhi - Connaught', type: 'Alert', title: 'Camera offline', description: 'Security camera #2 at entrance stopped responding.', timestamp: 'Yesterday 16:45', severity: 'Low' },
  { id: 'EVT-011', branchId: 'BR-201', branch: 'Shanghai - Lujiazui', type: 'Audit', title: 'Compliance audit completed', description: 'Quarterly compliance audit passed with no findings.', timestamp: '2 days ago', severity: 'Info' },
  { id: 'EVT-012', branchId: 'BR-402', branch: 'Manchester - Spinningfields', type: 'Incident', title: 'UPS battery failure (resolved)', description: 'UPS battery failed, power backup restored after 3 hours.', timestamp: '3 days ago', severity: 'High' },
]

// === Region Performance (per PRD - Regional Director persona) ===
export const regionPerformance = [
  { region: 'Northeast', branches: 2, avgHealth: 92, avgSla: 98, incidents: 3, customers: 2940, utilisation: 82 },
  { region: 'West', branches: 4, avgHealth: 90, avgSla: 97, incidents: 4, customers: 4290, utilisation: 80 },
  { region: 'Midwest', branches: 1, avgHealth: 89, avgSla: 96, incidents: 1, customers: 1180, utilisation: 78 },
  { region: 'South', branches: 1, avgHealth: 85, avgSla: 94, incidents: 2, customers: 920, utilisation: 75 },
  { region: 'Southeast', branches: 2, avgHealth: 85, avgSla: 93, incidents: 3, customers: 1760, utilisation: 74 },
  { region: 'East (China)', branches: 1, avgHealth: 92, avgSla: 98, incidents: 2, customers: 1620, utilisation: 83 },
  { region: 'North (China)', branches: 1, avgHealth: 90, avgSla: 97, incidents: 1, customers: 1380, utilisation: 81 },
  { region: 'South (China)', branches: 2, avgHealth: 86, avgSla: 94, incidents: 3, customers: 2020, utilisation: 77 },
  { region: 'West (India)', branches: 1, avgHealth: 92, avgSla: 98, incidents: 1, customers: 1240, utilisation: 81 },
  { region: 'North (India)', branches: 1, avgHealth: 88, avgSla: 95, incidents: 2, customers: 980, utilisation: 77 },
  { region: 'South (India)', branches: 2, avgHealth: 90, avgSla: 96, incidents: 3, customers: 2280, utilisation: 79 },
  { region: 'East (India)', branches: 1, avgHealth: 79, avgSla: 89, incidents: 4, customers: 640, utilisation: 69 },
  { region: 'Greater London', branches: 1, avgHealth: 91, avgSla: 97, incidents: 1, customers: 1280, utilisation: 80 },
  { region: 'North West (UK)', branches: 1, avgHealth: 85, avgSla: 94, incidents: 1, customers: 820, utilisation: 75 },
  { region: 'Central (SG)', branches: 1, avgHealth: 93, avgSla: 99, incidents: 1, customers: 1320, utilisation: 82 },
  { region: 'Hesse (DE)', branches: 1, avgHealth: 89, avgSla: 96, incidents: 1, customers: 980, utilisation: 78 },
  { region: 'Kanto (JP)', branches: 1, avgHealth: 90, avgSla: 97, incidents: 1, customers: 1480, utilisation: 81 },
  { region: 'Dubai (AE)', branches: 1, avgHealth: 87, avgSla: 95, incidents: 1, customers: 1060, utilisation: 76 },
  { region: 'NSW (AU)', branches: 1, avgHealth: 88, avgSla: 96, incidents: 1, customers: 1020, utilisation: 77 },
]
