export interface ProductMeta {
  id: string
  name: string
  short: string
  icon: string
  color: string
  description: string
  active?: boolean
}

export const products: ProductMeta[] = [
  { id: 'kyb', name: 'Know Your Branch', short: 'KYB', icon: 'Building2', color: '#2563eb', description: 'Branch operations & health', active: true },
  { id: 'kyc', name: 'Know Your Customer', short: 'KYC', icon: 'UserCheck', color: '#0ea5e9', description: 'Customer onboarding & risk' },
  { id: 'kya', name: 'Know Your Account', short: 'KYA', icon: 'Wallet', color: '#10b981', description: 'Account behaviour & fraud' },
  { id: 'kyt', name: 'Know Your Transaction', short: 'KYT', icon: 'ArrowLeftRight', color: '#f59e0b', description: 'Real-time payment monitoring' },
  { id: 'kym', name: 'Know Your Merchant', short: 'KYM', icon: 'Store', color: '#8b5cf6', description: 'Merchant risk & compliance' },
  { id: 'kyp', name: 'Know Your Partner', short: 'KYP', icon: 'Handshake', color: '#ec4899', description: 'Third-party & vendor risk' },
  { id: 'kye', name: 'Know Your Employee', short: 'KYE', icon: 'BadgeCheck', color: '#14b8a6', description: 'Workforce & insider risk' },
  { id: 'kyv', name: 'Know Your Vendor', short: 'KYV', icon: 'Truck', color: '#6366f1', description: 'Supply chain visibility' },
  { id: 'kys', name: 'Know Your Supplier', short: 'KYS', icon: 'PackageCheck', color: '#f43f5e', description: 'Procurement & ESG risk' },
]
