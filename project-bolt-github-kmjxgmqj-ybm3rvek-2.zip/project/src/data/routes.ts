export interface RouteMeta {
  path?: string
  title: string
  subtitle: string
}

export const routeMeta: Record<string, RouteMeta> = {
  '/': { title: 'Home', subtitle: 'Enterprise branch operations dashboard' },
  '/branch-search': { title: 'Search Branches', subtitle: 'Find and discover branches worldwide' },
  '/branch-map': { title: 'Geospatial Map', subtitle: 'Drill from world to individual branch' },
  '/branch/:branchId': { title: 'Branch Detail', subtitle: 'Complete operational view of a single branch' },
  '/product/:productId': { title: 'Enterprise Suite', subtitle: 'Product overview' },
  '/performance': { title: 'Branch Performance', subtitle: 'SLA, CSAT & operational KPIs' },
  '/ivr-analytics': { title: 'IVR Analytics', subtitle: 'Interactive Voice Response performance' },
  '/reports': { title: 'Reports', subtitle: 'Scheduled & on-demand reporting' },
  '/branch-health': { title: 'Branch Health', subtitle: 'Composite health across all branches' },
  '/network-health': { title: 'Network Health', subtitle: 'LAN, WAN & SIP trunk monitoring' },
  '/device-health': { title: 'Device Health', subtitle: 'ATMs, cash recyclers, servers & endpoints' },
  '/application-health': { title: 'Application Health', subtitle: 'Core banking & branch apps uptime' },
  '/tickets': { title: 'Tickets', subtitle: 'Incident & request management' },
  '/inventory': { title: 'Branch Inventory', subtitle: 'Hardware & asset register' },
  '/events': { title: 'Branch Events', subtitle: 'Incidents & alerts timeline' },
  '/employees': { title: 'Branch Personas', subtitle: 'Headcount & utilisation' },
  '/assistant': { title: 'AI Assistant', subtitle: 'Conversational branch intelligence' },
  '/feedback': { title: 'Submit Feedback', subtitle: 'Help us improve' },
  '/tour': { title: 'Branch Virtual Tour', subtitle: 'Explore branches virtually' },
}
