import type { ReactNode } from 'react'

export function Card({ children, title, subtitle, className }: { children: ReactNode; title?: string; subtitle?: string; className?: string }) {
  return (
    <div className={`card ${className || ''}`}>
      {title && (
        <div className="mb-4">
          <div className="card-title">{title}</div>
          {subtitle && <div className="card-subtitle">{subtitle}</div>}
        </div>
      )}
      {children}
    </div>
  )
}

export function Badge({ children, tone = 'neutral' }: { children: ReactNode; tone?: 'green' | 'amber' | 'red' | 'blue' | 'neutral' }) {
  return <span className={`badge badge-${tone}`}>{children}</span>
}

export function HealthDot({ value }: { value: number }) {
  const color = value >= 90 ? '#10b981' : value >= 80 ? '#f59e0b' : '#ef4444'
  return <span className="inline-flex rounded-full" style={{ width: 10, height: 10, background: color, flexShrink: 0 }} />
}

export function ProgressBar({ value, tone = 'blue', color, max = 100 }: { value: number; tone?: 'blue' | 'green' | 'amber' | 'red'; color?: string; max?: number }) {
  const colors: Record<string, string> = { blue: '#3b82f6', green: '#10b981', amber: '#f59e0b', red: '#ef4444' }
  const pct = Math.min(100, (value / max) * 100)
  return (
    <div className="progress-bar">
      <div className="progress-bar-fill" style={{ width: `${pct}%`, background: color || colors[tone] }} />
    </div>
  )
}

export function KPI({ icon, label, value, delta, trend, hint, tone }: {
  icon: ReactNode; label: string; value: string; delta?: string; trend?: 'up' | 'down'; hint?: string; tone?: 'blue' | 'green' | 'amber' | 'red'
}) {
  const toneColors = { blue: '#3b82f6', green: '#10b981', amber: '#f59e0b', red: '#ef4444' }
  const iconColor = tone ? toneColors[tone] : 'var(--ink-400)'
  return (
    <div className="card" style={{ padding: 16 }}>
      <div className="flex items-center justify-between mb-2">
        <div style={{ color: iconColor }}>{icon}</div>
        {delta && (
          <span className="text-xs font-semibold" style={{ color: trend === 'up' ? 'var(--emerald-600)' : 'var(--red-600)' }}>
            {trend === 'up' ? '↑' : '↓'} {delta}
          </span>
        )}
      </div>
      <div className="text-2xl font-bold text-ink-900">{value}</div>
      <div className="text-xs text-ink-400">{label}</div>
      {hint && <div className="text-xs text-ink-400 mt-2" style={{ opacity: 0.7 }}>{hint}</div>}
    </div>
  )
}

export function Sparkline({ data, color = '#3b82f6', width = 120, height = 32 }: { data: number[]; color?: string; width?: number; height?: number }) {
  if (data.length === 0) return null
  const min = Math.min(...data)
  const max = Math.max(...data)
  const range = max - min || 1
  const step = width / (data.length - 1)
  const points = data.map((d, i) => `${i * step},${height - ((d - min) / range) * height}`).join(' ')
  const areaPoints = `0,${height} ${points} ${width},${height}`
  return (
    <svg width={width} height={height} style={{ display: 'block' }}>
      <polyline points={areaPoints} fill={color} fillOpacity={0.08} stroke="none" />
      <polyline points={points} fill="none" stroke={color} strokeWidth={1.5} strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  )
}

export function TrendArrow({ value }: { value: 'up' | 'down' | 'flat' }) {
  const color = value === 'up' ? 'var(--emerald-600)' : value === 'down' ? 'var(--red-600)' : 'var(--ink-400)'
  const arrow = value === 'up' ? '↑' : value === 'down' ? '↓' : '→'
  return <span style={{ color, fontSize: 12, fontWeight: 700 }}>{arrow}</span>
}
