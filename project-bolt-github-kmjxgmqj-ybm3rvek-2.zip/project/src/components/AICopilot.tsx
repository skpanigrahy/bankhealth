import { useState, useRef, useEffect } from 'react'
import { Bot, X, Send, Sparkles } from 'lucide-react'
import { branches, incidents, devices, networkCircuits, aiRecommendations } from '../data/mockData'

interface Message { role: 'user' | 'assistant'; text: string; confidence?: number; sources?: string[] }

const suggestions = [
  'Why is Kolkata health low?',
  'Which branches need attention?',
  'Show critical incidents',
  'Network status summary',
  'Which IVR flows have high abandonment?',
  'Compare regions',
]

function generateResponse(q: string): Message {
  const lower = q.toLowerCase()

  if (lower.includes('kolkata') || (lower.includes('why') && lower.includes('health'))) {
    return {
      role: 'assistant',
      text: `Kolkata - Park Street has a health score of 79 (Critical) due to a primary WAN circuit failure at 10:35 AM. This caused the SIP trunk to go down, making IVR self-service unavailable. Calls were rerouted to the backup queue, increasing wait times to 6.8 minutes. The backup circuit is now at 92% utilization.\n\nRecommended action: Fail over to backup ISP circuit (94% confidence). A field engineer has been dispatched.`,
      confidence: 94,
      sources: ['INC-2026-001', 'Root Cause Analysis', 'AI Recommendations'],
    }
  }
  if (lower.includes('attention') || lower.includes('which branch') || lower.includes('needs')) {
    const critical = branches.filter((b) => b.health < 85).sort((a, b) => a.health - b.health)
    return {
      role: 'assistant',
      text: `${critical.length} branches require immediate attention:\n\n${critical.slice(0, 5).map((b) => `• ${b.branch} — Health: ${b.health}, ${b.openTickets} tickets, ${b.devicesOffline} devices offline`).join('\n')}\n\nKolkata is the most critical with an active SIP trunk outage.`,
      confidence: 96,
      sources: ['Branch Health', 'Incident Management'],
    }
  }
  if (lower.includes('critical') && (lower.includes('incident') || lower.includes('ticket'))) {
    const crit = incidents.filter((i) => i.severity === 'Critical' && i.status !== 'Resolved')
    return {
      role: 'assistant',
      text: `There ${crit.length === 1 ? 'is' : 'are'} ${crit.length} critical incident${crit.length > 1 ? 's' : ''}:\n\n${crit.map((i) => `• ${i.id}: ${i.title}\n  Branch: ${i.branch}\n  Status: ${i.status}, Assigned: ${i.assignedTo}\n  Impact: ${i.impact}`).join('\n\n')}`,
      confidence: 100,
      sources: ['Incident Management'],
    }
  }
  if (lower.includes('network') || lower.includes('wan') || lower.includes('latency')) {
    const degraded = networkCircuits.filter((c) => c.status !== 'Healthy')
    const avgLat = Math.round(networkCircuits.filter((c) => c.type === 'WAN').reduce((s, c) => s + c.latency, 0) / 27)
    return {
      role: 'assistant',
      text: `Network Status Summary:\n\n• Average WAN latency: ${avgLat}ms\n• ${degraded.length} degraded circuits across ${new Set(degraded.map((c) => c.branch)).size} branches\n• Most affected: Kolkata (SIP trunk critical), Houston (WAN latency 47ms), Guangzhou (SIP degraded)\n\nOverall network availability: 99.1% (down 0.2% from last week).`,
      confidence: 92,
      sources: ['Network Health', 'Circuit Monitoring'],
    }
  }
  if (lower.includes('ivr') || lower.includes('abandon') || lower.includes('call')) {
    return {
      role: 'assistant',
      text: `IVR Analytics Summary:\n\n• Total calls (30d): 61.5K\n• Average containment: 75% (up 3%)\n• Average abandonment: 7.9%\n\nHighest abandonment flows:\n• Live Agent Request: 15.3% abandonment\n• Lost/Stolen Card: 12.7% abandonment\n• Loan Inquiry: 9.8% abandonment\n\nPeak hour: 12 PM with 4,180 calls. Recommend adding self-service options for Lost/Stolen Card flow.`,
      confidence: 91,
      sources: ['IVR Analytics', 'Voice Quality Metrics'],
    }
  }
  if (lower.includes('region') || lower.includes('compare')) {
    const regions = [...new Set(branches.map((b) => b.region))].map((r) => {
      const rb = branches.filter((b) => b.region === r)
      return { region: r, avg: Math.round(rb.reduce((s, b) => s + b.health, 0) / rb.length), count: rb.length }
    }).sort((a, b) => a.avg - b.avg)
    return {
      role: 'assistant',
      text: `Regional Health Comparison:\n\n${regions.map((r) => `• ${r.region}: ${r.avg} avg health (${r.count} branches)`).join('\n')}\n\nLowest performing: East (India) at 79 — driven by Kolkata outage.\nHighest performing: South (India) at 95 — led by Bengaluru MG Road.`,
      confidence: 95,
      sources: ['Regional Performance', 'Branch Health'],
    }
  }
  if (lower.includes('device') || lower.includes('offline')) {
    const off = devices.filter((d) => d.status === 'Offline')
    return {
      role: 'assistant',
      text: `Device Status:\n\n• ${off.length} devices offline across all branches\n• ${devices.filter((d) => d.status === 'Degraded').length} devices degraded\n• Total devices monitored: ${devices.length}\n\nOffline devices:\n${off.map((d) => `• ${d.branch} — ${d.type} (${d.model})`).join('\n')}\n\nRecommend dispatching field engineers for ATM and camera repairs.`,
      confidence: 93,
      sources: ['Device Health', 'Asset Inventory'],
    }
  }
  if (lower.includes('recommend') || lower.includes('action') || lower.includes('should')) {
    return {
      role: 'assistant',
      text: `AI Recommendations (${aiRecommendations.length} active):\n\n${aiRecommendations.slice(0, 4).map((r) => `• [${r.priority.toUpperCase()}] ${r.action}\n  Branch: ${branches.find((b) => b.id === r.branchId)?.branch}\n  Confidence: ${r.confidence}%`).join('\n\n')}\n\nThe most urgent action is failing over Kolkata's backup ISP circuit.`,
      confidence: 90,
      sources: ['AI Recommendations', 'Root Cause Analysis'],
    }
  }
  return {
    role: 'assistant',
    text: `I can help you with:\n\n• Branch health analysis and root cause\n• Incident investigation and timelines\n• Network and device status\n• IVR performance and call flows\n• Regional comparisons\n• AI-generated recommendations\n\nTry asking: "Why is Kolkata health low?" or "Which branches need attention?"`,
    confidence: 88,
  }
}

export default function AICopilot() {
  const [open, setOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', text: 'Hello! I am your Branch Operations AI Copilot. I can explain dashboards, summarize incidents, compare branches, and recommend actions. Ask me anything about your branch network.', confidence: 99 },
  ])
  const [input, setInput] = useState('')
  const messagesRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (messagesRef.current) {
      messagesRef.current.scrollTop = messagesRef.current.scrollHeight
    }
  }, [messages])

  const send = (text?: string) => {
    const query = text || input
    if (!query.trim()) return
    const response = generateResponse(query)
    setMessages((prev) => [...prev, { role: 'user', text: query }, response])
    setInput('')
  }

  return (
    <>
      <button className="copilot-toggle" onClick={() => setOpen(!open)} aria-label="AI Copilot">
        {open ? <X style={{ width: 22, height: 22 }} /> : <Bot style={{ width: 22, height: 22 }} />}
      </button>
      {open && (
        <div className="copilot-panel">
          <div className="copilot-header">
            <div className="copilot-header-icon">
              <Sparkles style={{ width: 18, height: 18 }} />
            </div>
            <div className="copilot-header-text">
              <span className="copilot-header-title">AI Copilot</span>
              <span className="copilot-header-sub">Branch Operations Intelligence</span>
            </div>
            <button className="copilot-close" onClick={() => setOpen(false)}>
              <X style={{ width: 16, height: 16 }} />
            </button>
          </div>
          <div className="copilot-messages" ref={messagesRef}>
            {messages.map((m, i) => (
              <div key={i} className={`copilot-msg copilot-msg-${m.role === 'user' ? 'user' : 'ai'}`}>
                <div style={{ whiteSpace: 'pre-wrap' }}>{m.text}</div>
                {m.confidence && (
                  <div className="copilot-confidence">
                    <Sparkles style={{ width: 10, height: 10 }} />
                    Confidence: {m.confidence}%
                    {m.sources && m.sources.length > 0 && ` · Sources: ${m.sources.join(', ')}`}
                  </div>
                )}
              </div>
            ))}
          </div>
          <div className="copilot-suggestions">
            {suggestions.map((s) => (
              <button key={s} className="copilot-suggestion" onClick={() => send(s)}>{s}</button>
            ))}
          </div>
          <div className="copilot-input-row">
            <input
              className="copilot-input"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && send()}
              placeholder="Ask about branches, incidents, health…"
            />
            <button className="copilot-send" onClick={() => send()}>
              <Send style={{ width: 16, height: 16 }} />
            </button>
          </div>
        </div>
      )}
    </>
  )
}
