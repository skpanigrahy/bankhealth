import { useState, useRef, useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import * as Icons from 'lucide-react'
import { alerts } from '../data/mockData'
import { products } from '../data/projects'
import { routeMeta } from '../data/routes'

export default function Topbar() {
  const location = useLocation()
  const navigate = useNavigate()
  const meta = routeMeta[location.pathname] || { title: 'Know Your Branch', subtitle: 'Enterprise operations' }
  const productMatch = location.pathname.match(/^\/product\/(\w+)/)
  const [activeId, setActiveId] = useState(productMatch ? productMatch[1] : 'kyb')
  const active = products.find((p) => p.id === activeId) || products[0]
  const criticalCount = alerts.filter((a) => a.severity === 'critical').length

  const [switcherOpen, setSwitcherOpen] = useState(false)
  const [notifOpen, setNotifOpen] = useState(false)
  const [profileOpen, setProfileOpen] = useState(false)
  const switcherRef = useRef<HTMLDivElement>(null)
  const notifRef = useRef<HTMLDivElement>(null)
  const profileRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (switcherRef.current && !switcherRef.current.contains(e.target as Node)) setSwitcherOpen(false)
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) setNotifOpen(false)
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) setProfileOpen(false)
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  const ActiveIcon = (Icons as any)[active.icon] as Icons.LucideIcon

  return (
    <header className="topbar">
      {/* Brand umbrella + product switcher */}
      <div className="brand-umbrella" ref={switcherRef}>
        <div className="brand-mark">
          <span className="brand-mark-letter">K</span>
        </div>
        <button
          className={`product-switcher ${switcherOpen ? 'is-open' : ''}`}
          onClick={() => setSwitcherOpen((v) => !v)}
          aria-haspopup="true"
          aria-expanded={switcherOpen}
        >
          <span className="product-switcher-icon" style={{ background: `${active.color}1a`, color: active.color }}>
            <ActiveIcon style={{ width: 16, height: 16 }} />
          </span>
          <span className="product-switcher-text">
            <span className="product-switcher-name">{active.name}</span>
            <span className="product-switcher-sub">Enterprise Suite</span>
          </span>
          <Icons.ChevronsUpDown style={{ width: 14, height: 14, color: 'var(--ink-400)' }} />
        </button>

        {switcherOpen && (
          <div className="switcher-menu" role="menu">
            <div className="switcher-menu-head">
              <span>Know Your Suite</span>
              <span className="switcher-menu-count">{products.length} products</span>
            </div>
            <div className="switcher-menu-list">
              {products.map((p) => {
                const Icon = (Icons as any)[p.icon] as Icons.LucideIcon
                const isActive = p.id === activeId
                return (
                  <button
                    key={p.id}
                    className={`switcher-item ${isActive ? 'is-active' : ''}`}
                    role="menuitem"
                    onClick={() => {
                      setActiveId(p.id)
                      setSwitcherOpen(false)
                      if (p.id === 'kyb') {
                        navigate('/')
                      } else {
                        navigate(`/product/${p.id}`)
                      }
                    }}
                  >
                    <span className="switcher-item-icon" style={{ background: `${p.color}1a`, color: p.color }}>
                      <Icon style={{ width: 16, height: 16 }} />
                    </span>
                    <span className="switcher-item-text">
                      <span className="switcher-item-name">{p.name}</span>
                      <span className="switcher-item-desc">{p.description}</span>
                    </span>
                    {isActive && <Icons.Check style={{ width: 14, height: 14, color: 'var(--brand-600)' }} />}
                  </button>
                )
              })}
            </div>
          </div>
        )}
      </div>

      <div className="topbar-divider" />

      {/* Breadcrumb */}
      <nav className="topbar-breadcrumb" aria-label="Breadcrumb">
        <span className="breadcrumb-item">Enterprise</span>
        <Icons.ChevronRight style={{ width: 12, height: 12, color: 'var(--ink-300)' }} />
        <span className="breadcrumb-item breadcrumb-current">{meta.title}</span>
      </nav>

      {/* Dynamic page title */}
      <div className="topbar-title">
        <h1>{meta.title}</h1>
        <p>{meta.subtitle}</p>
      </div>

      <div className="topbar-spacer" />

      {/* Right cluster */}
      <div className="topbar-actions">
        <div className="topbar-search">
          <Icons.Search style={{ width: 15, height: 15, color: 'var(--ink-400)' }} />
          <input placeholder="Search branches, tickets, devices…" />
          <span className="topbar-search-kbd">⌘K</span>
        </div>

        <div className="topbar-icon-btn" ref={notifRef}>
          <button onClick={() => setNotifOpen((v) => !v)} aria-label="Notifications">
            <Icons.Bell style={{ width: 18, height: 18 }} />
            {criticalCount > 0 && <span className="topbar-badge">{criticalCount}</span>}
          </button>
          {notifOpen && (
            <div className="dropdown-panel">
              <div className="dropdown-panel-head">
                <span>Notifications</span>
                <span className="dropdown-panel-count">{alerts.length} new</span>
              </div>
              <div className="dropdown-panel-list">
                {alerts.slice(0, 5).map((a) => (
                  <div key={a.id} className="notif-item">
                    <span className="notif-dot" style={{ background: a.severity === 'critical' ? 'var(--red-500)' : a.severity === 'high' ? 'var(--amber-500)' : 'var(--ink-300)' }} />
                    <div className="notif-body">
                      <div className="notif-title">{a.title}</div>
                      <div className="notif-meta">{a.branch} · {a.time}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="topbar-icon-btn" ref={profileRef}>
          <button className="profile-trigger" onClick={() => setProfileOpen((v) => !v)}>
            <span className="profile-avatar">OP</span>
            <span className="profile-text">
              <span className="profile-name">Ops Admin</span>
              <span className="profile-role">Super User</span>
            </span>
            <Icons.ChevronDown style={{ width: 13, height: 13, color: 'var(--ink-400)' }} />
          </button>
          {profileOpen && (
            <div className="dropdown-panel profile-panel">
              <div className="profile-panel-head">
                <span className="profile-avatar" style={{ width: 40, height: 40, fontSize: 15 }}>OP</span>
                <div>
                  <div className="profile-name">Ops Admin</div>
                  <div className="profile-role">ops.admin@enterprise.com</div>
                </div>
              </div>
              <div className="dropdown-panel-list">
                <button className="profile-menu-item"><Icons.Settings style={{ width: 15, height: 15 }} /> Settings</button>
                <button className="profile-menu-item"><Icons.Bell style={{ width: 15, height: 15 }} /> Notification preferences</button>
                <button className="profile-menu-item"><Icons.LifeBuoy style={{ width: 15, height: 15 }} /> Help & support</button>
                <div className="dropdown-divider" />
                <button className="profile-menu-item danger"><Icons.LogOut style={{ width: 15, height: 15 }} /> Sign out</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  )
}
