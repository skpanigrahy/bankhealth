import { useState } from 'react'
import { NavLink, useLocation } from 'react-router-dom'
import { Chrome as Home, Search, BarChart3, HeartPulse, Package, CalendarClock, Users, Bot, MessageSquare, Map as MapIcon, ChevronRight, Gauge, PhoneCall, Network, Cpu, AppWindow, Ticket, FileBarChart } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'

interface SubItem { to: string; label: string; icon: LucideIcon }
interface NavGroup {
  label: string
  to?: string
  icon: LucideIcon
  subItems?: SubItem[]
}

const navGroups: NavGroup[] = [
  { label: 'Home', to: '/', icon: Home },
  {
    label: 'Search Branches', icon: Search,
    subItems: [
      { to: '/branch-search', label: 'Branch Search', icon: Search },
      { to: '/branch-map', label: 'Geospatial Map', icon: MapIcon },
    ],
  },
  {
    label: 'Branch Analytics', icon: BarChart3,
    subItems: [
      { to: '/performance', label: 'Performance', icon: Gauge },
      { to: '/ivr-analytics', label: 'IVR Analytics', icon: PhoneCall },
      { to: '/reports', label: 'Reports', icon: FileBarChart },
    ],
  },
  {
    label: 'Branch Health', icon: HeartPulse,
    subItems: [
      { to: '/branch-health', label: 'Health Overview', icon: HeartPulse },
      { to: '/network-health', label: 'Network', icon: Network },
      { to: '/device-health', label: 'Devices', icon: Cpu },
      { to: '/application-health', label: 'Applications', icon: AppWindow },
      { to: '/tickets', label: 'Tickets', icon: Ticket },
    ],
  },
  {
    label: 'Branch Inventory', icon: Package,
    subItems: [
      { to: '/inventory', label: 'Asset Register', icon: Package },
    ],
  },
  {
    label: 'Branch Events', icon: CalendarClock,
    subItems: [
      { to: '/events', label: 'Alerts & Timeline', icon: CalendarClock },
    ],
  },
  {
    label: 'Branch Personas', icon: Users,
    subItems: [
      { to: '/employees', label: 'Employees', icon: Users },
    ],
  },
  { label: 'AI Assistant', to: '/assistant', icon: Bot },
  { label: 'Submit Feedback', to: '/feedback', icon: MessageSquare },
  { label: 'Virtual Tour', to: '/tour', icon: MapIcon },
]

export default function Sidebar() {
  const location = useLocation()
  const initialExpanded = navGroups
    .filter((g) => g.subItems?.some((s) => location.pathname.startsWith(s.to)))
    .map((g) => g.label)
  const [expanded, setExpanded] = useState<string[]>(initialExpanded)

  const toggle = (label: string) => {
    setExpanded((prev) => prev.includes(label) ? prev.filter((l) => l !== label) : [...prev, label])
  }

  return (
    <aside className="sidebar">
      <nav className="sidebar-nav">
        {navGroups.map((group) => {
          if (!group.subItems) {
            return (
              <div key={group.label} className="nav-row">
                <NavLink
                  to={group.to!}
                  end={group.to === '/'}
                  className={({ isActive }) => `nav-link ${isActive ? 'nav-link-active' : ''}`}
                >
                  <group.icon style={{ width: 16, height: 16 }} />
                  <span>{group.label}</span>
                </NavLink>
              </div>
            )
          }

          const isExpanded = expanded.includes(group.label)
          const hasActiveChild = group.subItems.some((s) => location.pathname === s.to)

          return (
            <div key={group.label} className="nav-row">
              <button
                onClick={() => toggle(group.label)}
                className={`nav-group-header ${isExpanded ? 'expanded' : ''}`}
                style={hasActiveChild ? { color: 'var(--brand-700)' } : undefined}
              >
                <group.icon style={{ width: 16, height: 16, color: hasActiveChild ? 'var(--brand-600)' : 'var(--ink-500)' }} />
                <span>{group.label}</span>
                <ChevronRight className="chevron" style={{ width: 13, height: 13, color: 'var(--ink-400)' }} />
              </button>
              {isExpanded && (
                <div className="nav-group-children">
                  {group.subItems.map((sub) => (
                    <NavLink
                      key={sub.to}
                      to={sub.to}
                      className={({ isActive }) => `nav-sub-link ${isActive ? 'nav-sub-link-active' : ''}`}
                    >
                      <sub.icon style={{ width: 13, height: 13 }} />
                      <span>{sub.label}</span>
                    </NavLink>
                  ))}
                </div>
              )}
            </div>
          )
        })}
      </nav>

      <div className="sidebar-foot">
        <span className="sidebar-foot-dot" />
        <span>27 branches · 9 countries</span>
      </div>
    </aside>
  )
}
