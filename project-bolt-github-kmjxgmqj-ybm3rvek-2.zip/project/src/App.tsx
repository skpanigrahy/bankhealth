import { Routes, Route } from 'react-router-dom'
import Sidebar from './components/Sidebar'
import Topbar from './components/Topbar'
import AICopilot from './components/AICopilot'
import Home from './pages/Home'
import BranchSearch from './pages/BranchSearch'
import BranchMap from './pages/BranchMap'
import BranchDetail from './pages/BranchDetail'
import Performance from './pages/Performance'
import IVRAnalytics from './pages/IVRAnalytics'
import Reports from './pages/Reports'
import BranchHealth from './pages/BranchHealth'
import NetworkHealth from './pages/NetworkHealth'
import DeviceHealth from './pages/DeviceHealth'
import ApplicationHealth from './pages/ApplicationHealth'
import Tickets from './pages/Tickets'
import Inventory from './pages/Inventory'
import Events from './pages/Events'
import Employees from './pages/Employees'
import Assistant from './pages/Assistant'
import ComingSoon from './pages/ComingSoon'
import ProductLanding from './pages/ProductLanding'

export default function App() {
  return (
    <div className="app-shell">
      <Sidebar />
      <div className="app-main">
        <Topbar />
        <div className="app-content">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/branch-search" element={<BranchSearch />} />
            <Route path="/branch-map" element={<BranchMap />} />
            <Route path="/branch/:branchId" element={<BranchDetail />} />
            <Route path="/performance" element={<Performance />} />
            <Route path="/ivr-analytics" element={<IVRAnalytics />} />
            <Route path="/reports" element={<Reports />} />
            <Route path="/branch-health" element={<BranchHealth />} />
            <Route path="/network-health" element={<NetworkHealth />} />
            <Route path="/device-health" element={<DeviceHealth />} />
            <Route path="/application-health" element={<ApplicationHealth />} />
            <Route path="/tickets" element={<Tickets />} />
            <Route path="/inventory" element={<Inventory />} />
            <Route path="/events" element={<Events />} />
            <Route path="/employees" element={<Employees />} />
            <Route path="/assistant" element={<Assistant />} />
            <Route path="/feedback" element={<ComingSoon title="Submit Feedback" />} />
            <Route path="/tour" element={<ComingSoon title="Branch Virtual Tour" />} />
            <Route path="/product/:productId" element={<ProductLanding />} />
          </Routes>
        </div>
      </div>
      <AICopilot />
    </div>
  )
}
